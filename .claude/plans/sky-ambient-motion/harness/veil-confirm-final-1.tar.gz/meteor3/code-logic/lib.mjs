// Minimal helpers for the code-logic investigation: own headless Chromium (playwright-core), observation only.
// Never touches the repository, never starts or stops a server, never calls the schedule API.
import fs from 'node:fs'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
export const PW = 'C:/Users/josep/AppData/Local/npm-cache/_npx/e41f203b7505f1fb/node_modules/playwright-core'
export const pw = require(PW)
export const { PNG } = require(PW + '/lib/utilsBundle.js')
export const HERE = 'C:/Users/josep/AppData/Local/Temp/claude/S--Documents-repos-Portfolio/f159339c-8cb2-444a-916b-251e57be791d/scratchpad/starfield/meteor3/code-logic'
export const CHROME = 'C:/Users/josep/AppData/Local/ms-playwright/chromium-1223/chrome-win64/chrome.exe'
export const GPU_ARGS = ['--enable-gpu', '--ignore-gpu-blocklist', '--use-angle=d3d11']
export const URL = 'http://localhost:3000/'
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

export function launch(args = GPU_ARGS) {
	return pw.chromium.launch({ executablePath: CHROME, headless: true, args })
}

// Page: every message posted to the sky worker (epoch ms), minus the canvas and tokens
export const PAGE_INIT = `(() => {
	const now = () => performance.timeOrigin + performance.now()
	const t = (window.__m3 = { posts: [], back: [], workers: 0 })
	const Native = window.Worker
	window.Worker = class extends Native {
		constructor(url, options) {
			super(url, options)
			t.workers++
			const post = this.postMessage
			this.postMessage = function (message, transfer) {
				try {
					const m = { at: now(), type: message.type }
					for (const [k, v] of Object.entries(message)) if (k !== 'canvas' && k !== 'tokens' && k !== 'type') m[k] = v
					t.posts.push(m)
				} catch {}
				return post.call(this, message, transfer)
			}
			this.addEventListener('message', (e) => t.back.push({ at: now(), type: e.data && e.data.type, message: e.data && e.data.message }))
		}
	}
})()`

export async function open(browser, { width = 1440, height = 900, dpr = 1, mobile = false, reducedMotion = 'no-preference' } = {}) {
	const context = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: dpr, reducedMotion, isMobile: mobile, hasTouch: mobile })
	await context.addInitScript(PAGE_INIT)
	const run = { context, logs: [] }
	const page = await context.newPage()
	run.page = page
	page.on('console', (m) => {
		if (m.type() === 'error' || m.type() === 'warning') run.logs.push(m.type() + ': ' + m.text().slice(0, 300))
	})
	page.on('pageerror', (e) => run.logs.push('pageerror: ' + String(e.message).slice(0, 300)))
	await page.goto(URL, { waitUntil: 'load', timeout: 120000 })
	return run
}

export const posts = (run) => run.page.evaluate(() => window.__m3.posts)
export const pageEpoch = (run) => run.page.evaluate(() => performance.timeOrigin + performance.now())

export async function waitFor(fn, timeout, label, interval = 50) {
	const start = Date.now()
	for (;;) {
		const value = await fn()
		if (value) return value
		if (Date.now() - start > timeout) throw new Error('timeout: ' + label)
		await sleep(interval)
	}
}
export async function waitPost(run, predicate, timeout, label) {
	return waitFor(async () => (await posts(run)).find(predicate), timeout, label)
}
export const save = (name, data) => fs.writeFileSync(`${HERE}/${name}`, typeof data === 'string' ? data : JSON.stringify(data, null, 1))
