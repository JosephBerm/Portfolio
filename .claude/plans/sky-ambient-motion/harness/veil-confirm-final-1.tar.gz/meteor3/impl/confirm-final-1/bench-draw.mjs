// JS cost of drawMeteor per frame (the repository's against the proposed), in my own headless Chromium on an OffscreenCanvas
// (GPU flags, as the live-capture harness): batches of 300 calls mid-flight near the copy, 12 batches, median per call.
import fs from 'node:fs'
import path from 'node:path'
import { launch } from '../../code-logic/lib.mjs'
import { P, B, HERE, loadCapture, fieldOf, walkProto } from './lib.mjs'

const label = process.argv[2] ?? '1440x900@1'
const capture = loadCapture(label)
const random = P.mulberry32(99)
const field = fieldOf(capture)
// a flight that passes behind the copy
let flight = null
for (let i = 0; i < 5000 && !flight; i++) {
	const f = P.planMeteor(random, field, P.pickRadiant(random, field.width, field.height), 0)
	if (f && walkProto(f, field.quiet, 200).filter((s) => s.onCopy && s.rise >= 0.04).length > 12) flight = f
}
const PAGE = '<!doctype html><meta charset="utf-8"><body></body>'
const TOKENS = { navy: [10, 25, 47], white: [230, 241, 255], green: [100, 255, 218], card2: [60, 103, 227], card3: [78, 0, 194] }
const browser = await launch()
try {
	const context = await browser.newContext({ viewport: { width: 800, height: 600 } })
	await context.route('http://sky.test/**', async (route) => {
		const url = new URL(route.request().url())
		if (url.pathname === '/') return route.fulfill({ contentType: 'text/html', body: PAGE })
		const file = path.resolve(HERE, '.' + decodeURIComponent(url.pathname))
		if (path.relative(HERE, file).startsWith('..') || !fs.existsSync(file)) return route.fulfill({ status: 404, body: 'missing' })
		return route.fulfill({ contentType: 'text/javascript', body: fs.readFileSync(file, 'utf8') })
	})
	const page = await context.newPage()
	await page.goto('http://sky.test/')
	for (const tree of ['base', 'proto']) {
		const zones = fieldOf(capture, tree === 'base' ? B : P).quiet
		const result = await page.evaluate(
			async ({ tree, flight, zones, width, height, tokens }) => {
				const { drawSky, drawMeteor, createStarField } = await import(`/pure/${tree}/components-sky/renderSky.mjs`)
				const { buildStarAtlas, buildHaze, starPalette } = await import(`/pure/${tree}/components-sky/skyAssets.mjs`)
				const canvas = new OffscreenCanvas(width, height)
				const ctx = canvas.getContext('2d', { alpha: false })
				const assets = { atlas: buildStarAtlas(1, tokens), haze: buildHaze(width, height, tokens), palette: starPalette(tokens), tokens }
				const frameAt = (time) => ({ time, width, height, dpr: 1, deviceWidth: width, deviceHeight: height, parallaxScroll: 0, keep: 0, layers: { far: 0, mid: 0, near: 0 }, dusk: Infinity, twinkle: 0, haze: 1, quiet: { from: [], to: zones, level: 1 }, meteorInk: 1, meteorScroll: 1 })
				const batches = []
				for (let b = 0; b < 12; b++) {
					const t0 = performance.now()
					for (let i = 0; i < 300; i++) drawMeteor(ctx, assets, flight, frameAt(flight.duration * (0.5 + 0.4 * (i / 300))))
					batches.push((performance.now() - t0) / 300)
					// flush the queued GPU work between batches so it doesn't pile up
					canvas.transferToImageBitmap?.()
				}
				batches.sort((a, b) => a - b)
				return batches[6]
			},
			{ tree, flight, zones, width: capture.width, height: capture.height, tokens: TOKENS }
		)
		console.log(label, tree, 'drawMeteor JS per call (ms, median of 12 batches):', result.toFixed(4))
	}
} finally {
	await browser.close()
}
