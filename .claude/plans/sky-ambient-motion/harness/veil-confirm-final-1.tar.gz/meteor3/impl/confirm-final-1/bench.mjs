// Cost of one planMeteor launch (Node 24, the real planners on the live rects) and of one drawMeteor call's JS.
import { P, B, loadCapture, fieldOf } from './lib.mjs'

const labels = ['1440x900@1', '1280x720@1', '1920x1080@1', '2560x1440@1', '390x844@3m']
const N = 3000
const q = (a, f) => [...a].sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(f * a.length))]
console.log('planMeteor per launch (ms): median / p99 / max')
for (const label of labels) {
	const capture = loadCapture(label)
	for (const tree of ['base', 'proto']) {
		const lib = tree === 'base' ? B : P
		const field = fieldOf(capture, lib)
		const random = lib.mulberry32(5)
		// warm up
		for (let i = 0; i < 300; i++) lib.planMeteor(random, field, lib.pickRadiant(random, field.width, field.height), 0)
		const times = []
		for (let i = 0; i < N; i++) {
			const radiant = lib.pickRadiant(random, field.width, field.height)
			const t0 = performance.now()
			lib.planMeteor(random, field, radiant, 0)
			times.push(performance.now() - t0)
		}
		console.log(label.padEnd(13), tree.padEnd(6), q(times, 0.5).toFixed(3), '/', q(times, 0.99).toFixed(3), '/', Math.max(...times).toFixed(3))
	}
}
