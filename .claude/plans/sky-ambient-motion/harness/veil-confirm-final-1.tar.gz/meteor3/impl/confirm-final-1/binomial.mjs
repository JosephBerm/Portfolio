// Acceptance thresholds for a live count: of n flights, how few may show a pass before the model is rejected at the 5% level?
// k_min(n, p) is the smallest k with P(X <= k) >= 0.05 for X ~ Binomial(n, p): a count below it happens in under 5% of correct runs.
//   node binomial.mjs <n> <p> [p...]
const [nArg, ...ps] = process.argv.slice(2)
const n = Number(nArg)
function pmf(k, p) {
	let logC = 0
	for (let i = 1; i <= k; i++) logC += Math.log((n - k + i) / i)
	return Math.exp(logC + k * Math.log(p) + (n - k) * Math.log(1 - p))
}
for (const p of ps.map(Number)) {
	let cdf = 0
	let kMin = 0
	for (let k = 0; k <= n; k++) {
		cdf += pmf(k, p)
		if (cdf >= 0.05) {
			kMin = k
			break
		}
	}
	// chance a correct run lands under the 12% / 20% style thresholds people write down, for comparison: the exact rate of a false alarm at k_min - 1
	let below = 0
	for (let k = 0; k < kMin; k++) below += pmf(k, p)
	console.log(`n ${n}, expected rate ${(100 * p).toFixed(1)}%: accept when at least ${kMin} of ${n} flights pass (${((100 * kMin) / n).toFixed(1)}%); a correct implementation fails this with probability ${(100 * below).toFixed(1)}%`)
}
