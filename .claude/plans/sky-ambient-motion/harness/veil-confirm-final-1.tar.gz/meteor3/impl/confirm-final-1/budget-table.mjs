// Per-element ink budgets and the analytic worst case (budget + haze reserve + the brightest far star on the same pixel, STAR_INK_PEAK),
// and the same with the haze really measured under each copy (results/haze-under-copy.txt: the worst white-equivalent over 9 viewports).
import { P, NAVY, WHITE } from './lib.mjs'
import { contrastRatio } from './wcag.mjs'

const rows = [
	['greeting, links, button', 'rgb(100, 255, 218)', 16, 400, 0.0084],
	['name h1 (and Contact heading)', 'rgb(204, 214, 246)', 75, 600, 0.0179],
	['tagline', 'rgb(136, 146, 176)', 75, 600, 0.0226],
	['paragraph', 'rgb(136, 146, 176)', 16, 400, 0.009],
	['rails, footer', 'rgb(168, 178, 209)', 12, 400, 0.0137],
	['phone name and tagline (35 px)', 'rgb(136, 146, 176)', 35, 600, 0.0226],
]
const lit = (white) => NAVY.map((c, k) => Math.min(255, c + white * WHITE[k]))
console.log(`STAR_INK_PEAK ${P.STAR_INK_PEAK}, hazeReserve ${P.INK_BUDGET.hazeReserve}, safety ${P.INK_BUDGET.safety}, ceiling ${P.INK_BUDGET.ceiling}`)
console.log('copy | WCAG min | on navy | headroom | budget | worst case white (budget + haze reserve + star) | contrast then | with the haze measured under it | contrast then')
for (const [name, color, size, weight, haze] of rows) {
	const text = P.parseRgbColor(color, NAVY)
	const min = P.minimumContrast(size, weight)
	const headroom = P.lightHeadroom(text, NAVY, WHITE, min)
	const budget = P.inkBudget(headroom)
	const worst = budget + P.INK_BUDGET.hazeReserve + P.STAR_INK_PEAK
	const real = budget + haze + P.STAR_INK_PEAK
	console.log(`${name} | ${min}:1 | ${contrastRatio(text, NAVY).toFixed(2)}:1 | ${headroom.toFixed(4)} | ${budget.toFixed(4)} | ${worst.toFixed(4)} | ${contrastRatio(text, lit(worst)).toFixed(2)}:1 | ${real.toFixed(4)} | ${contrastRatio(text, lit(real)).toFixed(2)}:1`)
}
// the brightest far star on copy, from the catalog and the twinkle bounds (what STAR_INK_PEAK = 0.6 x inkKeep rounds up)
const farAlpha = P.magnitudeAlpha ? P.magnitudeAlpha(P.LAYERS.far.magnitude[0]) : null
const sigmaMax = P.LAYERS.far.twinkleSigma[1] * (1 + P.TWINKLE_HORIZON_GAIN)
const noiseMax = (1 + P.TWINKLE_HARMONICS.weight2 + P.TWINKLE_HARMONICS.weight3) / P.TWINKLE_HARMONICS.norm
const lift = Math.exp(sigmaMax * noiseMax - (sigmaMax * sigmaMax) / 2)
console.log(`\nfar star alpha at magnitude ${P.LAYERS.far.magnitude[0]} (catalog) = ${farAlpha}; twinkle bound ${lift.toFixed(3)}; their product ${((farAlpha ?? 0.386) * lift).toFixed(4)} (STAR_INK_PEAK = 0.6 x inkKeep, so ${(0.6 * P.LAYERS.far.inkKeep).toFixed(4)} at ${P.LAYERS.far.inkKeep}; ${(0.6 * 0.1).toFixed(4)} at 0.1)`)
