// Check E (edge fades) on the implemented code, with the confirmer's metric (confirm-3/categories.mjs, variant.mjs, variant-policy.mjs)
// pointed at the repository (impl/pure/proto) and at the plan's files (impl/pure/plan) for contrast.
//   edge fade  a planned flight whose head, at least METEOR_VEIL.edgeBright (0.3) white unveiled, is dimmed by the veil to edgeKept (0.5) of its light or
//              less, and that never shows on a text rect at METEOR_PASS.glimmer (0.041) white or more for METEOR_PASS.dwell (0.1) of the flight
//   scored on a finer walk than the planner's 64 samples (400 moments per flight), as the confirmer did, so a rare residue is expected
//   per-launch  a fresh radiant per launch (variant.mjs: 2000 launches, seeds 0xbeef + 3w + h)
//   policy      the worker's own radiant policy (variant-policy.mjs): sessions of 10 launches, a sticky radiant, long flights on every radiant before
//               a shorter one, one fresh radiant on narrow screens (seeds 0x5eed + w)
//   node check-e.mjs [per-launch launches] [policy sessions] [ink] [labels...]    ink: 1 (default) or 0 (prefers-contrast: more)
import { P, loadCapture, fieldOf, walkProto } from './lib.mjs'

const N = Number(process.argv[2] ?? 2000)
const SESSIONS = Number(process.argv[3] ?? 150)
const INK = Number(process.argv[4] ?? 1)
const ALL = ['1440x900@1', '1280x800@1', '1366x768@1', '1536x864@1.25', '1920x1080@1', '2560x1440@1', '1280x720@1', '1024x768@1', '390x844@3m']
const labels = process.argv.slice(5).length ? process.argv.slice(5) : ALL
// The plan's files (PTREE=plan) have no such keys: the confirmer's thresholds stand in, to score the plan's flights the same way
const { edgeBright = 0.3, edgeKept = 0.5 } = P.METEOR_VEIL
const { glimmer = 0.041, dwell } = P.METEOR_PASS
const CATEGORY_LABELS = ['1440x900@1', '1280x800@1', '1920x1080@1']
const STEPS = 400
const POLICY_STEPS = 300

const pc = (v, d) => ((100 * v) / Math.max(1, d)).toFixed(1).padStart(5) + '%'
const median = (a) => (a.length ? [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)] : NaN)

/** Scores one planned flight on the fine walk: did a bright head get dimmed away without showing on the copy? */
function score(flight, zones, steps) {
	const walk = walkProto(flight, zones, steps, INK)
	const dt = flight.duration / steps
	let faded = false
	let on = 0
	let on12 = 0
	for (const s of walk) {
		if (s.white >= edgeBright && s.kept <= edgeKept) faded = true
		if (s.onCopy && s.rise >= glimmer) on++
		if (s.onCopy && s.rise >= P.METEOR_PASS.visible) on12++
	}
	const pass = on * dt >= dwell
	return { faded, pass, edge: faded && !pass, pass12: on12 * dt >= dwell }
}

const rows = []
console.log(`ink ${INK}; edge fade = head >= ${edgeBright} white unveiled dimmed to <= ${edgeKept} of its light, no pass (>= ${glimmer} white on a text rect for ${dwell} of the flight); fine walk ${STEPS} moments per launch, ${POLICY_STEPS} per policy flight`)
for (const label of labels) {
	const capture = loadCapture(label)
	const field = fieldOf(capture, P)
	const narrow = capture.width <= P.NARROW_MAX_WIDTH
	const shortLimit = (narrow ? P.METEOR.narrowFallbackDuration[1] : P.METEOR.fallbackDuration[1]) + 1e-9

	// per launch, fresh radiant
	{
		const random = P.mulberry32(0xbeef + capture.width * 3 + capture.height)
		let planned = 0
		let short = 0
		let edge = 0
		let pass = 0
		let pass12 = 0
		let fireball = 0
		let flare = 0
		let train = 0
		const paths = []
		const durs = []
		for (let i = 0; i < N; i++) {
			const flight = P.planMeteor(random, field, P.pickRadiant(random, capture.width, capture.height), 0, { ink: INK })
			if (!flight) continue
			planned++
			if (!flight.fireball && flight.duration <= shortLimit) short++
			if (flight.fireball) fireball++
			if (flight.flare) flare++
			if (flight.train) train++
			paths.push(flight.length)
			durs.push(flight.duration)
			const s = score(flight, field.quiet, STEPS)
			if (s.edge) edge++
			if (s.pass) pass++
			if (s.pass12) pass12++
		}
		const row = { label, mode: 'per-launch', launches: N, planned: planned / N, short: short / Math.max(1, planned), edge: edge / Math.max(1, planned), pass: pass / N, pass12: pass12 / N }
		rows.push(row)
		console.log(`${label.padEnd(14)} per-launch ${String(N).padStart(5)} planned ${pc(planned, N)} short ${pc(short, planned)} | edge fade ${pc(edge, planned)} | pass@.04 ${pc(pass, N)} pass@.12 ${pc(pass12, N)} | fireball ${pc(fireball, planned)} flare ${pc(flare, planned)} train ${pc(train, planned)} | path ${median(paths).toFixed(0)} dur ${median(durs).toFixed(2)}`)
	}

	// categories (confirm-3/categories.mjs: 1500 launches, 300 moments, seeds 0xca7 + w): every planned flight in one class
	if (CATEGORY_LABELS.includes(label)) {
		const random = P.mulberry32(0xca7 + capture.width)
		const c = { pass: 0, edge: 0, late: 0, graze: 0, clear: 0 }
		let planned = 0
		for (let i = 0; i < 1500; i++) {
			const f = P.planMeteor(random, field, P.pickRadiant(random, capture.width, capture.height), 0, { ink: INK })
			if (!f) continue
			planned++
			const walk = walkProto(f, field.quiet, 300, INK)
			const dt = f.duration / 300
			let on = 0
			let bright = false
			let minKept = 1
			for (const st of walk) {
				if (st.onCopy && st.rise >= glimmer) on++
				if (st.white >= edgeBright && st.kept <= edgeKept) bright = true
				minKept = Math.min(minKept, st.kept)
			}
			if (on * dt >= dwell) c.pass++
			else if (bright) c.edge++
			else if (minKept <= 0.5) c.late++
			else if (minKept < 0.9) c.graze++
			else c.clear++
		}
		rows.push({ label, mode: 'categories', edge: c.edge / planned })
		console.log(`${label.padEnd(14)} categories ${Object.entries(c).map(([k, v]) => `${k} ${((100 * v) / planned).toFixed(1)}%`).join('  ')}`)
	}

	// the worker's own radiant policy
	{
		const random = P.mulberry32(0x5eed + capture.width)
		let launches = 0
		let planned = 0
		let short = 0
		let edge = 0
		let pass = 0
		for (let s = 0; s < SESSIONS; s++) {
			let radiant = null
			for (let l = 0; l < 10; l++) {
				launches++
				const radiants = radiant ? [radiant] : []
				while (radiants.length < (radiant ? 1 : 0) + (narrow ? 1 : P.METEOR.radiantTries)) radiants.push(P.pickRadiant(random, capture.width, capture.height))
				let plan = null
				outer: for (const flights of ['long', 'short']) {
					for (const candidate of radiants) {
						plan = P.planMeteor(random, field, candidate, 0, { flights, ink: INK })
						if (plan) {
							radiant = candidate
							break outer
						}
					}
				}
				if (!plan) {
					radiant = null
					continue
				}
				planned++
				if (!plan.fireball && plan.duration <= shortLimit) short++
				const sc = score(plan, field.quiet, POLICY_STEPS)
				if (sc.pass) pass++
				else if (sc.faded) edge++
			}
		}
		const row = { label, mode: 'policy', launches, planned: planned / launches, short: short / Math.max(1, planned), edge: edge / Math.max(1, planned), pass: pass / Math.max(1, planned) }
		rows.push(row)
		console.log(`${label.padEnd(14)} policy     ${String(launches).padStart(5)} planned ${pc(planned, launches)} short ${pc(short, planned)} | edge fade ${pc(edge, planned)} | pass@.04 ${pc(pass, planned)}`)
	}
}

// acceptance (the confirmer's metrics): edge fades at most 2% of planned flights on every desktop viewport, 1024x768 up, as categories.mjs
// (fresh radiant, three viewports) and variant-policy.mjs (the worker's own radiant policy, all of them) measure them; the phone's is reported,
// not judged. The per-launch figure of variants.mjs (fresh radiant, every viewport) is reported beside them.
const isDesktop = (r) => !r.label.startsWith('390')
const worstOf = (list) => list.reduce((a, r) => (r.edge > a.edge ? r : a), { edge: 0, label: '-' })
const judged = rows.filter((r) => isDesktop(r) && (r.mode === 'policy' || r.mode === 'categories'))
const worst = worstOf(judged)
console.log(`\nworst desktop edge fade, categories and worker policy: ${(100 * worst.edge).toFixed(1)}% (${worst.label}, ${worst.mode}); limit 2.0%: ${worst.edge <= 0.02 ? 'PASS' : 'FAIL'}`)
const worstLaunch = worstOf(rows.filter((r) => isDesktop(r) && r.mode === 'per-launch'))
console.log(`worst desktop edge fade per launch (fresh radiant, variant.mjs metric): ${(100 * worstLaunch.edge).toFixed(1)}% (${worstLaunch.label})`)
for (const r of rows.filter((r) => !isDesktop(r) && r.mode !== 'categories')) console.log(`phone ${r.mode}: edge fade ${(100 * r.edge).toFixed(1)}%, planned ${(100 * r.planned).toFixed(1)}%, short ${(100 * r.short).toFixed(1)}%`)
process.exitCode = worst.edge <= 0.02 ? 0 : 1
