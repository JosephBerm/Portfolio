// D3 on the implemented renderSky (impl/pure/proto), with a recording 2D context and no browser: drawMeteor(ctx, assets, meteor, frame, fade)
// multiplies the alpha of the train, the wake (both passes), the glow and the core by `fade`, in clear sky and behind copy, and fade = 1 is the
// default (the same calls as passing 1). Also: drawMeteor reads no frame-level scroll field any more.
// And D2: while a layout change eases in (blend level under 1, no previous copy at that spot), every part of the star, head, glow, core, wake and train,
// is drawn with the new zones share, not the cross-fade: the same alphas as with the ease finished. The plan renderer is the control, which draws
// them brighter.
//   node check-fade.mjs
import { pathToFileURL } from 'node:url'
import { HERE, loadCapture, fieldOf } from './lib.mjs'

const load = async (dir, name) => import(pathToFileURL(`${HERE}/pure/proto/${dir}/${name}.mjs`).href)
const { drawMeteor } = await load('components-sky', 'renderSky')
const L = { ...(await load('lib-sky', 'meteors')), ...(await load('lib-sky', 'config')), ...(await load('lib-sky', 'random')), ...(await load('lib-sky', 'scene')) }

class RecordingContext {
	constructor() {
		this.globalAlpha = 1
		this.log = { images: [], fills: [], strokes: [], gradients: [] }
	}
	set fillStyle(value) {
		this._fill = value
	}
	set strokeStyle(value) {
		this._stroke = value
	}
	createLinearGradient() {
		const gradient = { stops: [] , addColorStop(offset, color) { this.stops.push([offset, Number(/,([\d.]+)\)$/.exec(color)?.[1])]) } }
		this.log.gradients.push(gradient)
		return gradient
	}
	drawImage(image, sx, sy, sw, sh) {
		this.log.images.push({ alpha: this.globalAlpha, size: sw })
	}
	beginPath() {}
	moveTo() {}
	lineTo() {}
	closePath() {}
	fill() {
		this.log.fills.push({ alpha: this.globalAlpha, stops: this._fill.stops.map((s) => s[1]) })
	}
	stroke() {
		this.log.strokes.push({ stops: this._stroke.stops.map((s) => s[1]) })
	}
}

const tokens = { navy: [10, 25, 47], white: [230, 241, 255], green: [100, 255, 218], card2: [60, 103, 227], card3: [78, 0, 194] }
const assets = { atlas: { image: {}, stars: [], meteorCore: { x: 0, y: 0, size: 7 }, meteorGlow: { x: 8, y: 0, size: 19 } }, haze: null, palette: Array.from({ length: 8 }, () => tokens.white), tokens }
const capture = loadCapture('1440x900@1')
const field = fieldOf(capture, L)

// a fireball (it has a train and a glow boost) in clear sky, and a plain flight that passes behind the copy
const random = L.mulberry32(11)
let fireball = null
let behind = null
for (let i = 0; i < 20000 && !(fireball && behind); i++) {
	const flight = L.planMeteor(random, field, L.pickRadiant(random, field.width, field.height), 0)
	if (!flight) continue
	if (!fireball && flight.fireball && flight.train) fireball = flight
	if (!behind && flight.nearCopy && !flight.fireball && !flight.train) behind = flight
}
const frameOf = (flight, progress, zones) => ({
	time: flight.startedAt + progress * flight.duration,
	width: field.width,
	height: field.height,
	dpr: 1,
	deviceWidth: field.width,
	deviceHeight: field.height,
	parallaxScroll: 0,
	keep: 0,
	layers: { far: 0, mid: 0, near: 0 },
	dusk: Infinity,
	twinkle: 0,
	haze: 0,
	quiet: { from: [], to: zones, level: 1 },
	meteorInk: 1,
})

/** Every alpha drawMeteor writes, in call order: image alphas, soft pass and core pass fills with their gradient stops, the train's stops. */
const alphasOf = (flight, progress, zones, fade) => {
	const ctx = new RecordingContext()
	if (fade === undefined) drawMeteor(ctx, assets, flight, frameOf(flight, progress, zones))
	else drawMeteor(ctx, assets, flight, frameOf(flight, progress, zones), fade)
	const { images, fills, strokes } = ctx.log
	return { images: images.map((i) => i.alpha), fillAlphas: fills.map((f) => f.alpha), stops: fills.map((f) => f.stops), train: strokes.map((s) => s.stops) }
}

let failures = 0
const flat = (a) => [...a.images, ...a.stops.flat(), ...a.train.flat()]
const near = (a, b) => Math.abs(a - b) < 2e-4
const cases = [
	['a fireball with its train, in clear sky, p 0.6', fireball, 0.6, []],
	['a fireball with its train after the flight (the train lingers), p 1.3', fireball, 1.3, []],
	['a flight behind the copy, p 0.8', behind, 0.8, field.quiet],
]
for (const [name, flight, progress, zones] of cases) {
	if (!flight) {
		console.log(`FAIL ${name}: no such flight found`)
		failures++
		continue
	}
	const one = alphasOf(flight, progress, zones, 1)
	const none = alphasOf(flight, progress, zones, undefined)
	const defaultIsOne = JSON.stringify(one) === JSON.stringify(none)
	const parts = { glow: one.images[0], core: one.images[1], wakeStops: one.stops.flat().length, trainStops: one.train.flat().length }
	let scaled = true
	for (const fade of [0.5, 0.25, 0]) {
		const dimmed = alphasOf(flight, progress, zones, fade)
		const a = flat(one)
		const b = flat(dimmed)
		if (a.length !== b.length) scaled = false
		for (let k = 0; k < a.length; k++) if (!near(b[k], a[k] * fade)) scaled = false
		// the fills' own alphas (the soft pass 0.22 and the core pass 1) are not faded: the gradient's stops carry it
		if (JSON.stringify(dimmed.fillAlphas) !== JSON.stringify(one.fillAlphas)) scaled = false
	}
	const lit = flat(one).filter((v) => v > 0.01).length
	console.log(`${defaultIsOne && scaled && lit > 0 ? 'ok  ' : 'FAIL'} ${name}: fade 1 is the default ${defaultIsOne}; every alpha scales with fade 0.5 / 0.25 / 0 ${scaled}; ${lit} of ${flat(one).length} alphas above 0.01 (glow ${parts.glow?.toFixed(3)}, core ${parts.core?.toFixed(3)}, wake stops ${parts.wakeStops}, train stops ${parts.trainStops})`)
	if (!(defaultIsOne && scaled && lit > 0)) failures++
}

// ---------- D2 in the renderer ----------
{
	const plan = {
		drawMeteor: (await import(pathToFileURL(HERE + '/pure/plan/components-sky/renderSky.mjs').href)).drawMeteor,
		scene: await import(pathToFileURL(HERE + '/pure/plan/lib-sky/scene.mjs').href),
	}
	const at = (flight, progress) => L.meteorPoint(flight, Math.min(1, progress))
	// copy right under the head and under the middle of the flown path (so the wake and the train both cross it): the tagline's headroom, rects
	// 70 px wide and 24 px tall, in screen coordinates
	const copyAt = (points) => points.map((p) => ({ x: p.x - 35, y: p.y - 12, width: 70, height: 24, headroom: 0.19 }))
	const rects = copyAt([at(fireball, 0.7), at(fireball, 0.35)])
	const zonesTo = L.screenQuietZones(rects, 0, [])
	const planTo = plan.scene.screenQuietZones(rects, 0, [])
	const run = (draw, flight, progress, to, level, extra = {}) => {
		const ctx = new RecordingContext()
		draw(ctx, assets, flight, { ...frameOf(flight, progress, to), quiet: { from: [], to, level }, ...extra })
		const { images, fills, strokes } = ctx.log
		return [...images.map((i) => i.alpha), ...fills.flatMap((f) => f.stops), ...strokes.flatMap((st) => st.stops)]
	}
	const done = run(drawMeteor, fireball, 0.7, zonesTo, 1)
	const easing = run(drawMeteor, fireball, 0.7, zonesTo, 0.3)
	const sameAlphas = done.length === easing.length && done.every((v, k) => near(v, easing[k]))
	const controlDone = run(plan.drawMeteor, fireball, 0.7, planTo, 1, { meteorScroll: 1 })
	const controlEasing = run(plan.drawMeteor, fireball, 0.7, planTo, 0.3, { meteorScroll: 1 })
	const brighter = controlEasing.filter((v, k) => v > controlDone[k] + 1e-3).length
	console.log(`${sameAlphas && brighter > 0 ? 'ok  ' : 'FAIL'} D2: with the ease at 0.3 and no copy there before, every alpha of the star (${done.length}: glow, core, wake stops, train stops) equals its alpha with the ease finished: ${sameAlphas}; the plan's renderer, the control, draws ${brighter} of them brighter mid-ease`)
	if (!(sameAlphas && brighter > 0)) failures++
}

console.log(failures ? `\nFAILED (${failures})` : '\nfade multiplies the train, wake, glow and core alphas, and the star follows the new zones at once')
process.exitCode = failures ? 1 : 0
