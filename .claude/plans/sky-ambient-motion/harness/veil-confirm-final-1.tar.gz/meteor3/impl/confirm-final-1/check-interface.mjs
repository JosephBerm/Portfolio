// The promise to the ambient-motion session (INTERFACE-FINAL.md "Exports") against the implemented code: every name exists with the
// shape promised. Function.length counts the parameters before the first default, so planMeteor (options = {}) reports 4, budgetKeeps
// (ink = 1) 2, scrollKept (fade = 1) 2, drawMeteor (fade = 1) 4, headGain (boost = 1) 0. Reads impl/pure/proto (the repository, transpiled)
// and the source text for what a transpile cannot show (the SkyFrame field, the private names).
//   node check-interface.mjs
import fs from 'node:fs'
import { pathToFileURL } from 'node:url'
import { HERE } from './lib.mjs'

const load = async (dir, name) => import(pathToFileURL(`${HERE}/pure/proto/${dir}/${name}.mjs`).href)
const config = await load('lib-sky', 'config')
const scene = await load('lib-sky', 'scene')
const meteors = await load('lib-sky', 'meteors')
const render = await load('components-sky', 'renderSky')
const REPO = 'S:/Documents/repos/Portfolio'
const text = (rel) => fs.readFileSync(`${REPO}/${rel}`, 'utf8')
let failures = 0
const check = (name, ok, detail = '') => {
	if (!ok) failures++
	console.log(`${ok ? 'ok  ' : 'FAIL'} ${name}${detail ? '  ' + detail : ''}`)
}
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b)

check('config.INK_BUDGET', same(config.INK_BUDGET, { ceiling: 0.2, safety: 0.9, hazeReserve: 0.025 }), JSON.stringify(config.INK_BUDGET))
check('config.STAR_INK_PEAK = 0.6 * LAYERS.far.inkKeep, with inkKeep 0', config.STAR_INK_PEAK === 0.6 * config.LAYERS.far.inkKeep && config.LAYERS.far.inkKeep === 0)
check('config.METEOR_VEIL', same(config.METEOR_VEIL, { quietKeep: 0.3, clearUntil: 0.47, rise: 0.01, samples: 64, edgeBright: 0.3, edgeKept: 0.5 }), JSON.stringify(config.METEOR_VEIL))
check('config.METEOR_PASS', same(config.METEOR_PASS, { share: 0.4, visible: 0.12, dwell: 0.1, glimmer: 0.041 }), JSON.stringify(config.METEOR_PASS))
check('config.SCROLL_CANCEL', same(config.SCROLL_CANCEL, { from: 12, to: 24 }))
check('config.QUIET_REACH = QUIET.padding + QUIET.feather', config.QUIET_REACH === config.QUIET.padding + config.QUIET.feather && config.QUIET_REACH === 72)

check('scene.inkBudget(headroom)', typeof scene.inkBudget === 'function' && scene.inkBudget.length === 1)
check('scene.budgetKeeps(white, quietKeep, ink = 1)', typeof scene.budgetKeeps === 'function' && scene.budgetKeeps.length === 2 && text('src/lib/sky/scene.ts').includes('export function budgetKeeps(white: number, quietKeep: number, ink = 1): QuietKeeps'))
check('scene.scrollKept(launchScrollY, scrollY, fade = 1)', typeof scene.scrollKept === 'function' && scene.scrollKept.length === 2 && text('src/lib/sky/scene.ts').includes('export function scrollKept(launchScrollY: number, scrollY: number, fade = 1): number'))
check('scene.transientQuietFactor(blend, x, y, keeps)', typeof scene.transientQuietFactor === 'function' && scene.transientQuietFactor.length === 4 && text('src/lib/sky/scene.ts').includes('export function transientQuietFactor(blend: QuietBlend, x: number, y: number, keeps: QuietKeeps): number'))
check('scene.easedQuietFactor and quietFactor still exported (the stars)', typeof scene.easedQuietFactor === 'function' && typeof scene.quietFactor === 'function')
check('scene.QuietKeeps.inkKeep is a number or (zone) => number', text('src/lib/sky/scene.ts').includes('inkKeep: number | ((zone: SkyRect) => number)'))
check('scene: fitKeep private', scene.fitKeep === undefined && !text('src/lib/sky/scene.ts').includes('export function fitKeep'))

check('meteors.planMeteor(random, field, radiant, now, options: PlanOptions = {})', meteors.planMeteor.length === 4 && text('src/lib/sky/meteors.ts').includes('export function planMeteor(random: () => number, field: MeteorField, radiant: Point, now: number, options: PlanOptions = {}): Meteor | null'))
check('meteors.PlanOptions { nearCopy?, flights?, ink? }', /export interface PlanOptions \{\s*\/\*\*[^]*?nearCopy\?: boolean[^]*?flights\?: 'long' \| 'short' \| 'both'[^]*?ink\?: number\s*\}/.test(text('src/lib/sky/meteors.ts')))
check('meteors.Meteor.nearCopy: boolean', /nearCopy: boolean\s*startedAt: number/.test(text('src/lib/sky/meteors.ts')))
check('meteors.headGain(boost = 1) and WAKE_GAIN', typeof meteors.headGain === 'function' && meteors.headGain.length === 0 && typeof meteors.WAKE_GAIN === 'number')
check('meteors: planFlight private with PassOptions extends PlanOptions { timing, fireballs }', meteors.planFlight === undefined && /interface PassOptions extends PlanOptions \{\s*timing: readonly \[number, number\]\s*fireballs: boolean\s*\}/.test(text('src/lib/sky/meteors.ts')) && text('src/lib/sky/meteors.ts').includes('function planFlight(random: () => number, field: MeteorField, radiant: Point, now: number, options: PassOptions): Meteor | null'))
check('meteors: segmentTouches not exported', meteors.segmentTouches === undefined)
check('meteors: veiledFrom private, returns { dimFrom, behind } | null', meteors.veiledFrom === undefined && text('src/lib/sky/meteors.ts').includes('function veiledFrom(zones: readonly SkyRect[], path: MeteorPath, peak: number, ink: number): Veiled | null'))

check('renderSky.drawMeteor(ctx, assets, meteor, frame, fade = 1)', render.drawMeteor.length === 4 && text('src/components/sky/renderSky.ts').includes('export function drawMeteor(ctx: OffscreenCanvasRenderingContext2D, assets: SkyAssets, meteor: Meteor, frame: SkyFrame, fade = 1): void'))
check('renderSky: SkyFrame has no meteorScroll, still has meteorInk', !/\bmeteorScroll\b/.test(text('src/components/sky/renderSky.ts')) && /meteorInk: number/.test(text('src/components/sky/renderSky.ts')))

const worker = text('src/components/sky/sky.worker.ts')
check('worker: launchScrollY, planLaunch, contrastLevels, applyLayout, settleQuiet', ['let launchScrollY', 'function planLaunch(', 'function contrastLevels(', 'function applyLayout(', 'function settleQuiet('].every((s) => worker.includes(s)))
check('worker passes scrollKept(launchScrollY, scrollY) to drawMeteor', worker.includes('drawMeteor(ctx, assets, meteor, frame, scrollKept(launchScrollY, scrollY))') && !/\bmeteorScroll\b/.test(worker))
check('worker: the radiant is sticky: resize clears it, layout does not re-pick it', /function resize\([^]*?radiant = null/.test(worker) && !/case 'layout': \{[^]*?radiant = null/.test(worker))
check('mountSky: copyReader', text('src/components/sky/mountSky.ts').includes('function copyReader('))
check('protocol: SkyRect.headroom: number', /headroom: number/.test(text('src/lib/sky/protocol.ts')))
check('color: luminance and contrastRatio private', (await load('lib-sky', 'color')).luminance === undefined && (await load('lib-sky', 'color')).contrastRatio === undefined)
check('AGENTS.md carries the copyReader precondition line', /free of static `transform` translations and of `opacity` below 1 at rest/.test(text('AGENTS.md')))

console.log(failures ? `\nFAILED (${failures})` : '\nthe interface promised in INTERFACE-FINAL.md is what the repository exports')
process.exitCode = failures ? 1 : 0
