// Check W: the real worker (fake clock, recording 2D context) with a shooting star in flight that passes behind copy, then a layout message that
// shifts all the copy by 10-20 px. Two claims, on the implemented tree (proto = the repository) and, for contrast, the plan's tree (plan):
//   W1  no head pixel goes above the budget of the copy it is on during the ease: per drawn frame, the head's white (core + glow + the wake's
//       head stop through its soft pass and core, read from the alphas the worker drew) against inkBudget(headroom) of every text rect, in the
//       NEW layout, the head is inside (the most protective wins). The plan drew the star through the stars' cross-fade, which still held the old
//       zones' share while copy slid under the head, so it could exceed.
//   W2  stars still cross-fade: every star that is drawn at a constant alpha before the message (no twinkle) and changes after it changes at no
//       more than the ease rate (a clean 0.6 s smoothstep: 1.5 / 0.6 = 2.5 per second of its own alpha) and none steps in one frame; the stars use
//       easedQuietFactor, which D2 left alone.
//   HELD=1 (round-1 fix, audit finding correctness-wcag:F1): an unrelated 1 px re-measure goes in 100 ms before the shift, so the
//       ease it starts is still running when the shift arrives and the worker holds the shift (pendingLayout) for up to 0.6 s. W1 is
//       scored against the shifted copy's budgets all the same: the star must not wait for the held layout to be applied. W2 (stars)
//       is scored over a longer window (1.4 s), on the stars the 1 px re-measure leaves alone: the held shift must still cross-fade at the ease rate (the one-frame step bound is
//       left out: the second ease runs after the flight, on 33 ms fade frames, where a clean ease steps 0.083).
//   node --max-old-space-size=12000 check-w.mjs [label] [passes per tree] [trees: plan,proto]
import fs from 'node:fs'
import { ZONES, P, loadCapture, walkProto } from './lib.mjs'
import { createSim, alphaOf } from './harness/sim.mjs'

const label = process.argv[2] ?? '1440x900@1'
const HELD = process.env.HELD === '1'
const PASSES = Number(process.argv[3] ?? 24)
// One tree per process keeps the worker module instances (a fresh one per simulated visit, never collected) within the heap
const TREES = (process.argv[4] ?? 'plan,proto').split(',')
const capture = loadCapture(label)
const raw = JSON.parse(fs.readFileSync(`${ZONES}/${label}.json`, 'utf8'))
const clean = (rects, headrooms) => rects.map((r, i) => ({ x: r.x, y: r.y, width: r.width, height: r.height, headroom: headrooms[i] ?? 0 }))
const settledRaw = raw.layouts.filter((l) => l.quiet.length > 0).at(-1)
const settled = {
	documentHeight: settledRaw.documentHeight,
	quiet: clean(settledRaw.quiet, capture.quiet.map((r) => r.headroom)),
	pinned: clean(settledRaw.pinned, capture.pinned.map((r) => r.headroom)),
}
const shifted = (dx, dy) => ({ documentHeight: settled.documentHeight, quiet: settled.quiet.map((r) => ({ ...r, x: r.x + dx, y: r.y + dy })), pinned: settled.pinned.map((r) => ({ ...r, x: r.x + dx, y: r.y + dy })) })
const zonesOf = (layout) => P.screenQuietZones(layout.quiet, 0, layout.pinned)
const insideRect = (r, x, y) => x >= r.x && x <= r.x + r.width && y >= r.y && y <= r.y + r.height

// copy shifted by 10-20 px, in several directions; the message lands 0 to 0.45 s before the head reaches the copy, so the ease (0.6 s) covers the pass
const VECTORS = [[0, 10], [0, -10], [0, 15], [0, -15], [0, 20], [0, -20], [12, 12], [-12, -12], [15, 0], [-15, 0], [20, -10]]
const LEADS = [0, 0.2, 0.45]
// held: the shift waits up to 0.5 s and then eases in over 0.6 s, so the window has to reach past 1.1 s to hold the whole second ease
const WINDOW_S = HELD ? 1.4 : 0.8
const EASE_RATE = 1.5 / P.QUIET.ease
// The worker writes gradient alphas with 4 decimals (rgba()), and the head's white is read back from them: 2 x 1.22 x 5e-5, rounded up
const TOLERANCE = 2e-4
// Under this alpha (2.5 levels of 255) a star's change is below what a viewer can see; the renderer skips a star under MIN_STAR_ALPHA (0.004) altogether
const VISIBLE_ALPHA = 0.01

/** The seeds whose first launch passes behind copy in the settled layout, with the time (s after launch) its head first shows on the copy. */
async function seedsWithPass(tree, wanted) {
	const found = []
	for (let seed = 1; found.length < wanted && seed < 400; seed++) {
		const sim = await createSim({ width: capture.width, height: capture.height, seed, tree })
		sim.send({ type: 'init' })
		sim.advance(3800)
		sim.send({ type: 'reveal' })
		const revealAt = sim.clock.now
		sim.send({ type: 'layout', ...settled })
		if (!sim.until(revealAt + 20000, () => !!sim.dbg.meteor)) continue
		const flight = { ...sim.dbg.meteor }
		const walk = walkProto(flight, zonesOf(settled), 600)
		const on = walk.find((s) => s.onCopy && s.rise >= P.METEOR_PASS.glimmer)
		if (on) found.push({ seed, arrives: on.p * flight.duration })
	}
	return found
}

async function run(tree, { seed, arrives }, [dx, dy], lead) {
	const sim = await createSim({ width: capture.width, height: capture.height, seed, tree })
	sim.send({ type: 'init' })
	sim.advance(3800)
	sim.send({ type: 'reveal' })
	const revealAt = sim.clock.now
	sim.send({ type: 'layout', ...settled })
	if (!sim.until(revealAt + 20000, () => !!sim.dbg.meteor)) return null
	const launchMs = sim.clock.now
	const after = shifted(dx, dy)
	const shiftMs = launchMs + Math.max(0, arrives - lead) * 1000
	// the stars are recorded from the launch on, so the frames before the message give each its resting alpha
	sim.recordStars = true
	if (HELD) {
		sim.until(Math.max(sim.clock.now, shiftMs - 100))
		sim.send({ type: 'layout', ...shifted(0, 1) })
		if (!sim.dbg.layoutAt) throw new Error('the 1 px re-measure did not start an ease')
	}
	sim.until(shiftMs)
	sim.flush()
	const shiftT = sim.clock.now / 1000
	sim.send({ type: 'layout', ...after })
	if (HELD && [dx, dy].some((v) => v !== 0) && sim.dbg.pendingLayout === null) throw new Error('the shift was not held')
	sim.until(sim.clock.now + WINDOW_S * 1000)
	sim.flush()
	sim.recordStars = false

	// W1: the head against the new copy's budgets
	const texts = [...after.quiet, ...after.pinned]
	let maxRatio = 0
	let worstExcess = -Infinity
	let onCopyFrames = 0
	let exceeding = 0
	let maxRise = 0
	let lastRise = null
	let maxJump = 0
	const riseAt = new Map()
	for (const f of sim.frames) {
		if (f.t < shiftT - 1e-9 || f.t > shiftT + WINDOW_S) continue
		const core = f.meteorImages.find((i) => i.size === 7)
		const glow = f.meteorImages.find((i) => i.size === 19)
		if (!core) continue
		const headFill = f.fills.map((x) => x.alpha * alphaOf(x.gradient.stops[0][1]))
		const rise = core.alpha + (glow?.alpha ?? 0) + headFill.reduce((a, b) => a + b, 0)
		maxRise = Math.max(maxRise, rise)
		riseAt.set(Math.round(f.t * 1e4), rise)
		if (lastRise !== null) maxJump = Math.max(maxJump, Math.abs(rise - lastRise))
		lastRise = rise
		const budgets = texts.filter((r) => insideRect(r, core.cx, core.cy)).map((r) => P.inkBudget(r.headroom))
		if (budgets.length === 0) continue
		onCopyFrames++
		const budget = Math.min(...budgets)
		maxRatio = Math.max(maxRatio, rise / budget)
		worstExcess = Math.max(worstExcess, rise - budget)
		if (rise - budget > TOLERANCE) exceeding++
	}

	// W2: stars whose alpha is constant before the message and changes after it
	const series = new Map()
	for (const frame of sim.starFrames) {
		for (const star of frame.stars) {
			const key = `${star.cx},${star.cy}`
			let list = series.get(key)
			if (!list) series.set(key, (list = []))
			list.push({ t: frame.t, alpha: star.alpha })
		}
	}
	const times = sim.starFrames.map((f) => f.t)
	let changed = 0
	let maxRate = 0
	let maxStep = 0
	for (const [key, list] of series) {
		const before = list.filter((s) => s.t < shiftT - 1e-9)
		if (before.length < 2 || before.some((s) => Math.abs(s.alpha - before[0].alpha) > 1e-9)) continue
		// A star's own alpha with no copy near it is the most it is ever drawn at: steps are measured against that (before the message it may already be dimmed)
		const base = Math.max(...list.map((s) => s.alpha))
		if (base < 0.05) continue
		const start = before[0].alpha
		const at = new Map(list.map((s) => [s.t, s.alpha]))
		let previous = start
		let previousT = null
		let low = start
		let high = start
		for (const t of times) {
			if (t < shiftT - 1e-9) continue
			const alpha = at.get(t) ?? 0
			low = Math.min(low, alpha)
			high = Math.max(high, alpha)
			if (previousT !== null && t - previousT > 1e-6) {
				// a star that drops under the draw threshold (or comes over it) changes by a few levels of 255 in one frame: not a step anyone sees
				if (Math.max(alpha, previous) >= VISIBLE_ALPHA) {
					const rate = Math.abs(alpha - previous) / base / (t - previousT)
					if (process.env.DEBUG_W2 && rate > 3) console.log('DEBUG star', key, 'peak', base.toFixed(4), 't', (t - shiftT).toFixed(3), 'dt', (t - previousT).toFixed(4), 'prev', previous.toFixed(4), 'alpha', alpha.toFixed(4), 'series', list.filter((s) => s.t >= shiftT - 0.05).map((s) => (s.t - shiftT).toFixed(3) + ':' + s.alpha.toFixed(4)).join(' '))
					maxRate = Math.max(maxRate, rate)
					maxStep = Math.max(maxStep, Math.abs(alpha - previous) / base)
				}
			}
			previous = alpha
			previousT = t
		}
		if (high - low > 0.05 * base) changed++
	}
	return { maxRatio, worstExcess, onCopyFrames, exceeding, maxRise, maxJump, changed, maxRate, maxStep, riseAt }
}

console.log(`${label}: copy shifted by 10-20 px (${VECTORS.length} vectors) with the message ${LEADS.join(' / ')} s before the head reaches the copy${HELD ? ', held behind an unrelated 1 px re-measure 100 ms earlier' : ''}; ${PASSES} passing flights per tree; window ${WINDOW_S} s; clean ease rate ${EASE_RATE.toFixed(2)} per second\n`)
let failures = 0
for (const tree of TREES) {
	const seeds = await seedsWithPass(tree, PASSES)
	let runs = 0
	let usable = 0
	let exceedingRuns = 0
	let worst = 0
	let worstExcess = -Infinity
	let totalExceedFrames = 0
	let onCopyFrames = 0
	let worstJump = 0
	let pop = 0
	let maxEffect = 0
	let starsChanged = 0
	let starRate = 0
	let starStep = 0
	let starRuns = 0
	for (const entry of seeds) {
		const controls = new Map()
		for (const lead of LEADS) controls.set(lead, await run(tree, entry, [0, 0], lead))
		for (const vector of VECTORS) {
			for (const lead of LEADS) {
				const r = await run(tree, entry, vector, lead)
				runs++
				if (!r) continue
				// what the message did to the head: its white with the shift minus its white in the control run, per frame; the pop is that difference's largest one-frame change
				const control = controls.get(lead)
				if (control) {
					let before = 0
					for (const [key, rise] of [...r.riseAt].sort((a, b) => a[0] - b[0])) {
						const base = control.riseAt.get(key)
						if (base === undefined) continue
						const effect = rise - base
						pop = Math.max(pop, Math.abs(effect - before))
						maxEffect = Math.max(maxEffect, Math.abs(effect))
						before = effect
					}
				}
				if (r.onCopyFrames >= 3) usable++
				if (r.exceeding > 0) exceedingRuns++
				worst = Math.max(worst, r.maxRatio)
				worstExcess = Math.max(worstExcess, r.worstExcess)
				totalExceedFrames += r.exceeding
				onCopyFrames += r.onCopyFrames
				worstJump = Math.max(worstJump, r.maxJump)
				if (r.changed > 0) starRuns++
				starsChanged += r.changed
				starRate = Math.max(starRate, r.maxRate)
				starStep = Math.max(starStep, r.maxStep)
			}
		}
	}
	console.log(`${tree.padEnd(5)} ${seeds.length} passing flights x ${VECTORS.length} shifts x ${LEADS.length} timings = ${runs} runs (${usable} with the head on the new copy for 3 frames or more, ${onCopyFrames} frames on copy in all)`)
	console.log(`      W1  runs with a head pixel above its copy's budget during the ease: ${exceedingRuns} (${totalExceedFrames} frames); worst head white / budget ${worst.toFixed(4)} (largest excess ${worstExcess.toFixed(5)} of white); largest one-frame change of the head's white ${worstJump.toFixed(3)} (the flight's own light curve included)`)
	console.log(`      pop  what the message itself does to the head's white, against a control run of the same flight with no message: at most ${maxEffect.toFixed(3)} of white, and ${pop.toFixed(3)} of white in one frame`)
	console.log(`      W2  stars that changed with the shift: ${starsChanged} (in ${starRuns} runs); fastest star change ${starRate.toFixed(2)} of its alpha per second (clean ease ${EASE_RATE.toFixed(2)}), largest step between two frames ${starStep.toFixed(3)} of its alpha`)
	if (tree === 'proto') {
		if (exceedingRuns > 0 || worstExcess > TOLERANCE) {
			console.log('      FAIL W1')
			failures++
		}
		if (usable < 50) {
			console.log('      FAIL W1 is vacuous: too few runs had the head on the copy')
			failures++
		}
		if (starsChanged === 0 || starRate > EASE_RATE * 1.15 || (!HELD && starStep > 0.06)) {
			console.log('      FAIL W2')
			failures++
		}
	}
}
console.log(failures ? `\nFAILED (${failures})` : HELD ? '\nW (held) holds: no head pixel above the shifted copy\'s budget while the shift waits' : '\nW holds: no head pixel above its copy\'s budget during the ease, and the stars cross-fade')
process.exitCode = failures ? 1 : 0
