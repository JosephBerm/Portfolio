// Check 11 capture: one first flight per visit on the real page (dev server, own headless Chromium, the real Turbopack worker bundle with
// the observation hook of live-lib.mjs). Per visit: the quiet copy's lines (DOM), the page's posts, every planMeteor call and every drawMeteor
// frame the worker made (inputs, and the sprite and gradient calls it drew), the long main-thread tasks, console and worker errors, and the
// pixels: per frame the largest R+G+B rise over the sky-only baseline inside every text rect and its lowest WCAG contrast.
//   node live-flights.mjs <spec> <visits> [parallel=4] [tag=a]        spec: 1440x900@1 | 1280x800@1 | 390x844@3m ...
// Env: START (first visit number, default 1), EVIDENCE (PNG evidence for at most this many pass-A flights, default 6), WAIT_S (seconds after the reveal).
import fs from 'node:fs'
import path from 'node:path'
import { launch, newVisitContext, openHome, posts, pageEpoch, sleep, waitFor, measureLines, parseColor, parseSpec, pool, OUT, LONGTASK_INIT } from './live-lib.mjs'

const spec = parseSpec(process.argv[2] ?? '1440x900@1')
const visits = Number(process.argv[3] ?? 4)
const parallel = Number(process.argv[4] ?? 4)
const tag = process.argv[5] ?? 'a'
const first = Number(process.env.START ?? 1)
const waitS = Number(process.env.WAIT_S ?? (spec.mobile ? 45 : 18))
const evidenceMax = Number(process.env.EVIDENCE ?? 6)
const dir = path.join(OUT, `flights-${spec.name}-${tag}`)
fs.mkdirSync(dir, { recursive: true })
let evidence = 0

async function visit(browser, n) {
	const label = `v${String(n).padStart(3, '0')}`
	const { context, stats } = await newVisitContext(browser, spec)
	const record = { label, spec: spec.name }
	try {
		const { page, worker, init, logs } = await openHome(context)
		record.init = { dpr: init.dpr, width: init.width, height: init.height, motion: init.motion, scrollY: init.scrollY, at: init.at }
		record.chunk = stats
		await worker.evaluate(() => {
			self.__live.capture = true
			self.__live.outputs = true
		})
		const reveal = await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 60000, 'reveal')
		record.revealAt = reveal.at
		while ((await pageEpoch(page)) < reveal.at + 2000) await sleep(40)
		const measured = await measureLines(page)
		record.lines = measured.lines.map((l) => ({ ...l, rgb: parseColor(l.color) }))
		record.deviceMemory = measured.deviceMemory
		let firstAt = null
		while (!firstAt && (await pageEpoch(page)) < reveal.at + waitS * 1000) {
			firstAt = await worker.evaluate(() => (self.__live.frames.length ? self.__live.frames[0].at : null))
			if (!firstAt) await sleep(100)
		}
		if (firstAt) {
			for (;;) {
				await sleep(150)
				const [last, now] = await worker.evaluate(() => [self.__live.frames.at(-1).at, performance.timeOrigin + performance.now()])
				if (now - last > 1400 || now - firstAt > 9000) break
			}
			await waitFor(() => worker.evaluate(() => self.__live.pending === 0), 20000, 'copies')
			const texts = record.lines.map((l) => ({ x: l.x, y: l.y, w: l.w, h: l.h, rgb: l.rgb }))
			record.pixels = await worker.evaluate(([i, t]) => self.__live.analyze(i, t, true), [0, texts])
			// PNG evidence for pass-A flights (a rect pixel lit by 87 of 726 or more for six frames or more)
			const lit = record.pixels.filter((f) => f.rect.some((r) => r >= 87)).length
			if (lit >= 6 && evidence < evidenceMax) {
				evidence++
				const best = record.pixels.reduce((a, f) => (Math.max(...f.rect) > Math.max(...a.rect) ? f : a))
				record.evidence = []
				for (const [name, k, gain] of [['raw', best.k, 1], ['x4', best.k, 4], ['base', -1, 1]]) {
					const png = await worker.evaluate(([i, kk, g]) => self.__live.png(i, kk, g), [0, k, gain])
					const file = `${label}-${name}.png`
					fs.writeFileSync(path.join(dir, file), Buffer.from(png, 'base64'))
					record.evidence.push({ name, file, k, time: best.time })
				}
			}
		}
		record.dump = await worker.evaluate(() => self.__live.dump())
		record.posts = (await posts(page)).map((p) => (p.type === 'layout' ? { type: p.type, at: p.at, documentHeight: p.documentHeight, quiet: p.quiet, pinned: p.pinned } : { type: p.type, at: p.at, y: p.y, width: p.width, height: p.height, dpr: p.dpr }))
		record.long = (await page.evaluate((from) => window.__long.filter((e) => e.at >= from), reveal.at)).map((e) => ({ at: e.at, ms: e.ms }))
		record.canvasReady = await page.evaluate(() => !!document.querySelector('canvas[data-ready]'))
		record.logs = logs
		record.endedAt = await pageEpoch(page)
		const frames = record.dump.frames.length
		console.log(`${spec.name} ${label}: first flight +${firstAt ? ((firstAt - reveal.at) / 1000).toFixed(2) : '-'} s, ${frames} frames, plans ${record.dump.plans.length}, long tasks ${record.long.length}, logs ${logs.length}${record.dump.errors.length ? ', worker errors ' + record.dump.errors.join('|') : ''}${record.evidence ? ', evidence saved' : ''}`)
	} catch (error) {
		record.failed = String(error && error.message ? error.message : error).slice(0, 300)
		console.log(`${spec.name} ${label}: FAILED ${record.failed}`)
	} finally {
		fs.writeFileSync(path.join(dir, `${label}.json`), JSON.stringify(record))
		await context.close().catch(() => {})
	}
	return record
}

const browser = await launch()
const started = Date.now()
try {
	const tasks = Array.from({ length: visits }, (_, i) => () => visit(browser, first + i))
	const records = await pool(tasks, parallel)
	const flown = records.filter((r) => r.dump?.frames?.length).length
	console.log(`\n${spec.name}: ${visits} visits, ${flown} with a flight, ${records.filter((r) => r.failed).length} failed, ${((Date.now() - started) / 1000).toFixed(0)} s`)
} finally {
	await browser.close()
}
