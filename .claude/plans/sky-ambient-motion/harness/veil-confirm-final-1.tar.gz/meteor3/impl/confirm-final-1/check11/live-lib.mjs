// Shared helpers of the live checks (own headless Chromium through playwright-core, the dev server at localhost:3000, observation only).
// The sky worker's chunk is served through a route handler that puts worker-hook.js in front of it and wraps planMeteor and drawMeteor (patchChunk),
// so the real worker records what it plans and draws; nothing about what it draws changes.
import fs from 'node:fs'
import path from 'node:path'
import { launch, PAGE_INIT, posts, pageEpoch, sleep, waitFor, skyWorkerOf, parseSpec, parseColor } from '../../../live-capture/lib.mjs'

export { launch, PAGE_INIT, posts, pageEpoch, sleep, waitFor, skyWorkerOf, parseSpec, parseColor }
export const LIVE = 'C:/Users/josep/AppData/Local/Temp/claude/S--Documents-repos-Portfolio/f159339c-8cb2-444a-916b-251e57be791d/scratchpad/starfield/meteor3/impl/confirm-final-1/check11'
export const OUT = path.join(LIVE, 'out')
fs.mkdirSync(OUT, { recursive: true })
export const TARGET = process.env.TARGET ?? 'http://localhost:3000/'

const HOOK = fs.readFileSync(path.join(LIVE, 'worker-hook.js'), 'utf8')
const PLAN_HEAD = 'function planMeteor(random, field, radiant, now, options = {}) {'
const DRAW_HEAD = 'function drawMeteor(ctx, assets, meteor, frame, fade = 1) {'
const PICK_HEAD = 'function pickRadiant(random, width, height) {'

/**
 * The worker chunk with the hook in front and the two wrappers, or null for any other chunk. The unwrapped planMeteor, pickRadiant and drawMeteor
 * are registered in self.__live.orig when their modules run (function declarations are hoisted, so the statement before each may name it).
 */
export function patchChunk(text) {
	if (!text.includes(PLAN_HEAD) || !text.includes(DRAW_HEAD) || !text.includes(PICK_HEAD)) return null
	return (
		HOOK +
		';\n' +
		text
			.replace(PLAN_HEAD, 'self.__live.orig.plan = __planMeteor0;\nfunction planMeteor(...a) { return self.__live.plan(__planMeteor0, a) }\nfunction __planMeteor0(random, field, radiant, now, options = {}) {')
			.replace(DRAW_HEAD, 'self.__live.orig.draw = __drawMeteor0;\nfunction drawMeteor(...a) { return self.__live.draw(__drawMeteor0, a) }\nfunction __drawMeteor0(ctx, assets, meteor, frame, fade = 1) {')
			.replace(PICK_HEAD, 'self.__live.orig.pick = pickRadiant;\n' + PICK_HEAD)
	)
}

/** Routes the sky worker's chunk through patchChunk for every page of the context. Returns counters. */
export async function hookWorkerChunk(context) {
	const stats = { patched: 0, seen: 0 }
	await context.route(/\/_next\/static\/chunks\/src_[^/]*\.js(\?.*)?$/, async (route) => {
		stats.seen++
		const response = await route.fetch()
		const text = await response.text()
		const patched = patchChunk(text)
		if (patched) stats.patched++
		const body = patched ?? text
		// The body changed size: the original content-length (and any encoding) no longer describes it
		const headers = { ...response.headers() }
		delete headers['content-encoding']
		delete headers['transfer-encoding']
		headers['content-length'] = String(Buffer.byteLength(body))
		await route.fulfill({ status: response.status(), headers, body })
	})
	return stats
}

export const LONGTASK_INIT = `(() => { window.__long = []; try { new PerformanceObserver((list) => { for (const e of list.getEntries()) window.__long.push({ at: performance.timeOrigin + e.startTime, ms: e.duration }) }).observe({ type: 'longtask', buffered: true }) } catch {} })()`

/** The quiet copy's text lines and the boxes of its links and buttons, with their computed color, size and weight (the page's DOM, scroll offset 0 unless noted). */
export async function measureLines(page) {
	return page.evaluate(() => {
		const out = []
		let id = 0
		for (const root of document.querySelectorAll('[data-sky-quiet]')) {
			const fixed = getComputedStyle(root).position === 'fixed'
			const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
			const range = document.createRange()
			for (let n = walker.nextNode(); n; n = walker.nextNode()) {
				if (!n.textContent.trim()) continue
				range.selectNodeContents(n)
				const el = n.parentElement
				const cs = getComputedStyle(el)
				for (const r of range.getClientRects()) {
					if (!r.width || !r.height || r.bottom < 0 || r.top > innerHeight) continue
					out.push({ id: id++, text: n.textContent.trim().replace(/\s+/g, ' ').slice(0, 40), tag: el.tagName, color: cs.color, size: parseFloat(cs.fontSize), weight: Number(cs.fontWeight), x: r.left, y: r.top, w: r.width, h: r.height, fixed })
				}
			}
			for (const c of root.querySelectorAll('a, button')) {
				const r = c.getBoundingClientRect()
				if (!r.width || !r.height || r.bottom < 0 || r.top > innerHeight) continue
				const cs = getComputedStyle(c)
				out.push({ id: id++, text: '[box] ' + c.textContent.trim().slice(0, 30), tag: c.tagName, color: cs.color, size: parseFloat(cs.fontSize), weight: Number(cs.fontWeight), x: r.left, y: r.top, w: r.width, h: r.height, fixed, box: true })
			}
		}
		return { lines: out, scrollY, inner: [innerWidth, innerHeight], deviceMemory: navigator.deviceMemory, cores: navigator.hardwareConcurrency }
	})
}

/** WCAG 2 minimum contrast for text of this computed size and weight (mirrors minimumContrast in color.ts, for the scorer only). */
export function minimumContrast(size, weight) {
	return size >= 24 || (size >= 18.66 && weight >= 700) ? 3 : 4.5
}

/** A fresh context for one visit: the page's posts logged, long tasks observed, the worker chunk hooked. */
export async function newVisitContext(browser, spec, { reducedMotion = 'no-preference', forcedColors = 'none', hook = true, colorScheme } = {}) {
	const context = await browser.newContext({ viewport: { width: spec.width, height: spec.height }, deviceScaleFactor: spec.dsf, isMobile: spec.mobile, hasTouch: spec.mobile, reducedMotion, forcedColors, ...(colorScheme ? { colorScheme } : {}) })
	await context.addInitScript(PAGE_INIT)
	await context.addInitScript(LONGTASK_INIT)
	const stats = hook ? await hookWorkerChunk(context) : { patched: 0, seen: 0 }
	return { context, stats }
}

/** Opens the home page in `context` and waits for the sky worker and its init post. */
export async function openHome(context, { timeout = 120000 } = {}) {
	const page = await context.newPage()
	const logs = []
	// Motion's own development warning that reduced motion is on is the page agreeing with the emulation, not an error
	page.on('console', (m) => (m.type() === 'error' || m.type() === 'warning') && !/Reduced Motion enabled/.test(m.text()) && logs.push('page ' + m.type() + ': ' + m.text().slice(0, 300)))
	page.on('pageerror', (e) => logs.push('pageerror: ' + e.message.slice(0, 300)))
	const workers = []
	page.on('worker', (w) => {
		workers.push(w)
		w.on('console', (m) => (m.type() === 'error' || m.type() === 'warning') && logs.push('worker ' + m.type() + ': ' + m.text().slice(0, 300)))
	})
	await page.goto(TARGET, { waitUntil: 'load', timeout })
	const worker = await waitFor(() => skyWorkerOf(workers), 30000, 'sky worker')
	const init = await waitFor(async () => (await posts(page)).find((p) => p.type === 'init'), 30000, 'init post')
	return { page, worker, init, logs, workers }
}

export const median = (xs) => {
	const s = [...xs].sort((a, b) => a - b)
	return s.length ? (s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2) : null
}

/** Runs `tasks` (async functions) with at most `limit` at a time; results in task order. */
export async function pool(tasks, limit) {
	const results = new Array(tasks.length)
	let next = 0
	const run = async () => {
		for (;;) {
			const i = next++
			if (i >= tasks.length) return
			results[i] = await tasks[i]()
		}
	}
	await Promise.all(Array.from({ length: Math.min(limit, tasks.length) }, run))
	return results
}
