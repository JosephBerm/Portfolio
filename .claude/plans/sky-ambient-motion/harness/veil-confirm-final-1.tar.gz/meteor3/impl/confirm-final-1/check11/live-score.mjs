// Scores the live flights captured by live-flights.mjs (check 11 and the live parts of checks 5, 6, 15, 17):
//   node live-score.mjs <spec> <tag> [tag...]       e.g. 1440x900@1 a b
// Per flight: when it launched; the pixels (lit by 87 of 726 for 0.1 s: level A, by 30: level B; the lowest contrast and the brightest rise
// per copy against its budget); the planned flight and the zones the worker really used, scored with the plan's own metrics (pass, edge fade
// as check-e.mjs does); and an exact replay: the repository's drawMeteor (impl/pure/proto) run on the recorded inputs of every frame must
// produce the sprite and gradient calls the real worker bundle recorded.
import fs from 'node:fs'
import path from 'node:path'
import { P, walkProto } from '../lib.mjs'
import { drawMeteor } from '../pure/proto/components-sky/renderSky.mjs'
import { starPalette } from '../pure/proto/components-sky/skyAssets.mjs'
import { OUT, median } from './live-lib.mjs'

const [specName, ...tags] = process.argv.slice(2)
const dirs = tags.map((tag) => path.join(OUT, `flights-${specName}-${tag}`))
const TOKENS = { navy: [10, 25, 47], white: [230, 241, 255], green: [100, 255, 218], card2: [60, 103, 227], card3: [78, 0, 194] }
const SUM = TOKENS.white[0] + TOKENS.white[1] + TOKENS.white[2]
const { edgeBright, edgeKept } = P.METEOR_VEIL
const { glimmer, dwell, visible } = P.METEOR_PASS
const LEVEL_A = 87
const LEVEL_B = 30
const STEPS = 400

/** What kind of copy a measured line is (by its color and size, as lib.mjs kindOf does for the captures). */
function kindOf(line) {
	const c = line.color
	if (c === 'rgb(204, 214, 246)') return line.size >= 24 ? 'name' : 'lightest small'
	if (c === 'rgb(136, 146, 176)') return line.size >= 24 ? 'tagline' : 'paragraph'
	if (c === 'rgb(100, 255, 218)') return line.size >= 24 ? 'green large' : 'green small'
	if (c === 'rgb(168, 178, 209)') return 'light slate'
	return 'other ' + c
}

/** The posted rect (with its headroom) a measured line belongs to. */
function headroomOf(line, layout) {
	if (!layout) return null
	const list = line.fixed ? layout.pinned : layout.quiet
	const near = (a, b) => Math.abs(a - b) <= 1.5
	const hit = list.find((r) => near(r.x, line.x) && near(r.y, line.y) && near(r.width, line.w) && near(r.height, line.h))
	return hit ? hit.headroom : null
}

/** Seconds of the frames (each worth the gap to the next one, at most a 30 fps frame) for which `lit(frame)` holds. */
function litSeconds(frames, lit) {
	let seconds = 0
	for (let i = 0; i < frames.length; i++) {
		if (!lit(frames[i])) continue
		const gap = i + 1 < frames.length ? frames[i + 1].time - frames[i].time : 1 / 60
		seconds += Math.min(gap, 1 / 30)
	}
	return seconds
}

/** The planner's metrics for the flight the worker really flew, on the zones it really had (check-e.mjs's score). */
function modelScore(meteor, zones, ink) {
	const walk = walkProto(meteor, zones, STEPS, ink)
	const dt = meteor.duration / STEPS
	let faded = false
	let on = 0
	let on12 = 0
	let minKept = 1
	let peakWhite = 0
	let onCopyMax = 0
	for (const s of walk) {
		if (s.white >= edgeBright && s.kept <= edgeKept) faded = true
		if (s.onCopy && s.rise >= glimmer) on++
		if (s.onCopy && s.rise >= visible) on12++
		if (s.onCopy) onCopyMax = Math.max(onCopyMax, s.rise)
		minKept = Math.min(minKept, s.kept)
		peakWhite = Math.max(peakWhite, s.white)
	}
	const pass = on * dt >= dwell
	return { faded, pass, edge: faded && !pass, pass12: on12 * dt >= dwell, onSeconds: on * dt, minKept, peakWhite, onCopyMax }
}

/** A recording context: the sprite and gradient calls drawMeteor makes, in the form the hook records them. */
function recorder() {
	const record = { draws: [], grads: [] }
	const ctx = {
		globalAlpha: 1,
		globalCompositeOperation: 'source-over',
		drawImage(...b) {
			record.draws.push([b[1], b[2], b[3], b[4], Math.round(b[5] * 1e4) / 1e4, Math.round(b[6] * 1e4) / 1e4, this.globalAlpha])
		},
		createLinearGradient(...b) {
			const stops = []
			record.grads.push({ at: b, stops })
			return { addColorStop: (o, c) => stops.push([o, c]) }
		},
		beginPath() {},
		moveTo() {},
		lineTo() {},
		closePath() {},
		fill() {},
		stroke() {},
	}
	return { ctx, record }
}

/** Largest difference between what the real worker recorded for a frame and what the repository's drawMeteor draws from the same inputs. */
function replayGap(record, flight, frame, zones, dpr, assets) {
	const { ctx, record: replay } = recorder()
	const blend = { from: zones.from, to: zones.to, level: frame.level }
	drawMeteor(ctx, assets, flight, { time: frame.time, width: assets.width, height: assets.height, dpr, deviceWidth: assets.width * dpr, deviceHeight: assets.height * dpr, quiet: blend, meteorInk: 1 }, frame.fade)
	const live = frame.record
	if (!live) return null
	let gap = 0
	let structural = live.draws.length !== replay.draws.length || live.grads.length !== replay.grads.length
	for (let i = 0; i < Math.min(live.draws.length, replay.draws.length); i++) for (let k = 0; k < 7; k++) gap = Math.max(gap, Math.abs(live.draws[i][k] - replay.draws[i][k]))
	const alphaOf = (color) => Number(/,\s*([\d.]+)\)$/.exec(color)?.[1] ?? NaN)
	for (let i = 0; i < Math.min(live.grads.length, replay.grads.length); i++) {
		const a = live.grads[i]
		const b = replay.grads[i]
		if (a.stops.length !== b.stops.length) structural = true
		for (let k = 0; k < 4; k++) gap = Math.max(gap, Math.abs(a.at[k] - b.at[k]))
		for (let s = 0; s < Math.min(a.stops.length, b.stops.length); s++) {
			gap = Math.max(gap, Math.abs(alphaOf(a.stops[s][1]) - alphaOf(b.stops[s][1])))
			if (a.stops[s][1].replace(/[\d.]+\)$/, '') !== b.stops[s][1].replace(/[\d.]+\)$/, '')) structural = true
		}
	}
	return { gap, structural }
}

function scoreVisit(r) {
	const out = { label: r.label, failed: r.failed ?? null, flown: false }
	if (r.failed || !r.dump) return out
	const d = r.dump
	out.logs = r.logs
	out.workerErrors = d.errors
	out.long = r.long.length
	out.longMax = r.long.length ? Math.max(...r.long.map((e) => e.ms)) : 0
	out.beats = d.beats.length
	out.canvasReady = r.canvasReady
	out.layoutPosts = r.posts.filter((p) => p.type === 'layout').map((p) => [Math.round(p.at - r.revealAt), p.quiet.length, p.pinned.length])
	if (!d.frames.length) return out
	out.flown = true
	const frames = d.frames
	const meteor = d.meteors[0]
	out.launchAfterReveal = (frames[0].at - r.revealAt) / 1000
	out.kind = meteor.fireball ? 'fireball' : meteor.flare ? 'flare' : meteor.train ? 'train' : 'plain'
	out.path = meteor.length
	out.duration = meteor.duration
	out.peak = meteor.peak
	out.nearCopy = meteor.nearCopy
	out.flights = d.meteors.length
	out.frames = frames.length
	out.zoneVersions = d.zones.length
	// The plan: the last call that returned this flight
	const plan = [...d.plans].reverse().find((p) => p.meteor && p.meteor.startedAt === meteor.startedAt)
	out.planMs = plan?.ms ?? null
	out.planCalls = d.plans.length
	out.fallbackFlight = plan?.options?.flights === 'short'
	const layout = [...r.posts].reverse().find((p) => p.type === 'layout' && p.quiet.length)
	if (plan) out.model = modelScore(meteor, plan.zones, plan.options.ink ?? 1)
	// Gaps between the frames while the shooting star moves (the worker's animation-frame phase: the flight and its wake; the lingering train
	// is drawn from a 30 fps timer, whose own jitter is not a long frame)
	const flightFrames = frames.filter((f) => f.time - meteor.startedAt <= meteor.duration + P.METEOR.wakeSpan * meteor.wake)
	const gaps = flightFrames.slice(1).map((f, i) => (f.time - flightFrames[i].time) * 1000).filter((g) => g > 2)
	out.frameGapMax = gaps.length ? Math.max(...gaps) : 0
	out.frameGapMedian = median(gaps)
	out.slowFrames = gaps.filter((g) => g > 50).length
	out.droppedFrames = gaps.filter((g) => g > 33.4).length
	// Worker stalls (an event-loop gap over 60 ms) that overlap the shooting star's frames; the ones after it are the pixel analysis of this harness
	const windowStart = frames[0].at
	const windowEnd = flightFrames.at(-1).at
	out.stallsInFlight = d.beats.filter(([at, ms]) => at + ms >= windowStart && at <= windowEnd).length
	out.stallsAfter = d.beats.filter(([at]) => at > windowEnd).length
	out.stallsBefore = d.beats.filter(([at, ms]) => at + ms < windowStart).length
	out.drawMsMedian = median(d.drawMs)
	out.drawMsMax = Math.max(...d.drawMs)
	// Pixels
	const px = r.pixels ?? []
	const lines = r.lines
	const lit = (level) => (f) => f.rect.some((v) => v >= level)
	out.litA = litSeconds(px, lit(LEVEL_A))
	out.litB = litSeconds(px, lit(LEVEL_B))
	out.framesA = px.filter(lit(LEVEL_A)).length
	out.framesB = px.filter(lit(LEVEL_B)).length
	// 0.1 s of lit time, allowing a quarter frame (the same frames, 6 of 60 fps, in a 60 Hz run)
	out.passA = out.litA >= dwellSeconds
	out.passB = out.litB >= dwellSeconds
	out.anyLit = litSeconds(px, (f) => f.any >= LEVEL_B)
	out.copyLit = litSeconds(px, lit(LEVEL_B))
	// Per copy: lowest contrast and brightest rise against the budget
	out.copy = {}
	lines.forEach((line, j) => {
		const kind = kindOf(line)
		const worst = Math.min(...px.map((f) => f.contrast[j] ?? Infinity))
		const rise = Math.max(0, ...px.map((f) => f.rect[j]))
		const headroom = headroomOf(line, layout)
		const budget = headroom === null ? null : P.inkBudget(headroom) * SUM
		const c = (out.copy[kind] ??= { min: Infinity, rise: 0, ratio: 0, minimum: 4.5, rects: 0, lit: 0 })
		c.rects++
		c.minimum = Math.min(c.minimum, line.size >= 24 || (line.size >= 18.66 && line.weight >= 700) ? 3 : 4.5)
		if (Number.isFinite(worst)) {
			c.min = Math.min(c.min, worst)
			c.lit++
		}
		c.rise = Math.max(c.rise, rise)
		if (budget) c.ratio = Math.max(c.ratio, rise / budget)
		else if (rise > 0 && budget === 0) c.ratio = Math.max(c.ratio, Infinity)
	})
	// Exact replay of every recorded frame
	const first = frames.find((f) => f.record && f.record.draws.length === 2)
	if (first) {
		const [glow, core] = first.record.draws
		const assets = { atlas: { image: null, meteorGlow: { x: glow[0], y: glow[1], size: glow[2] }, meteorCore: { x: core[0], y: core[1], size: core[2] } }, tokens: TOKENS, palette: starPalette(TOKENS), width: r.init.width, height: r.init.height }
		let worst = 0
		let structural = 0
		let compared = 0
		for (const f of frames) {
			const zones = d.zones[f.zones]
			const res = replayGap(f.record, d.meteors[f.meteor], f, zones, r.init.dpr, assets)
			if (!res) continue
			compared++
			worst = Math.max(worst, res.gap)
			if (res.structural) structural++
		}
		out.replay = { compared, worst, structural }
	}
	return out
}

const dwellSeconds = P.METEOR_PASS.dwell - 0.004

const results = []
for (const dir of dirs) {
	if (!fs.existsSync(dir)) continue
	for (const f of fs.readdirSync(dir).filter((x) => /^v\d+\.json$/.test(x)).sort()) {
		const record = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'))
		results.push({ dir: path.basename(dir), ...scoreVisit(record) })
	}
}
const flown = results.filter((r) => r.flown)
const pc = (n, d) => `${n} of ${d} (${((100 * n) / Math.max(1, d)).toFixed(1)}%)`
console.log(`${specName} [${tags.join(',')}]: ${results.length} visits, ${results.filter((r) => r.failed).length} failed, ${flown.length} with a flight`)
console.log(`first flight after the reveal: ${median(flown.map((r) => r.launchAfterReveal))?.toFixed(2)} s median, ${Math.min(...flown.map((r) => r.launchAfterReveal)).toFixed(2)}-${Math.max(...flown.map((r) => r.launchAfterReveal)).toFixed(2)} s`)
const A = flown.filter((r) => r.passA).length
const B = flown.filter((r) => r.passB).length
console.log(`level A (a text-rect pixel lit by >= ${LEVEL_A} of 726 for ${dwellSeconds.toFixed(3)} s): ${pc(A, flown.length)}`)
console.log(`level B (>= ${LEVEL_B}): ${pc(B, flown.length)}`)
console.log(`   by whole frames (6 or more): A ${flown.filter((r) => r.framesA >= 6).length}, B ${flown.filter((r) => r.framesB >= 6).length}`)
console.log(`model (the planned flights on the zones the worker held, 400 moments): pass@.04 ${pc(flown.filter((r) => r.model?.pass).length, flown.length)}, pass@.12 ${pc(flown.filter((r) => r.model?.pass12).length, flown.length)}`)
const edge = flown.filter((r) => r.model?.edge)
const edgePixels = edge.filter((r) => !r.passB)
console.log(`edge fades (model, check-e metric): ${pc(edge.length, flown.length)}; of those the pixels also show no glimmer (level B): ${pc(edgePixels.length, flown.length)}`)
console.log(`kinds: ${['plain', 'fireball', 'flare', 'train'].map((k) => `${k} ${flown.filter((r) => r.kind === k).length}`).join(', ')}; nearCopy ${flown.filter((r) => r.nearCopy).length}; fallback (short) flights ${flown.filter((r) => r.fallbackFlight).length}; path median ${median(flown.map((r) => r.path))?.toFixed(0)} px; duration median ${median(flown.map((r) => r.duration))?.toFixed(2)} s`)
const onCopy = flown.filter((r) => r.passB)
console.log(`time lit on copy (level B), flights that pass: median ${median(onCopy.map((r) => r.litB))?.toFixed(2)} s; level A passes: median ${median(flown.filter((r) => r.passA).map((r) => r.litA))?.toFixed(2)} s`)
// Readability per kind of copy over every flight
const kinds = {}
for (const r of flown) {
	for (const [kind, c] of Object.entries(r.copy ?? {})) {
		const k = (kinds[kind] ??= { min: Infinity, rise: 0, ratio: 0, minimum: c.minimum, flights: 0 })
		k.min = Math.min(k.min, c.min)
		k.rise = Math.max(k.rise, c.rise)
		k.ratio = Math.max(k.ratio, c.ratio)
		if (c.lit) k.flights++
	}
}
console.log('lowest contrast of each kind of copy against the pixels a flight lit (AA minimum), brightest rise (R+G+B of 726) and its share of the budget, flights that lit it:')
for (const [kind, k] of Object.entries(kinds)) console.log(`  ${kind.padEnd(14)} min ${Number.isFinite(k.min) ? k.min.toFixed(2) : '-'} (AA ${k.minimum})  rise ${k.rise}  budget share ${Number.isFinite(k.ratio) ? k.ratio.toFixed(3) : 'inf'}  flights ${k.flights}`)
const replays = flown.filter((r) => r.replay)
console.log(`replay of drawMeteor on the recorded inputs against the real worker's sprite and gradient calls: ${replays.length} flights, ${replays.reduce((a, r) => a + r.replay.compared, 0)} frames, worst difference ${Math.max(0, ...replays.map((r) => r.replay.worst)).toExponential(2)}, structural mismatches ${replays.reduce((a, r) => a + r.replay.structural, 0)}`)
console.log(`plans: ${results.filter((r) => r.planCalls).reduce((a, r) => a + r.planCalls, 0)} planMeteor calls, ms median ${median(flown.map((r) => r.planMs).filter((v) => v !== null))?.toFixed(3)}; drawMeteor JS median of medians ${median(flown.map((r) => r.drawMsMedian))?.toFixed(4)} ms, worst ${Math.max(0, ...flown.map((r) => r.drawMsMax)).toFixed(3)} ms`)
console.log(`long main-thread tasks after the reveal: ${results.reduce((a, r) => a + (r.long ?? 0), 0)} (longest ${Math.max(0, ...results.map((r) => r.longMax ?? 0)).toFixed(0)} ms)`)
console.log(`worker stalls over 60 ms: during a flight ${flown.reduce((a, r) => a + r.stallsInFlight, 0)}, before it ${flown.reduce((a, r) => a + r.stallsBefore, 0)}, after it ${flown.reduce((a, r) => a + r.stallsAfter, 0)} (those are this harness reading the pixels back)`)
console.log(`animation-frame phase of the flights: frames more than 50 ms apart ${flown.reduce((a, r) => a + r.slowFrames, 0)}, more than 33 ms apart ${flown.reduce((a, r) => a + r.droppedFrames, 0)} of ${flown.reduce((a, r) => a + r.frames, 0)} frames (max gap ${Math.max(0, ...flown.map((r) => r.frameGapMax)).toFixed(0)} ms, median ${median(flown.map((r) => r.frameGapMedian))?.toFixed(1)} ms)`)
console.log(`logs (console, page, worker): ${results.reduce((a, r) => a + (r.logs?.length ?? 0), 0)}; worker hook errors: ${results.reduce((a, r) => a + (r.workerErrors?.length ?? 0), 0)}; canvas not ready: ${results.filter((r) => r.canvasReady === false).length}; layouts changed mid-flight: ${flown.filter((r) => r.zoneVersions > 1).length}`)
const withRects = results.map((r) => (r.layoutPosts ?? []).filter((p) => p[1] + p[2] > 0))
const firstMs = withRects.map((l) => l[0]?.[0]).filter((v) => v !== undefined)
console.log(`layout messages that carry rects: ${withRects.reduce((a, l) => a + l.length, 0)} over ${results.length} visits (visits with more than one: ${withRects.filter((l) => l.length > 1).length}); the first arrives ${Math.min(...firstMs)}-${Math.max(...firstMs)} ms after the reveal (median ${median(firstMs)} ms); rects in it: ${[...new Set(withRects.map((l) => l[0]?.[1] + '+' + l[0]?.[2]))].join(', ')}`)
fs.writeFileSync(path.join(OUT, `score-${specName}-${tags.join('+')}.json`), JSON.stringify({ spec: specName, tags, results }, null, 1))
// Binomial thresholds (impl/binomial.mjs): the 5% lower bounds of the rendered rates
const N = flown.length
console.log(`\nflown N = ${N}: A ${A}, B ${B}`)
