// Inserted at the top of the sky worker's chunk by live-lib.mjs (patchChunk), observation only. It defines self.__live, which the two wrappers
// patchChunk puts around planMeteor and drawMeteor call: they record what the real worker plans and draws, frame by frame (inputs, and with
// `outputs` the sprite and gradient calls), and with `capture` take GPU copies of the canvas region around the flight (the sky-only frame of
// the first meteor frame as the baseline, then the finished frame after each drawMeteor). Nothing here changes what the worker draws.
;(() => {
	if (self.__live) return
	const epoch = () => performance.timeOrigin + performance.now()
	const L = (self.__live = {
		capture: false,
		outputs: false,
		// every planMeteor call (the zones it saw, its arguments, its result) and every flight the renderer drew
		plans: [],
		meteors: [],
		zones: [],
		frames: [],
		shots: [],
		regions: [],
		bases: [],
		pending: 0,
		errors: [],
		beats: [],
		planMs: [],
		drawMs: [],
		lastMeteor: null,
		zoneSig: NaN,
		zoneIndex: -1,
		// the unwrapped planMeteor, pickRadiant and drawMeteor (registered by the patched chunk) and the assets the renderer was last given
		orig: {},
		assets: null,
	})
	const rects = (list) => list.map((r) => ({ x: r.x, y: r.y, width: r.width, height: r.height, headroom: r.headroom }))
	const sigOf = (blend) => {
		let s = blend.to.length * 31 + blend.from.length
		for (const r of blend.to) s = s * 1.0000003 + r.x + 2 * r.y + 3 * r.width + 5 * r.height + 7 * r.headroom
		for (const r of blend.from) s = s * 1.0000003 + 11 * r.x + 13 * r.y + 17 * r.width + 19 * r.height + 23 * r.headroom
		return s
	}
	// Event-loop gaps in the worker (a heartbeat every 25 ms; a gap over 60 ms means something held the worker that long)
	let lastBeat = epoch()
	setInterval(() => {
		const t = epoch()
		if (t - lastBeat > 60) L.beats.push([lastBeat, Math.round(t - lastBeat)])
		lastBeat = t
	}, 25)
	self.addEventListener('error', (e) => L.errors.push('error: ' + String(e.message)))
	self.addEventListener('unhandledrejection', (e) => L.errors.push('rejection: ' + String(e.reason && e.reason.message)))

	L.plan = (original, args) => {
		const t0 = performance.now()
		const result = original(...args)
		const t1 = performance.now()
		try {
			L.planMs.push(t1 - t0)
			const field = args[1]
			L.plans.push({ at: epoch(), ms: t1 - t0, now: args[3], width: field.width, height: field.height, zones: rects(field.quiet), radiant: { ...args[2] }, options: { ...(args[4] ?? {}) }, meteor: result ? { ...result } : null })
		} catch (e) {
			L.errors.push('plan hook: ' + String(e))
		}
		return result
	}

	L.draw = (original, args) => {
		const ctx = args[0]
		const meteor = args[2]
		const frame = args[3]
		L.assets = args[1]
		let record = null
		let index = -1
		try {
			if (meteor !== L.lastMeteor) {
				L.lastMeteor = meteor
				index = L.meteors.length
				L.meteors.push({ ...meteor })
				if (L.capture) {
					const d = ctx.canvas.width / frame.width
					const margin = 32
					const endX = meteor.startX + meteor.dirX * meteor.length
					const endY = meteor.startY + meteor.dirY * meteor.length
					const x0 = Math.max(0, Math.floor((Math.min(meteor.startX, endX) - margin) * d))
					const y0 = Math.max(0, Math.floor((Math.min(meteor.startY, endY) - margin) * d))
					const x1 = Math.min(ctx.canvas.width, Math.ceil((Math.max(meteor.startX, endX) + margin) * d))
					const y1 = Math.min(ctx.canvas.height, Math.ceil((Math.max(meteor.startY, endY) + margin) * d))
					L.regions[index] = [x0, y0, x1 - x0, y1 - y0, d]
					// drawSky has just drawn this frame: the canvas is the sky with no shooting star, the baseline of the pixel analysis
					L.pending++
					createImageBitmap(ctx.canvas, x0, y0, x1 - x0, y1 - y0).then((bmp) => {
						L.bases[index] = bmp
						L.pending--
					})
				}
			} else index = L.meteors.length - 1
			const sig = sigOf(frame.quiet)
			if (sig !== L.zoneSig) {
				L.zoneSig = sig
				L.zoneIndex = L.zones.length
				L.zones.push({ at: epoch(), to: rects(frame.quiet.to), from: rects(frame.quiet.from), level: frame.quiet.level })
			}
			if (L.outputs) {
				record = { draws: [], grads: [] }
				const drawImage = ctx.drawImage
				const createLinearGradient = ctx.createLinearGradient
				ctx.drawImage = function (...b) {
					record.draws.push([b[1], b[2], b[3], b[4], Math.round(b[5] * 1e4) / 1e4, Math.round(b[6] * 1e4) / 1e4, this.globalAlpha])
					return drawImage.apply(this, b)
				}
				ctx.createLinearGradient = function (...b) {
					const g = createLinearGradient.apply(this, b)
					const stops = []
					record.grads.push({ at: b, stops })
					const add = g.addColorStop
					g.addColorStop = function (o, c) {
						stops.push([o, c])
						return add.call(this, o, c)
					}
					return g
				}
			}
		} catch (e) {
			L.errors.push('draw hook: ' + String(e))
		}
		const t0 = performance.now()
		let result
		try {
			result = original(...args)
		} finally {
			if (record) {
				delete ctx.drawImage
				delete ctx.createLinearGradient
			}
		}
		const t1 = performance.now()
		try {
			const frameIndex = L.frames.length
			L.frames.push({ time: frame.time, at: epoch(), ms: t1 - t0, level: frame.quiet.level, fade: args[4] ?? 1, meteor: index, zones: L.zoneIndex, record })
			L.drawMs.push(t1 - t0)
			if (L.capture && L.regions[index]) {
				const [x0, y0, w, h] = L.regions[index]
				L.pending++
				createImageBitmap(ctx.canvas, x0, y0, w, h).then((bmp) => {
					L.shots[frameIndex] = bmp
					L.pending--
				})
			}
		} catch (e) {
			L.errors.push('draw hook after: ' + String(e))
		}
		return result
	}

	const LIN = new Float64Array(256)
	for (let c = 0; c < 256; c++) {
		const s = c / 255
		LIN[c] = s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4
	}
	const lum = (r, g, b) => 0.2126 * LIN[r] + 0.7152 * LIN[g] + 0.0722 * LIN[b]

	/**
	 * After a flight: per recorded frame of flight `meteorIndex`, the largest R+G+B rise over the baseline anywhere in the region and inside each
	 * text rect, and the lowest WCAG contrast of each rect's own color against the pixels the shooting star lit there. `texts`: [{ x, y, w, h, rgb }]
	 * in CSS px (screen coordinates). Closes the copies unless `keep`.
	 */
	L.analyze = async (meteorIndex, texts, keep) => {
		const [rx, ry, rw, rh, d] = L.regions[meteorIndex]
		const base = L.bases[meteorIndex]
		const scratch = new OffscreenCanvas(rw, rh)
		const sctx = scratch.getContext('2d', { willReadFrequently: true })
		const read = (bmp) => {
			sctx.globalCompositeOperation = 'copy'
			sctx.drawImage(bmp, 0, 0)
			return sctx.getImageData(0, 0, rw, rh).data
		}
		const b = read(base)
		const boxes = texts.map((t) => ({
			x0: Math.max(0, Math.floor(t.x * d) - rx),
			y0: Math.max(0, Math.floor(t.y * d) - ry),
			x1: Math.min(rw, Math.ceil((t.x + t.w) * d) - rx),
			y1: Math.min(rh, Math.ceil((t.y + t.h) * d) - ry),
			L: lum(t.rgb[0], t.rgb[1], t.rgb[2]),
		}))
		const out = []
		L.frames.forEach((f, k) => {
			const bmp = L.shots[k]
			if (f.meteor !== meteorIndex || !bmp) return
			const p = read(bmp)
			let any = 0
			for (let i = 0; i < p.length; i += 4) {
				const rise = p[i] - b[i] + p[i + 1] - b[i + 1] + p[i + 2] - b[i + 2]
				if (rise > any) any = rise
			}
			const rect = new Array(boxes.length).fill(0)
			const contrast = new Array(boxes.length).fill(null)
			boxes.forEach((box, j) => {
				let max = 0
				let worst = Infinity
				for (let y = box.y0; y < box.y1; y++) {
					for (let x = box.x0; x < box.x1; x++) {
						const i = (y * rw + x) * 4
						const rise = p[i] - b[i] + p[i + 1] - b[i + 1] + p[i + 2] - b[i + 2]
						if (rise <= 0) continue
						if (rise > max) max = rise
						const l = lum(p[i], p[i + 1], p[i + 2])
						const c = (Math.max(box.L, l) + 0.05) / (Math.min(box.L, l) + 0.05)
						if (c < worst) worst = c
					}
				}
				rect[j] = max
				contrast[j] = worst === Infinity ? null : worst
			})
			out.push({ k, time: f.time, at: f.at, any, rect, contrast })
		})
		if (!keep) {
			base.close()
			L.shots.forEach((bmp) => bmp.close())
			L.shots = []
		}
		return out
	}

	/** A PNG (base64) of the region copy of frame k, or of the baseline when k is -1, gained by `gain` over the baseline when gain > 1. */
	L.png = async (meteorIndex, k, gain = 1) => {
		const [, , rw, rh] = L.regions[meteorIndex]
		const scratch = new OffscreenCanvas(rw, rh)
		const sctx = scratch.getContext('2d', { willReadFrequently: true })
		const bmp = k < 0 ? L.bases[meteorIndex] : L.shots[k]
		sctx.drawImage(bmp, 0, 0)
		if (gain !== 1 && k >= 0) {
			const sctx2 = new OffscreenCanvas(rw, rh).getContext('2d', { willReadFrequently: true })
			sctx2.drawImage(L.bases[meteorIndex], 0, 0)
			const a = sctx.getImageData(0, 0, rw, rh)
			const bb = sctx2.getImageData(0, 0, rw, rh).data
			for (let i = 0; i < a.data.length; i += 4) {
				for (let c = 0; c < 3; c++) a.data[i + c] = Math.max(0, Math.min(255, bb[i + c] + (a.data[i + c] - bb[i + c]) * gain))
			}
			sctx.putImageData(a, 0, 0)
		}
		const blob = await scratch.convertToBlob({ type: 'image/png' })
		const bytes = new Uint8Array(await blob.arrayBuffer())
		let bin = ''
		for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000))
		return btoa(bin)
	}

	/**
	 * Steady-state JS cost of the real drawMeteor (the bundle's own, unwrapped) on a scratch canvas: `batches` batches of `calls` calls mid-flight of
	 * `meteor` against `zones` (as bench-draw.mjs does offline). Needs the renderer's assets, so run it after the first shooting star. Returns ms per call per batch.
	 */
	L.benchDraw = (meteor, zones, width, height, dpr, batches = 12, calls = 300) => {
		const canvas = new OffscreenCanvas(Math.round(width * dpr), Math.round(height * dpr))
		const ctx = canvas.getContext('2d', { alpha: false })
		const frameAt = (time) => ({ time, width, height, dpr, deviceWidth: canvas.width, deviceHeight: canvas.height, parallaxScroll: 0, keep: 0, layers: { far: 0, mid: 0, near: 0 }, dusk: Infinity, twinkle: 0, haze: 1, quiet: { from: [], to: zones, level: 1 }, meteorInk: 1 })
		const out = []
		for (let b = 0; b < batches; b++) {
			const t0 = performance.now()
			for (let i = 0; i < calls; i++) L.orig.draw(ctx, L.assets, meteor, frameAt(meteor.startedAt + meteor.duration * (0.5 + 0.4 * (i / calls))))
			out.push((performance.now() - t0) / calls)
			// flush the queued GPU work between batches so it doesn't pile up
			canvas.transferToImageBitmap?.()
		}
		return out
	}

	/**
	 * Cost of the real planMeteor (the bundle's own) per launch against `zones`: `batches` batches of `launches` fresh-radiant launches each, ms per
	 * launch per batch (the worker's timer has 0.1 ms steps, so a batch is the unit that resolves a cost of a few hundredths of a millisecond).
	 */
	L.benchPlan = (width, height, zones, batches = 150, launches = 20) => {
		const field = { width, height, quiet: zones }
		const out = []
		for (let b = 0; b < batches; b++) {
			const radiants = Array.from({ length: launches }, () => L.orig.pick(Math.random, width, height))
			const t0 = performance.now()
			for (const radiant of radiants) L.orig.plan(Math.random, field, radiant, 0)
			out.push((performance.now() - t0) / launches)
		}
		return out
	}

	/** Everything recorded except the pixel copies (JSON-able), and clears nothing. */
	L.dump = () => ({ plans: L.plans, meteors: L.meteors, zones: L.zones, frames: L.frames, regions: L.regions, errors: L.errors, beats: L.beats, planMs: L.planMs, drawMs: L.drawMs })

	/** Forgets everything recorded so far (the next visit step starts clean). */
	L.reset = () => {
		for (const bmp of L.shots) bmp?.close()
		for (const bmp of L.bases) bmp?.close()
		Object.assign(L, { plans: [], meteors: [], zones: [], frames: [], shots: [], regions: [], bases: [], beats: [], planMs: [], drawMs: [], lastMeteor: null, zoneSig: NaN, zoneIndex: -1 })
	}
})()
