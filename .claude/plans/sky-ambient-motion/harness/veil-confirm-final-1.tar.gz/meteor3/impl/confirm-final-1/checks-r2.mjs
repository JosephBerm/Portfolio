// Revision-2 invariants of the planner and the scroll helper, each a paired test (same random stream, one knob changed):
//   1. the aim never touches a fireball, a flare or a train: where the first fit is one of them, the aimed planner returns the very same flight
//   2. with no light allowed on copy (ink 0, prefers-contrast: more) nothing is aimed: the plan equals the unaimed plan, byte for byte
//   3. nearCopy: false is never aimed either
//   4. an aimed plan that differs from the unaimed one is a plain flight that passes behind copy for about `dwell` or more, judged on a finer walk
//   5. scrollKept: the 12-24 px ramp is symmetric, a caller's fade can only dim (clamped to 0-1), and 0 means gone
//   node checks-r2.mjs [launches] [labels...]
import { P, loadCapture, fieldOf, walkProto } from './lib.mjs'

const N = Number(process.argv[2] ?? 1500)
const labels = process.argv.slice(3).length ? process.argv.slice(3) : ['1440x900@1', '1280x800@1', '1920x1080@1', '1024x768@1', '390x844@3m']
const STEPS = 400
const failures = []
const SHARE = P.METEOR_PASS.share
const withShare = (share, fn) => {
	P.METEOR_PASS.share = share
	try {
		return fn()
	} finally {
		P.METEOR_PASS.share = SHARE
	}
}
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b)
const special = (f) => f && (f.fireball || f.flare || f.train)
const behindFor = (f, zones) => (walkProto(f, zones, STEPS).filter((s) => s.onCopy && s.rise >= P.METEOR_PASS.visible).length / STEPS) * f.duration

console.log(`METEOR_PASS ${JSON.stringify(P.METEOR_PASS)}; ${N} paired launches per viewport\n`)
console.log('viewport       specials  specials changed   ink 0 aimed   nearCopy:false aimed   aimed changes  of which plain + pass  (pass time min, s)')
for (const label of labels) {
	const capture = loadCapture(label)
	const field = fieldOf(capture)
	const radiantRandom = P.mulberry32(0x5eed + capture.width)
	let specials = 0
	let specialsChanged = 0
	let ink0Aimed = 0
	let clearAimed = 0
	let changed = 0
	let changedOk = 0
	let minPass = Infinity
	for (let i = 0; i < N; i++) {
		const seed = 0x1000 + i * 977 + capture.width
		const radiant = P.pickRadiant(radiantRandom, capture.width, capture.height)
		const plan = (share, options = {}) => withShare(share, () => P.planMeteor(P.mulberry32(seed), field, radiant, 0, options))
		const unaimed = plan(0)
		const aimed = plan(SHARE)
		if (special(unaimed)) {
			specials++
			if (!same(unaimed, aimed)) specialsChanged++
		}
		if (!same(plan(0, { ink: 0 }), plan(SHARE, { ink: 0 }))) ink0Aimed++
		if (!same(plan(0, { nearCopy: false }), plan(SHARE, { nearCopy: false }))) clearAimed++
		if (!same(unaimed, aimed) && aimed) {
			changed++
			const time = behindFor(aimed, field.quiet)
			// the planner judges 64 samples, this walk 400: allow the sampling difference (0.7 of the dwell)
			if (!special(aimed) && time >= 0.7 * P.METEOR_PASS.dwell * aimed.duration) changedOk++
			minPass = Math.min(minPass, time)
		}
	}
	console.log(label.padEnd(14), String(specials).padStart(8), String(specialsChanged).padStart(17), String(ink0Aimed).padStart(13), String(clearAimed).padStart(22), String(changed).padStart(15), String(changedOk).padStart(22), Number.isFinite(minPass) ? minPass.toFixed(3).padStart(14) : '-')
	if (specialsChanged || ink0Aimed || clearAimed || changedOk !== changed) failures.push(label)
}

// 5. the scroll helper
const near = (a, b) => Math.abs(a - b) < 1e-9
const ramp = [
	['within the slack (10 px)', P.scrollKept(500, 510), 1],
	['at from (12 px)', P.scrollKept(500, 512), 1],
	['halfway (18 px, either way)', P.scrollKept(500, 518), 0.5],
	['halfway upward (18 px)', P.scrollKept(500, 482), 0.5],
	['at to (24 px)', P.scrollKept(500, 524), 0],
	['a jump of a screen (900 px)', P.scrollKept(0, 900), 0],
	['fade 0.5 at rest', P.scrollKept(500, 500, 0.5), 0.5],
	['fade 0.5 halfway', P.scrollKept(500, 518, 0.5), 0.25],
	['fade above 1 cannot brighten', P.scrollKept(500, 518, 3), 0.5],
	['fade below 0 is gone', P.scrollKept(500, 500, -1), 0],
]
console.log('\nscrollKept(launchScrollY, scrollY, fade = 1):')
for (const [name, got, want] of ramp) {
	console.log(`  ${near(got, want) ? 'ok  ' : 'FAIL'} ${name.padEnd(30)} ${got.toFixed(4)} (want ${want})`)
	if (!near(got, want)) failures.push('scrollKept ' + name)
}
console.log(failures.length ? `\nFAILED: ${failures.join(', ')}` : '\nall revision-2 invariants hold')
