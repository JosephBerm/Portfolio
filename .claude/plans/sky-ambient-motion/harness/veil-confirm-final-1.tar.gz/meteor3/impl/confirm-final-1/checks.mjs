// Invariants of the proposed planner and veil over planned flights on the live rects (fine walk, 600 moments per flight):
//   1. start and peak in clear sky: the veil does nothing before the light peak plus a margin
//   2. no rect's budget is exceeded by the head pixel, for every rect the head is inside (min over rects)
//   3. worst case with the haze and the brightest far star added on the same pixel stays within every rect's headroom
//   4. the head never brightens again once the veil has dimmed it (beyond the slack)
//   5. a plan with nearCopy: false never enters the veil; options.length selects the flight kind
//   6. the veil never raises a point above what the stars' keeps would give a rect with the same budget (sanity of min over rects)
//   node checks.mjs [launches] [labels...]
import { P, loadCapture, fieldOf, textRects, insideRect, walkProto, kindOf } from './lib.mjs'

const N = Number(process.argv[2] ?? 2000)
const labels = process.argv.slice(3).length ? process.argv.slice(3) : ['1440x900@1', '1280x800@1', '1366x768@1', '1536x864@1.25', '1920x1080@1', '2560x1440@1', '1280x720@1', '1024x768@1', '390x844@3m']
const PEAK_AT = 0.5 ** (1 / P.METEOR_LIGHT.skew)
const STEPS = 600
const failures = []
console.log(`light peaks at p = ${PEAK_AT.toFixed(3)}; clearUntil = ${P.METEOR_VEIL.clearUntil}; ${N} launches per viewport, ${STEPS} moments per flight\n`)
console.log('viewport       flights  veil<0.98 through the peak   budget exceeded   worst rise+star+haze / headroom   re-brightens   nearCopy:false in veil   flights option ok')
for (const label of labels) {
	const capture = loadCapture(label)
	const field = fieldOf(capture)
	const rects = textRects(capture)
	const random = P.mulberry32(0xc0ffee + capture.width)
	let flights = 0
	let earlyVeil = 0
	let overBudget = 0
	let rebright = 0
	let worstRatio = 0
	let worstKind = ''
	let clearViolations = 0
	let lengthBad = 0
	for (let i = 0; i < N; i++) {
		const radiant = P.pickRadiant(random, capture.width, capture.height)
		const f = P.planMeteor(random, field, radiant, 0)
		if (!f) continue
		flights++
		const w = walkProto(f, field.quiet, STEPS)
		// 1. the head is at 98% of its light or more through the peak (the veil's faint outer tail may start a hair early between planner samples)
		if (w.some((s) => s.p <= PEAK_AT + 0.005 && s.kept < 0.98)) earlyVeil++
		// 2 and 3. per rect the head is inside
		for (const s of w) {
			for (const r of rects) {
				if (!insideRect(r, s.x, s.y)) continue
				const budget = P.inkBudget(r.headroom)
				if (s.rise > budget + 1e-9) overBudget++
				const worst = (s.rise + P.STAR_INK_PEAK + P.INK_BUDGET.hazeReserve) / r.headroom
				if (worst > worstRatio) {
					worstRatio = worst
					worstKind = kindOf(r.desc)
				}
			}
		}
		// 4. after the first dim and the clear-until point the visible light only falls (light x kept, slack METEOR_VEIL.rise)
		let lowest = Infinity
		for (const s of w) {
			if (s.p <= P.METEOR_VEIL.clearUntil) continue
			// the flare is a planned late brightening in clear sky, not the veil's doing
			const visible = s.kept * P.meteorLight(s.p, false)
			if (visible > lowest + P.METEOR_VEIL.rise + 0.02) {
				rebright++
				break
			}
			lowest = Math.min(lowest, visible)
		}
		// 5a. a clear-sky plan really is clear: no moment of the path is inside any veil
		const clear = P.planMeteor(random, field, radiant, 0, { nearCopy: false })
		if (clear) {
			for (let k = 0; k <= 400; k++) {
				const { x, y } = P.meteorPoint(clear, k / 400)
				if (P.quietAt(field.quiet, x, y) > 0) {
					clearViolations++
					break
				}
			}
			if (clear.nearCopy) clearViolations++
		}
		// 5b. the length option
		const long = P.planMeteor(random, field, radiant, 0, { flights: 'long' })
		const short = P.planMeteor(random, field, radiant, 0, { flights: 'short' })
		const narrow = capture.width <= P.NARROW_MAX_WIDTH
		const [lo, hi] = narrow ? P.METEOR.narrowFallbackDuration : P.METEOR.fallbackDuration
		if (long && long.duration < (narrow ? P.METEOR.narrowDuration[0] : P.METEOR.duration[0]) - 1e-9 && !long.fireball) lengthBad++
		if (short && (short.duration < lo - 1e-9 || short.duration > hi + 1e-9)) lengthBad++
	}
	console.log(
		label.padEnd(14),
		String(flights).padStart(6),
		String(earlyVeil).padStart(14),
		String(overBudget).padStart(20),
		`${worstRatio.toFixed(3)} (${worstKind})`.padStart(34),
		String(rebright).padStart(14),
		String(clearViolations).padStart(18),
		String(lengthBad).padStart(24)
	)
	if (earlyVeil || overBudget || clearViolations || lengthBad || worstRatio > 1) failures.push(label)
}
console.log(failures.length ? `\nFAILED: ${failures.join(', ')}` : '\nall invariants hold')
