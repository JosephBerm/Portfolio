// What D1-D3 changed, and nothing else, as paired tests on the implemented code (impl/pure/proto = the repository):
//   D1a  with the edge-fade rule switched off in memory (METEOR_VEIL.edgeBright = Infinity) planMeteor returns exactly the plan's plans
//        (impl/pure/plan = plan/proto), for the same random stream, for every option the planner takes: the rule is the only planner change
//   D1b  with the rule on, planMeteor returns exactly the plans of the confirmer's prototype (confirm-3/pure/variant, its thresholds 0.3 / 0.5 /
//        0.041 hard-coded): the implementation is that rule
//   D2   transientQuietFactor equals min(easedQuietFactor, quietFactor(to)) at every point, level and keep, and the plan's easedQuietFactor is
//        unchanged (stars): the stars' cross-fade is bit-identical to the plan's
//   D2n  (round-1 fix, audit finding correctness-wcag:F1) with a waiting layout, QuietBlend.next, transientQuietFactor equals
//        min(easedQuietFactor, quietFactor(to), quietFactor(next)) at every point, level and keep; the stars' easedQuietFactor ignores next;
//        a blend with no next, or next: undefined, is the D2 formula above exactly
//   node equiv-d.mjs [launches]
import { pathToFileURL } from 'node:url'
import { HERE, ROOT, loadCapture } from './lib.mjs'

const load = async (dir, name) => import(pathToFileURL(`${dir}/${name}.mjs`).href)
const lib = async (dir) => ({ ...(await load(dir, 'meteors')), ...(await load(dir, 'scene')), ...(await load(dir, 'config')), ...(await load(dir, 'random')) })
const PL = await lib(`${HERE}/pure/plan/lib-sky`)
const R = await lib(`${HERE}/pure/proto/lib-sky`)
const V = await lib(`${ROOT}/confirm-3/pure/variant/lib-sky`)
const N = Number(process.argv[2] ?? 1500)
const labels = ['1440x900@1', '1280x800@1', '1366x768@1', '1536x864@1.25', '1920x1080@1', '2560x1440@1', '1280x720@1', '1024x768@1', '390x844@3m']
const optionSets = [{}, { ink: 0 }, { ink: 0.5 }, { nearCopy: false }, { flights: 'long' }, { flights: 'short' }]
let failures = 0

const edgeBright = R.METEOR_VEIL.edgeBright
console.log(`implementation: METEOR_VEIL ${JSON.stringify(R.METEOR_VEIL)}, METEOR_PASS ${JSON.stringify(R.METEOR_PASS)}`)

async function paired(title, A, B, setup) {
	console.log(`\n${title}`)
	let identical = 0
	let total = 0
	let changedPlans = 0
	for (const label of labels) {
		const capture = loadCapture(label)
		const field = (L) => ({ width: capture.width, height: capture.height, quiet: L.screenQuietZones(capture.quiet, 0, capture.pinned) })
		const ra = A.mulberry32(0xd1 + capture.width)
		const rb = B.mulberry32(0xd1 + capture.width)
		let same = 0
		let nulls = 0
		for (let i = 0; i < N; i++) {
			const a = A.pickRadiant(ra, capture.width, capture.height)
			const b = B.pickRadiant(rb, capture.width, capture.height)
			const options = optionSets[i % optionSets.length]
			const pa = A.planMeteor(ra, field(A), a, 0, options)
			const pb = B.planMeteor(rb, field(B), b, 0, options)
			if (JSON.stringify(pa) === JSON.stringify(pb)) same++
			else changedPlans++
			if (pa === null) nulls++
		}
		console.log(`  ${label.padEnd(14)} ${same} of ${N} identical (${nulls} null plans)`)
		identical += same
		total += N
	}
	console.log(`  ${identical} of ${total} identical`)
	if (identical !== total) failures++
	return changedPlans
}

// D1a: the rule off
R.METEOR_VEIL.edgeBright = Infinity
await paired('D1a  implementation with the edge-fade rule off against the plan (same random stream)', R, PL)
R.METEOR_VEIL.edgeBright = edgeBright

// D1b: the rule on, against the confirmer's prototype
await paired('D1b  implementation against the confirmer\'s prototype (rule on: bright 0.3, kept 0.5, glimmer 0.041)', R, V)

// and the rule really changes plans (the paired tests above are not vacuous): one launch per seed, the rule on against off, same stream
{
	console.log('\nthe rule on against off, one launch per seed (same random stream, same radiant): share of launches whose plan changes')
	const edge = R.METEOR_VEIL.edgeBright
	for (const label of ['1440x900@1', '1280x800@1', '1920x1080@1', '1024x768@1', '390x844@3m']) {
		const capture = loadCapture(label)
		const field = { width: capture.width, height: capture.height, quiet: R.screenQuietZones(capture.quiet, 0, capture.pinned) }
		const radiantRandom = R.mulberry32(0x5eed + capture.width)
		let differ = 0
		for (let i = 0; i < N; i++) {
			const radiant = R.pickRadiant(radiantRandom, capture.width, capture.height)
			const seed = 0x1000 + i * 977 + capture.width
			R.METEOR_VEIL.edgeBright = edge
			const on = R.planMeteor(R.mulberry32(seed), field, radiant, 0)
			R.METEOR_VEIL.edgeBright = Infinity
			const off = R.planMeteor(R.mulberry32(seed), field, radiant, 0)
			R.METEOR_VEIL.edgeBright = edge
			if (JSON.stringify(on) !== JSON.stringify(off)) differ++
		}
		console.log(`  ${label.padEnd(14)} ${differ} of ${N} launches change (${((100 * differ) / N).toFixed(1)}%)`)
		if (differ === 0 && !label.startsWith('2560')) failures++
	}
}

// D2
console.log('\nD2  transientQuietFactor against min(easedQuietFactor, quietFactor(to)); easedQuietFactor against the plan')
{
	const random = R.mulberry32(77)
	let points = 0
	let mismatches = 0
	let starMismatches = 0
	let belowEased = 0
	let nextPoints = 0
	let nextMismatches = 0
	let belowCurrent = 0
	for (const label of labels) {
		const capture = loadCapture(label)
		const toZones = R.screenQuietZones(capture.quiet, 0, capture.pinned)
		const fromZones = R.screenQuietZones(
			capture.quiet.map((r) => ({ ...r, x: r.x + 14, y: r.y - 17 })),
			0,
			capture.pinned.map((r) => ({ ...r, x: r.x - 9, y: r.y + 12 }))
		)
		const nextZones = R.screenQuietZones(
			capture.quiet.map((r) => ({ ...r, x: r.x - 11, y: r.y + 23 })),
			0,
			capture.pinned.map((r) => ({ ...r, x: r.x + 6, y: r.y - 8 }))
		)
		const planTo = PL.screenQuietZones(capture.quiet, 0, capture.pinned)
		const planFrom = PL.screenQuietZones(
			capture.quiet.map((r) => ({ ...r, x: r.x + 14, y: r.y - 17 })),
			0,
			capture.pinned.map((r) => ({ ...r, x: r.x - 9, y: r.y + 12 }))
		)
		const keepsOf = (L, white) => [L.LAYERS.far, L.LAYERS.mid, L.LAYERS.near, L.budgetKeeps(white, L.METEOR_VEIL.quietKeep), L.budgetKeeps(white, L.METEOR_VEIL.quietKeep, 0.5)]
		for (let i = 0; i < 40000; i++) {
			const x = random() * capture.width
			const y = random() * capture.height
			const level = [0, 0.25, 0.5, 0.75, 1, 1.2][i % 6]
			const white = 0.2 + 2.5 * random()
			const blend = { from: level < 1 ? fromZones : [], to: toZones, level }
			const planBlend = { from: level < 1 ? planFrom : [], to: planTo, level }
			const keeps = keepsOf(R, white)
			const planKeeps = keepsOf(PL, white)
			for (let k = 0; k < keeps.length; k++) {
				const eased = R.easedQuietFactor(blend, x, y, keeps[k])
				const transient = R.transientQuietFactor(blend, x, y, keeps[k])
				const literal = Math.min(eased, R.quietFactor(blend.to, x, y, keeps[k]))
				points++
				if (transient !== literal) mismatches++
				if (transient < eased) belowEased++
				if (transient > eased) mismatches++
				// the stars' function is the plan's
				if (eased !== PL.easedQuietFactor(planBlend, x, y, planKeeps[k])) starMismatches++
				if (level >= 1 && transient !== eased) mismatches++
				// a waiting layout: the shooting star keeps clear of its copy too, the stars do not look at it
				const held = { ...blend, next: nextZones }
				const withNext = R.transientQuietFactor(held, x, y, keeps[k])
				const literalNext = Math.min(eased, R.quietFactor(blend.to, x, y, keeps[k]), R.quietFactor(nextZones, x, y, keeps[k]))
				nextPoints++
				if (withNext !== literalNext) nextMismatches++
				if (withNext > transient) nextMismatches++
				if (withNext < transient) belowCurrent++
				if (R.easedQuietFactor(held, x, y, keeps[k]) !== eased) nextMismatches++
				if (R.transientQuietFactor({ ...blend, next: undefined }, x, y, keeps[k]) !== transient) nextMismatches++
			}
		}
	}
	console.log(`  ${points} (point, level, keep) cases: ${mismatches} mismatches with the literal formula, transient below the eased factor in ${belowEased} (where the new copy dims more than the cross-fade), ${starMismatches} mismatches of easedQuietFactor with the plan's`)
	console.log(`  with a waiting layout (next): ${nextPoints} cases, ${nextMismatches} mismatches with min(eased, quietFactor(to), quietFactor(next)), the shooting star below the no-next factor in ${belowCurrent} (where the waiting layout's copy lies under the point)`)
	if (mismatches || starMismatches || nextMismatches || belowCurrent === 0) failures++
}

console.log(failures ? `\nFAILED (${failures})` : '\nall paired tests hold')
process.exit(failures ? 1 : 0)
