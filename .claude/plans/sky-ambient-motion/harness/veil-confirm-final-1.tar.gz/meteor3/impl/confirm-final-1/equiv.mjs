// The proposed quietFactor / quietAt / inkAt must give the stars exactly what the repository's give (numeric keeps).
import { P, B, loadCapture, fieldOf } from './lib.mjs'
const labels = ['1024x768@1', '1280x720@1', '1280x800@1', '1366x768@1', '1440x900@1', '1536x864@1.25', '1920x1080@1', '2560x1440@1', '390x844@3m']
const random = P.mulberry32(7)
let worst = 0, total = 0, mism = 0, inZone = 0
for (const label of labels) {
	const c = loadCapture(label)
	for (const scrollY of [0, 140, 777]) {
		const zp = P.screenQuietZones(c.quiet, scrollY, c.pinned)
		const zb = B.screenQuietZones(c.quiet, scrollY, c.pinned)
		const keepsList = [B.LAYERS.far, B.LAYERS.mid, B.LAYERS.near, B.METEOR_VEIL, { quietKeep: 0.3, inkKeep: 0.05 }]
		for (let i = 0; i < 40000; i++) {
			const x = random() * c.width, y = random() * c.height
			const k = keepsList[i % keepsList.length]
			const a = B.quietFactor(zb, x, y, k)
			const b = P.quietFactor(zp, x, y, k)
			total++
			if (a < 1) inZone++
			if (a !== b) { mism++; worst = Math.max(worst, Math.abs(a - b)) }
			if (B.quietAt(zb, x, y) !== P.quietAt(zp, x, y) || B.inkAt(zb, x, y) !== P.inkAt(zp, x, y)) { mism++; }
		}
	}
}
console.log(`quietFactor/quietAt/inkAt: ${total} random points, ${inZone} inside a veil, ${mism} mismatches, worst difference ${worst}`)
