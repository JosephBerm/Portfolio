// Builds pure/<tree>/components-sky/sky.worker.dbg.mjs: the transpiled worker (base: HEAD's, plan: the plan's proposed one,
// proto: the repository's, the implementation) plus read-only debug getters appended at the end of the module (this folder
// only; no behavior of the worker changes).
import fs from 'node:fs'
import { HERE } from '../lib.mjs'

for (const tree of ['base', 'plan', 'before', 'proto']) {
	const src = fs.readFileSync(`${HERE}/pure/${tree}/components-sky/sky.worker.mjs`, 'utf8')
	const extra = tree !== 'base' ? '\tget launchScrollY() { return launchScrollY },\n\tget pendingLayout() { return pendingLayout },\n' : ''
	const hook = `
globalThis.__skyDbg = {
	get meteor() { return meteor },
	get radiant() { return radiant },
	get assets() { return assets },
	get quiet() { return quiet },
	get pinned() { return pinned },
	get layoutAt() { return layoutAt },
	get scrollY() { return scrollY },
	get launched() { return launched },
	get nextMeteorAt() { return nextMeteorAt },
	get failedPlans() { return failedPlans },
${extra}	get needsDraw() { return needsDraw },
	get lastDrawAt() { return lastDrawAt },
	get rafId() { return rafId },
	get timerId() { return timerId },
	get quality() { return quality },
	frameMode,
	quietBlend,
	meteorsAllowed,
}
`
	fs.writeFileSync(`${HERE}/pure/${tree}/components-sky/sky.worker.dbg.mjs`, src + hook)
	console.log(tree, 'wrote sky.worker.dbg.mjs', (src + hook).length, 'bytes')
}
