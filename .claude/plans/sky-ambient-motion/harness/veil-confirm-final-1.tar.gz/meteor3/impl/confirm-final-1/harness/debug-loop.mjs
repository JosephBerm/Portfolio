// Finds a runaway event loop in the proposed worker on the fake clock: replays one visit (as visits.mjs does) with an event guard.
import fs from 'node:fs'
import { ZONES, loadCapture } from '../lib.mjs'
import { createSim } from './sim.mjs'

const label = '1440x900@1'
const capture = loadCapture(label)
const raw = JSON.parse(fs.readFileSync(`${ZONES}/${label}.json`, 'utf8'))
const headrooms = { quiet: capture.quiet.map((r) => r.headroom), pinned: capture.pinned.map((r) => r.headroom) }
const layouts = raw.layouts
	.filter((l) => l.quiet.length > 0)
	.map((l) => ({ ...l, quiet: l.quiet.map((r, i) => ({ ...r, headroom: headrooms.quiet[i] ?? 0 })), pinned: l.pinned.map((r, i) => ({ ...r, headroom: headrooms.pinned[i] ?? 0 })) }))

const seed = Number(process.argv[2] ?? 5)
const tree = process.argv[3] ?? 'proto'
const sim = await createSim({ width: capture.width, height: capture.height, dpr: capture.dpr, seed, tree })
sim.send({ type: 'init' })
sim.advance(3800)
sim.send({ type: 'reveal' })
const revealAt = sim.clock.now
let li = 0
let steps = 0
let last = null
const guard = (name) => () => {
	steps++
	while (li < layouts.length && sim.clock.now - revealAt >= layouts[li].msAfterReveal) {
		sim.send({ type: 'layout', documentHeight: layouts[li].documentHeight, quiet: layouts[li].quiet, pinned: layouts[li].pinned })
		li++
	}
	if (steps > 60000) {
		const d = sim.dbg
		throw new Error(`runaway in ${name}: clock ${((sim.clock.now - revealAt) / 1000).toFixed(2)} s, meteor ${!!d.meteor}, launched ${d.launched}, failedPlans ${d.failedPlans}, nextMeteorAt ${d.nextMeteorAt}, layoutAt ${d.layoutAt}, pending ${!!d.pendingLayout}, scrollY ${d.scrollY}, needsDraw ${d.needsDraw}, mode ${d.frameMode(sim.clock.now)}, lastDrawAt ${d.lastDrawAt}, now ${sim.clock.now}, raf ${d.rafId}, timer ${String(d.timerId)}, train ${d.meteor?.train}, lifetime ${d.meteor ? (d.meteor.duration + (d.meteor.train ? 2.4 : 0.39)).toFixed(2) : '-'}, age ${d.meteor ? (sim.clock.now / 1000 - d.meteor.startedAt).toFixed(2) : '-'}`)
	}
	const m = sim.dbg.meteor
	if (m && m !== last) {
		last = m
		return true
	}
	return false
}
try {
	for (let k = 1; k <= 3; k++) {
		steps = 0
		const got = sim.until(sim.clock.now + 200000, guard(`wait for flight ${k}`))
		if (!got) {
			console.log('no flight', k)
			break
		}
		const f = sim.dbg.meteor
		console.log('flight', k, 'at', ((sim.clock.now - revealAt) / 1000).toFixed(1), 's:', Math.round(f.length), 'px', f.duration.toFixed(2), 's nearCopy', f.nearCopy, 'events so far', steps)
		steps = 0
		sim.until(sim.clock.now + (f.duration + 1) * 1000, guard(`flight ${k}`))
		console.log('  flown; events', steps, 'meteor', !!sim.dbg.meteor, 'nextMeteorAt', sim.dbg.nextMeteorAt.toFixed(1))
	}
} catch (e) {
	console.log('ERROR', e.message)
}
