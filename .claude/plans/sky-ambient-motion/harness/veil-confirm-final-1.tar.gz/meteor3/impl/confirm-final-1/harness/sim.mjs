// Runs the REAL transpiled sky worker (pure/components-sky/sky.worker.dbg.mjs) in Node on a fake clock, with a recording 2D
// context, so worker behavior (launch, scroll, layout messages, draws) can be observed without a browser.
// Observation only. Usage: const sim = await createSim({ width, height, seed }); sim.send(msg); sim.advance(ms)
import { pathToFileURL } from 'node:url'
import { HERE } from '../lib.mjs'

const FRAME_MS = 1000 / 60
let instance = 0

class FakeCtx {
	constructor() {
		this.globalAlpha = 1
		this.globalCompositeOperation = 'source-over'
		this.fillStyle = null
		this.strokeStyle = null
		this.frame = { meteorImages: [], gradients: [], fills: [], strokes: [], stars: [] }
		this.meteorY = Infinity
	}
	fillRect() { this.frame = { meteorImages: [], gradients: [], fills: [], strokes: [], stars: [] } }
	drawImage(image, ...a) {
		if (a.length === 8 && a[1] >= this.meteorY) this.frame.meteorImages.push({ alpha: this.globalAlpha, sx: a[0], sy: a[1], size: a[2], cx: a[4] + a[6] / 2, cy: a[5] + a[7] / 2 })
		else if (a.length === 8 && this.recordStars) this.frame.stars.push({ alpha: this.globalAlpha, cx: a[4] + a[6] / 2, cy: a[5] + a[7] / 2 })
	}
	createLinearGradient(...a) {
		const g = { args: a, stops: [], addColorStop(offset, color) { this.stops.push([offset, color]) } }
		this.frame.gradients.push(g)
		return g
	}
	fill() { if (this.fillStyle && this.fillStyle.stops) this.frame.fills.push({ gradient: this.fillStyle, alpha: this.globalAlpha }) }
	stroke() { if (this.strokeStyle && this.strokeStyle.stops) this.frame.strokes.push({ gradient: this.strokeStyle, alpha: this.globalAlpha, width: this.lineWidth }) }
	beginPath() {}
	moveTo() {}
	lineTo() {}
	closePath() {}
	putImageData() {}
}
class FakeCanvas {
	constructor(w, h) {
		this.width = w
		this.height = h
		this.ctx = new FakeCtx()
	}
	getContext() { return this.ctx }
	transferToImageBitmap() { return { width: this.width, height: this.height, close() {} } }
	addEventListener() {}
}

/** rgba(r,g,b,a) -> a */
export const alphaOf = (color) => Number(/rgba\(([^)]*)\)/.exec(color)?.[1].split(',')[3] ?? NaN)

export async function createSim({ width = 1440, height = 900, dpr = 1, seed = 1, startMs = 10000, tree = 'proto' } = {}) {
	const id = ++instance
	const clock = { now: startMs }
	const timers = []
	const rafs = []
	let next = 1
	Object.defineProperty(globalThis, 'performance', { value: { now: () => clock.now, timeOrigin: 0 }, configurable: true, writable: true })
	globalThis.setTimeout = (fn, ms = 0) => { const h = next++; timers.push({ at: clock.now + Math.max(0, ms), h, fn }); return h }
	globalThis.clearTimeout = (h) => { const i = timers.findIndex((t) => t.h === h); if (i >= 0) timers.splice(i, 1) }
	let seedState = seed >>> 0
	Math.random = () => {
		seedState = (seedState + 0x6d2b79f5) >>> 0
		let t = seedState
		t = Math.imul(t ^ (t >>> 15), t | 1)
		t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
		return ((t ^ (t >>> 14)) >>> 0) / 4294967296
	}
	let listener = null
	const posted = []
	globalThis.self = {
		postMessage: (m) => posted.push(m),
		addEventListener: (type, fn) => { if (type === 'message') listener = fn },
		requestAnimationFrame: (cb) => { const h = next++; rafs.push({ at: Math.max(clock.now + 0.01, (Math.floor(clock.now / FRAME_MS) + 1) * FRAME_MS), h, cb }); return h },
		cancelAnimationFrame: (h) => { const i = rafs.findIndex((r) => r.h === h); if (i >= 0) rafs.splice(i, 1) },
	}
	globalThis.OffscreenCanvas = FakeCanvas
	globalThis.ImageData = class { constructor(w, h) { this.width = w; this.height = h; this.data = new Uint8ClampedArray(w * h * 4) } }

	await import(pathToFileURL(`${HERE}/pure/${tree}/components-sky/sky.worker.dbg.mjs`).href + `?sim=${id}`)
	const dbg = globalThis.__skyDbg
	const canvas = new FakeCanvas(width, height)
	const tokens = { navy: [10, 25, 47], white: [230, 241, 255], green: [100, 255, 218], card2: [60, 103, 227], card3: [78, 0, 194] }
	const frames = [] // one entry per draw that included a meteor: { t, scrollY, meteorImages, fills, strokes }
	const originalFillRect = canvas.ctx.fillRect.bind(canvas.ctx)
	canvas.ctx.fillRect = function (...a) {
		// a new frame starts at the navy fill; remember the previous one if it carried a meteor
		const prev = canvas.ctx.frame
		if (sim.recordStars && prev && prev.t !== undefined) sim.starFrames.push({ t: prev.t, stars: prev.stars })
		if (prev && prev.meteorImages.length + prev.fills.length + prev.strokes.length > 0) frames.push({ ...prev, t: prev.t })
		originalFillRect(...a)
		canvas.ctx.frame.t = clock.now / 1000
		canvas.ctx.frame.scrollY = dbg.scrollY
	}
	const sim = {
		clock, dbg, posted, frames, canvas, tokens,
		// While recordStars is true, every frame's star draws {alpha, cx, cy} go to starFrames ({ t, stars }), the previous frame at each new one
		recordStars: false,
		starFrames: [],
		send(message) {
			if (message.type === 'init') message = { canvas, width, height, dpr, tokens, emerging: true, revealed: false, motion: 'full', visible: true, contrastMore: false, scrollY: 0, ...message }
			listener({ data: message })
			canvas.ctx.meteorY = dbg.assets ? dbg.assets.atlas.meteorCore.y : Infinity
		},
		advance(ms) { sim.until(clock.now + ms) },
		until(target, stop = null) {
			for (;;) {
				const t = timers.reduce((a, b) => (!a || b.at < a.at ? b : a), null)
				const r = rafs.reduce((a, b) => (!a || b.at < a.at ? b : a), null)
				const e = t && r ? (t.at <= r.at ? t : r) : t ?? r
				if (!e || e.at > target) break
				clock.now = e.at
				if (e === t) { timers.splice(timers.indexOf(t), 1); t.fn() }
				else { rafs.splice(rafs.indexOf(r), 1); r.cb(clock.now) }
				if (stop && stop()) return true
			}
			clock.now = target
			return false
		},
		flush() {
			// push the frame in progress, if it carried a meteor
			const f = canvas.ctx.frame
			if (f && f.meteorImages.length + f.fills.length + f.strokes.length > 0 && frames.at(-1)?.t !== f.t) frames.push({ ...f })
			if (sim.recordStars && f && f.t !== undefined && sim.starFrames.at(-1)?.t !== f.t) sim.starFrames.push({ t: f.t, stars: f.stars })
		},
	}
	// The recording context reads the flag live, so draws made by timers between messages are recorded too
	Object.defineProperty(canvas.ctx, 'recordStars', { get: () => sim.recordStars })
	return sim
}
