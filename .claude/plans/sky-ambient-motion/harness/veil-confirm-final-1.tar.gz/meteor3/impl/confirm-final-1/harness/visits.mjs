// Visits under the REAL worker policy (fake clock): launch timing, the sticky radiant, the gates. For each visit the first
// `FLIGHTS` shooting stars are recorded as the worker planned them and scored with the model's walk: does the head spend at
// least 0.1 s on copy adding METEOR_PASS.visible (0.12) white or more? Compares the repository's worker with the proposed one.
//   node harness/visits.mjs [visits] [flights] [label]
import fs from 'node:fs'
import { HERE, ZONES, P, B, loadCapture, walkProto, walkBase, textRects, insideRect } from '../lib.mjs'
import { createSim } from './sim.mjs'

const VISITS = Number(process.argv[2] ?? 60)
const FLIGHTS = Number(process.argv[3] ?? 3)
const label = process.argv[4] ?? '1440x900@1'
const capture = loadCapture(label)
const raw = JSON.parse(fs.readFileSync(`${ZONES}/${label}.json`, 'utf8'))
const headrooms = { quiet: capture.quiet.map((r) => r.headroom), pinned: capture.pinned.map((r) => r.headroom) }
const layouts = raw.layouts
	.filter((l) => l.quiet.length > 0)
	.map((l) => ({ ...l, quiet: l.quiet.map((r, i) => ({ ...r, headroom: headrooms.quiet[i] ?? 0 })), pinned: l.pinned.map((r, i) => ({ ...r, headroom: headrooms.pinned[i] ?? 0 })) }))

for (const tree of (process.env.TREES ?? 'base,proto').split(',')) {
	const lib = tree === 'base' ? B : P
	const zones = lib.screenQuietZones(capture.quiet, 0, capture.pinned)
	const walk = tree === 'base' ? walkBase : walkProto
	let flights = 0
	let passes = 0
	let visitsWithPass = 0
	let shortFlights = 0
	const lengths = []
	const firsts = []
	for (let seed = 1; seed <= VISITS; seed++) {
		const started = Date.now()
		const sim = await createSim({ width: capture.width, height: capture.height, dpr: capture.dpr, seed, tree })
		sim.send({ type: 'init' })
		sim.advance(3800)
		sim.send({ type: 'reveal' })
		const revealAt = sim.clock.now
		let li = 0
		let seen = 0
		let any = false
		let last = null
		const due = () => {
			while (li < layouts.length && sim.clock.now - revealAt >= layouts[li].msAfterReveal) {
				sim.send({ type: 'layout', documentHeight: layouts[li].documentHeight, quiet: layouts[li].quiet, pinned: layouts[li].pinned })
				li++
			}
			const m = sim.dbg.meteor
			if (m && m !== last) {
				last = m
				return true
			}
			return false
		}
		while (seen < FLIGHTS && sim.until(sim.clock.now + 200000, due)) {
			const f = { ...sim.dbg.meteor }
			seen++
			flights++
			lengths.push(f.length)
			if (seen === 1) firsts.push((sim.clock.now - revealAt) / 1000)
			if (f.duration <= B.METEOR.fallbackDuration[1] + 1e-9) shortFlights++
			const w = walk(f, zones, 400)
			const onCopyVisible = (w.filter((s) => s.onCopy && s.rise >= P.METEOR_PASS.visible).length / 400) * f.duration
			if (onCopyVisible >= 0.1) {
				passes++
				any = true
			}
			// let the flight finish before waiting for the next one
			sim.advance((f.duration + 1) * 1000)
		}
		if (any) visitsWithPass++
		if (process.env.VERBOSE) console.log(tree, 'visit', seed, 'flights', seen, 'ms', Date.now() - started, 'heapMB', Math.round(process.memoryUsage().heapUsed / 1e6))
	}
	const med = (a) => [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)]
	console.log(`${label} ${tree.padEnd(5)}: ${VISITS} visits, ${flights} flights; passes behind copy ${((100 * passes) / flights).toFixed(0)}% of flights; visits with at least one pass in their first ${FLIGHTS}: ${((100 * visitsWithPass) / VISITS).toFixed(0)}%; shorter fallback flights ${shortFlights}; median path ${med(lengths).toFixed(0)} px; first flight ${med(firsts).toFixed(1)} s after the reveal`)
}
