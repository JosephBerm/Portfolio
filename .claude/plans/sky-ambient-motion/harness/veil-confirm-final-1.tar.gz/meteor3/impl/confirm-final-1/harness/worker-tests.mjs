// Runs the REAL transpiled workers (base: the repository's, proto: the proposed) on a fake clock with a recording 2D context:
//   C2  a layout message that arrives mid-ease: the largest change of any quiet factor in one frame, around the second message;
//       and the final state: after any run of messages the worker holds the last layout posted (c2final)
//   C1  a scroll while a shooting star is in the air: is it still drawn, and how bright is its head over copy the veil doesn't know
//   C4  radiant policy: how often a launch ends in the shorter fallback flight
// Observation only. Usage: node worker-tests.mjs [c1|c2|c2final|c4|all]
import fs from 'node:fs'
import { pathToFileURL } from 'node:url'
import { HERE, ZONES, P, B, loadCapture, NAVY, WHITE } from '../lib.mjs'
import { createSim, alphaOf } from './sim.mjs'

const which = process.argv[2] ?? 'all'
const WIDTH = 1440
const HEIGHT = 900
const raw = JSON.parse(fs.readFileSync(`${ZONES}/${WIDTH}x${HEIGHT}@1.json`, 'utf8'))
const capture = loadCapture(`${WIDTH}x${HEIGHT}@1`)
// The capture's layout messages in order (the first at +6 ms with the entrance still running), with the headroom of each rect by index
const headrooms = { quiet: capture.quiet.map((r) => r.headroom), pinned: capture.pinned.map((r) => r.headroom) }
const layouts = raw.layouts
	.filter((l) => l.quiet.length > 0)
	.map((l) => ({
		...l,
		quiet: l.quiet.map((r, i) => ({ ...r, headroom: headrooms.quiet[i] ?? 0 })),
		pinned: l.pinned.map((r, i) => ({ ...r, headroom: headrooms.pinned[i] ?? 0 })),
	}))
const mid = layouts[0]
const settled = layouts.at(-1)
const lib = { base: B, proto: P }

// ---------- C2 ----------
if (which === 'c2' || which === 'all') {
	console.log('\n=== C2: layout message mid-ease ===')
	const probes = []
	for (let y = 150; y <= 700; y += 10) for (let x = 100; x <= 1150; x += 10) probes.push([x, y])
	for (const tree of ['base', 'proto']) {
		const L = lib[tree]
		const keeps = { near: L.LAYERS.near, mid: L.LAYERS.mid, far: L.LAYERS.far, meteor: tree === 'base' ? L.METEOR_VEIL : L.budgetKeeps(0.6, L.METEOR_VEIL.quietKeep) }
		keeps.meteorEased = keeps.meteor
		// What each part draws through: the stars' cross-fade; the shooting star's own (transientQuietFactor, where the tree has it: the plan's drew it through the cross-fade)
		const factorOf = (name) => (name === 'meteor' && L.transientQuietFactor ? L.transientQuietFactor : L.easedQuietFactor)
		// (meteorEased is the same probe through the cross-fade, as the plan drew the shooting star: shown beside it)
		for (const delayMs of [1495, 300, 100]) {
			const sim = await createSim({ width: WIDTH, height: HEIGHT, seed: 3, tree })
			sim.send({ type: 'init' })
			sim.advance(3800)
			sim.send({ type: 'reveal' })
			sim.advance(6)
			sim.send({ type: 'layout', documentHeight: mid.documentHeight, quiet: mid.quiet, pinned: mid.pinned })
			sim.advance(delayMs)
			// the largest change of any factor between two frames, from the frame before the second message through the next 2.6 s
			const sample = () => {
				const blend = sim.dbg.quietBlend(sim.clock.now / 1000)
				const out = {}
				for (const [name, k] of Object.entries(keeps)) out[name] = probes.map(([x, y]) => factorOf(name)(blend, x, y, k))
				return out
			}
			let prev = sample()
			sim.send({ type: 'layout', documentHeight: settled.documentHeight, quiet: settled.quiet, pinned: settled.pinned })
			const worst = { near: 0, mid: 0, far: 0, meteor: 0, meteorEased: 0 }
			{
				const cur = sample()
				for (const name of Object.keys(keeps)) worst[name] = Math.max(worst[name], ...cur[name].map((v, i) => Math.abs(v - prev[name][i])))
				prev = cur
			}
			for (let t = 0; t < 2600; t += 16) {
				sim.advance(16)
				const cur = sample()
				for (const name of Object.keys(keeps)) worst[name] = Math.max(worst[name], ...cur[name].map((v, i) => Math.abs(v - prev[name][i])))
				prev = cur
			}
			console.log(`${tree.padEnd(5)} second layout ${String(delayMs).padStart(4)} ms after the first: largest one-frame change over the next 2.6 s: near ${worst.near.toFixed(3)} mid ${worst.mid.toFixed(3)} far ${worst.far.toFixed(3)} | shooting star ${worst.meteor.toFixed(3)} (through the cross-fade alone ${worst.meteorEased.toFixed(3)})`)
		}
	}
	console.log('(a clean 0.6 s ease moves a factor by at most about 0.03 per 16 ms frame)')
}

// ---------- C2, final state ----------
// The deferral must never leave the worker on a stale layout: after any run of layout messages the zones are the last ones posted
// (the main thread posts only changes, so nothing would correct a stale one later).
if (which === 'c2' || which === 'c2final' || which === 'all') {
	console.log('\n=== C2, final state: the worker ends on the last layout posted ===')
	const shift = (rects, dy) => rects.map((r) => ({ ...r, y: r.y + dy }))
	const flow = Array.from({ length: 12 }, (_, i) => ({ x: 150, y: 230 + i * 40, width: 600, height: 30, headroom: 0.19 }))
	const rails = Array.from({ length: 3 }, (_, i) => ({ x: 20, y: 700 + i * 20, width: 120, height: 14, headroom: 0.19 }))
	const layoutOf = (k) => ({ documentHeight: 5000 + k, quiet: shift(flow, k), pinned: shift(rails, -k) })
	const holds = (sim, k) => JSON.stringify(sim.dbg.quiet) === JSON.stringify(layoutOf(k).quiet) && JSON.stringify(sim.dbg.pinned) === JSON.stringify(layoutOf(k).pinned)
	const start = async (seed) => {
		// TREE=r1 runs the earlier proposal (node transpile-r1.mjs builds it): these tests fail there
		const sim = await createSim({ width: WIDTH, height: HEIGHT, seed, tree: process.env.TREE ?? 'proto' })
		sim.send({ type: 'init' })
		sim.advance(3800)
		sim.send({ type: 'reveal' })
		sim.advance(6)
		return sim
	}
	const post = (sim, k) => sim.send({ type: 'layout', ...layoutOf(k) })
	// (a) a layout held mid-ease, the tab hidden, a newer layout after the ease, the tab back
	{
		const sim = await start(5)
		post(sim, 1)
		sim.advance(300)
		post(sim, 2)
		const held = !!sim.dbg.pendingLayout
		sim.send({ type: 'visible', visible: false })
		sim.advance(1000)
		post(sim, 3)
		const rightAfter = holds(sim, 3) && !sim.dbg.pendingLayout
		sim.send({ type: 'visible', visible: true })
		sim.advance(3000)
		console.log(`(a) hidden tab: L2 held mid-ease ${held}; right after L3 the worker holds L3 with nothing waiting ${rightAfter}; 3 s after the tab returns it holds L3: ${holds(sim, 3)}`)
	}
	// (b) a window-edge drag: n layouts 16 ms apart (flow and rails both change), then nothing; every length from 20 to 140
	{
		let stale = 0
		const examples = []
		for (let n = 20; n <= 140; n++) {
			const sim = await start(n)
			for (let k = 1; k <= n; k++) {
				post(sim, k)
				sim.advance(16)
			}
			sim.advance(5000)
			if (!holds(sim, n) || sim.dbg.pendingLayout) {
				stale++
				if (examples.length < 4) examples.push(n)
			}
		}
		console.log(`(b) drag of 20-140 layouts 16 ms apart: ${stale} of 121 end on a stale layout${stale ? ' (' + examples.join(', ') + ' messages)' : ''}`)
	}
	// (c) a third layout that lands around the end of the ease (every 4 ms from 520 to 700 ms after the first; the ease ends at 600)
	{
		let stale = 0
		let runs = 0
		for (let gap = 520; gap <= 700; gap += 4) {
			const sim = await start(gap)
			post(sim, 1)
			sim.advance(100)
			post(sim, 2)
			sim.advance(gap - 100)
			post(sim, 3)
			sim.advance(2500)
			runs++
			if (!holds(sim, 3) || sim.dbg.pendingLayout) stale++
		}
		console.log(`(c) third layout 520-700 ms after the first, every 4 ms: ${stale} of ${runs} end on a stale layout`)
	}
	// (d) a message that goes back to the layout in force while another one waits: it wins, and an identical message restarts no ease
	{
		const sim = await start(9)
		post(sim, 1)
		sim.advance(200)
		post(sim, 2)
		post(sim, 1)
		sim.advance(2500)
		const reverted = holds(sim, 1)
		const at = sim.dbg.layoutAt
		post(sim, 1)
		sim.advance(100)
		console.log(`(d) revert while another waits: ends on the reverted layout ${reverted}; an identical message restarts no ease ${sim.dbg.layoutAt === at}`)
	}
}

// ---------- C1 ----------
if (which === 'c1' || which === 'all') {
	console.log('\n=== C1: scroll while a shooting star is in the air ===')
	const unquiet = JSON.parse(fs.readFileSync(`${ROOT_UNQUIET()}`, 'utf8'))
	function ROOT_UNQUIET() {
		return `${HERE}/../../code-logic/unquiet/${WIDTH}x${HEIGHT}@1.json`
	}
	const smooth = (t) => {
		const x = Math.min(1, Math.max(0, t))
		return x * x * (3 - 2 * x)
	}
	const lin = (c) => {
		const v = c / 255
		return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4
	}
	const lum = (c) => 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2])
	const contrast = (a, b) => (Math.max(lum(a), lum(b)) + 0.05) / (Math.min(lum(a), lum(b)) + 0.05)
	const over = (rise) => NAVY.map((c, k) => Math.min(255, c + rise * WHITE[k]))
	const SLATE = [136, 146, 176]
	async function run(tree, seed, { jump = 0, delay = 250, over: ms = 400 } = {}) {
		const sim = await createSim({ width: WIDTH, height: HEIGHT, seed, tree })
		sim.send({ type: 'init' })
		sim.advance(3800)
		sim.send({ type: 'reveal' })
		const revealAt = sim.clock.now
		let li = 0
		const layoutsDue = () => {
			while (li < layouts.length && sim.clock.now - revealAt >= layouts[li].msAfterReveal) {
				sim.send({ type: 'layout', documentHeight: layouts[li].documentHeight, quiet: layouts[li].quiet, pinned: layouts[li].pinned })
				li++
			}
			return !!sim.dbg.meteor
		}
		if (!sim.until(revealAt + 20000, layoutsDue)) return null
		const launch = { ...sim.dbg.meteor }
		const launchAt = sim.clock.now
		let y = 0
		const end = launchAt + (launch.duration + 0.6) * 1000
		let done = jump === 0
		const rows = []
		let cancelledAt = null
		while (sim.clock.now < end) {
			const since = sim.clock.now - launchAt
			if (!done) {
				const target = jump * smooth((since - delay) / ms)
				if (Math.abs(target - y) >= 1) {
					y = target
					sim.send({ type: 'scroll', y })
				}
				if (since - delay >= ms) done = true
			}
			sim.advance(16)
			sim.flush()
			if (cancelledAt === null && !sim.dbg.meteor) cancelledAt = since
		}
		sim.flush()
		for (const f of sim.frames) {
			const core = f.meteorImages.find((i) => i.size === 7)
			const glow = f.meteorImages.find((i) => i.size === 19)
			if (!core) continue
			const headFill = f.fills.map((x) => x.alpha * alphaOf(x.gradient.stops[0][1]))
			const rise = core.alpha + (glow?.alpha ?? 0) + headFill.reduce((a, b) => a + b, 0)
			let hit = null
			for (const l of unquiet.lines) {
				const top = l.y - f.scrollY
				if (core.cx >= l.x - 2 && core.cx <= l.x + l.w + 2 && core.cy >= top - 2 && core.cy <= top + l.h + 2) {
					hit = { text: l.text }
					break
				}
			}
			rows.push({ t: f.t - launch.startedAt, scrollY: f.scrollY, rise, hit })
		}
		return { launch, rows, cancelledAt }
	}
	const variants = [
		['nav click +900 px over 700 ms, 250 ms after launch', { jump: 900, over: 700, delay: 250 }],
		['PageDown +750 px over 450 ms, 250 ms after launch', { jump: 750, over: 450, delay: 250 }],
		['wheel flick +360 px over 300 ms, 400 ms after launch', { jump: 360, over: 300, delay: 400 }],
		['trackpad creep +10 px over 400 ms, 300 ms after launch', { jump: 10, over: 400, delay: 300 }],
	]
	for (const [name, opts] of variants) {
		for (const tree of ['base', 'proto']) {
			let n = 0
			let over_ = 0
			let maxRise = 0
			let minSlate = 99
			let cancelled = 0
			let framesLate = 0
			for (let seed = 1; seed <= Number(process.env.SEEDS ?? 30); seed++) {
				const r = await run(tree, seed, opts)
				if (!r) continue
				n++
				if (r.cancelledAt !== null && r.cancelledAt < (r.launch.duration + 0.3) * 1000) cancelled++
				const on = r.rows.filter((x) => x.hit)
				if (on.length) {
					over_++
					const top = on.reduce((a, b) => (b.rise > a.rise ? b : a))
					maxRise = Math.max(maxRise, top.rise)
					minSlate = Math.min(minSlate, contrast(SLATE, over(top.rise)))
				}
				framesLate += r.rows.filter((x) => x.scrollY >= 24).length
			}
			console.log(`${tree.padEnd(5)} ${name}: ${n} flights, cancelled mid-flight ${cancelled}, head over copy the veil doesn't know in ${over_}; frames drawn at 24 px or more from launch ${framesLate}${over_ ? `; worst head rise ${maxRise.toFixed(2)} -> slate body ${minSlate.toFixed(2)}:1` : ''}`)
		}
	}
}

// ---------- C4 ----------
if (which === 'c4' || which === 'all') {
	console.log('\n=== C4: radiant policy: shorter fallback flights per launch (worker policy, real planners) ===')
	const { pickRadiant, planMeteor } = P
	for (const label of ['1280x800@1', '1280x720@1', '1024x768@1', '1366x768@1', '1440x900@1', '390x844@3m']) {
		const cap = loadCapture(label)
		const narrow = cap.width <= P.NARROW_MAX_WIDTH
		const tries = narrow ? 1 : P.METEOR.radiantTries
		const sessions = 300
		const launches = 8
		let planned = 0
		let shortOld = 0
		let shortNew = 0
		let total = 0
		for (const policy of ['old', 'new']) {
			const random = P.mulberry32(0x77 + cap.width)
			const field = { width: cap.width, height: cap.height, quiet: P.screenQuietZones(cap.quiet, 0, cap.pinned) }
			const baseField = { width: cap.width, height: cap.height, quiet: B.screenQuietZones(cap.quiet, 0, cap.pinned) }
			for (let s = 0; s < sessions; s++) {
				let radiant = null
				for (let l = 0; l < launches; l++) {
					total += policy === 'old' ? 1 : 0
					let plan = null
					if (policy === 'old') {
						// the repository's worker: keep the radiant while planMeteor (long, then short, on one radiant) yields, else fresh ones
						plan = radiant ? B.planMeteor(random, baseField, radiant, 0) : null
						for (let t = 0; !plan && t < tries; t++) {
							radiant = B.pickRadiant(random, cap.width, cap.height)
							plan = B.planMeteor(random, baseField, radiant, 0)
						}
						if (!plan) radiant = null
						else {
							planned++
							if (plan.duration <= (narrow ? B.METEOR.narrowFallbackDuration[1] : B.METEOR.fallbackDuration[1])) shortOld++
						}
					} else {
						const radiants = radiant ? [radiant] : []
						while (radiants.length < (radiant ? 1 : 0) + tries) radiants.push(pickRadiant(random, cap.width, cap.height))
						outer: for (const flights of ['long', 'short']) {
							for (const candidate of radiants) {
								plan = planMeteor(random, field, candidate, 0, { flights })
								if (plan) {
									radiant = candidate
									break outer
								}
							}
						}
						if (!plan) radiant = null
						else if (plan.duration <= (narrow ? P.METEOR.narrowFallbackDuration[1] : P.METEOR.fallbackDuration[1])) shortNew++
					}
				}
			}
		}
		const n = sessions * launches
		console.log(`${label.padEnd(13)} launches ${n}: planned old ${(100 * planned) / n | 0}%; shorter fallback flights old ${((100 * shortOld) / n).toFixed(1)}% -> new ${((100 * shortNew) / n).toFixed(1)}%`)
	}
}
