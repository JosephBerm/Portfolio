// How much of the white budget does the real haze already use under each copy? For every text rect of every captured viewport the
// brightest background pixel (navy plus the real haze, rendered by the real skyAssets/renderSky in Chromium) is converted to the
// white alpha that gives the same luminance over navy: that is the haze's share of the copy's headroom (the hazeReserve).
import fs from 'node:fs'
import path from 'node:path'
import { launch } from '../../code-logic/lib.mjs'
import { HERE, loadCapture, textRects, kindOf, NAVY, WHITE } from './lib.mjs'

const labels = ['1024x768@1', '1280x720@1', '1280x800@1', '1366x768@1', '1440x900@1', '1536x864@1.25', '1920x1080@1', '2560x1440@1', '390x844@3m']
const PAGE = '<!doctype html><meta charset="utf-8"><body></body>'
const TOKENS = { navy: [10, 25, 47], white: [230, 241, 255], green: [100, 255, 218], card2: [60, 103, 227], card3: [78, 0, 194] }

const browser = await launch()
try {
	const context = await browser.newContext({ viewport: { width: 800, height: 600 } })
	await context.route('http://sky.test/**', async (route) => {
		const url = new URL(route.request().url())
		if (url.pathname === '/') return route.fulfill({ contentType: 'text/html', body: PAGE })
		const file = path.resolve(HERE, '.' + decodeURIComponent(url.pathname))
		if (path.relative(HERE, file).startsWith('..') || !fs.existsSync(file)) return route.fulfill({ status: 404, body: 'missing' })
		return route.fulfill({ contentType: 'text/javascript', body: fs.readFileSync(file, 'utf8') })
	})
	const page = await context.newPage()
	await page.goto('http://sky.test/')
	console.log('viewport | worst haze white-equivalent under any copy rect (kind) | brightest haze pixel on the whole screen')
	let worstOverall = 0
	const byKind = {}
	for (const label of labels) {
		const capture = loadCapture(label)
		const rects = textRects(capture).filter((r) => r.y < capture.height)
		const result = await page.evaluate(
			async ({ width, height, dpr, rects, tokens }) => {
				const { drawSky, createStarField } = await import('/pure/proto/components-sky/renderSky.mjs')
				const { buildStarAtlas, buildHaze, starPalette } = await import('/pure/proto/components-sky/skyAssets.mjs')
				const W = Math.round(width * dpr)
				const H = Math.round(height * dpr)
				const canvas = new OffscreenCanvas(W, H)
				const ctx = canvas.getContext('2d', { alpha: false, willReadFrequently: true })
				const assets = { atlas: buildStarAtlas(dpr, tokens), haze: buildHaze(width, height, tokens), palette: starPalette(tokens), tokens }
				drawSky(ctx, assets, createStarField(), { time: 0, width, height, dpr, deviceWidth: W, deviceHeight: H, parallaxScroll: 0, keep: 0, layers: { far: 0, mid: 0, near: 0 }, dusk: Infinity, twinkle: 0, haze: 1, quiet: { from: [], to: [], level: 1 }, meteorInk: 1, meteorScroll: 1 })
				const data = ctx.getImageData(0, 0, W, H).data
				const lin = (c) => {
					const v = c / 255
					return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4
				}
				const lum = (r, g, b) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
				const navyL = lum(...tokens.navy)
				const alphaFor = (L) => {
					let lo = 0
					let hi = 1
					for (let i = 0; i < 30; i++) {
						const mid = (lo + hi) / 2
						const l = lum(Math.min(255, tokens.navy[0] + tokens.white[0] * mid), Math.min(255, tokens.navy[1] + tokens.white[1] * mid), Math.min(255, tokens.navy[2] + tokens.white[2] * mid))
						if (l < L) lo = mid
						else hi = mid
					}
					return (lo + hi) / 2
				}
				const perRect = rects.map((r) => {
					let best = 0
					for (let y = Math.max(0, Math.floor(r.y * dpr)); y < Math.min(H, Math.ceil((r.y + r.height) * dpr)); y++) {
						for (let x = Math.max(0, Math.floor(r.x * dpr)); x < Math.min(W, Math.ceil((r.x + r.width) * dpr)); x += 1) {
							const i = (y * W + x) * 4
							const L = lum(data[i], data[i + 1], data[i + 2])
							if (L > best) best = L
						}
					}
					return alphaFor(best)
				})
				let brightest = 0
				for (let i = 0; i < data.length; i += 4 * 7) brightest = Math.max(brightest, lum(data[i], data[i + 1], data[i + 2]))
				return { perRect, screen: alphaFor(brightest), navyL }
			},
			{ width: capture.width, height: capture.height, dpr: 1, rects: rects.map((r) => ({ x: r.x, y: r.y, width: r.width, height: r.height })), tokens: TOKENS }
		)
		let worst = 0
		let kind = ''
		result.perRect.forEach((a, i) => {
			const k = kindOf(rects[i].desc)
			byKind[k] = Math.max(byKind[k] ?? 0, a)
			if (a > worst) {
				worst = a
				kind = kindOf(rects[i].desc)
			}
		})
		worstOverall = Math.max(worstOverall, worst)
		console.log(label.padEnd(14), worst.toFixed(4), `(${kind})`.padEnd(22), result.screen.toFixed(4))
	}
	console.log('worst haze by kind of copy over all viewports:', JSON.stringify(Object.fromEntries(Object.entries(byKind).map(([k, v]) => [k, +v.toFixed(4)]))))
	console.log('worst haze under any copy rect over all viewports:', worstOverall.toFixed(4), ' (INK_BUDGET.hazeReserve = 0.025)')
} finally {
	await browser.close()
}
