// Shared helpers for the fix-plan prototype: loads the base (repository) and proto (proposed) sky models, builds planner
// fields from the live captures (rects with their WCAG headroom), and walks a flight the way the renderer draws it.
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

export const ROOT = 'C:/Users/josep/AppData/Local/Temp/claude/S--Documents-repos-Portfolio/f159339c-8cb2-444a-916b-251e57be791d/scratchpad/starfield/meteor3'
export const HERE = `${ROOT}/impl/confirm-final-1`
export const ZONES = `${ROOT}/code-logic/zones`
export const NAVY = [10, 25, 47]
export const WHITE = [230, 241, 255]

const load = async (tree, name) => import(pathToFileURL(path.join(HERE, 'pure', tree, 'lib-sky', name + '.mjs')).href)
// PTREE=plan runs the scripts against the plan's proposed files (plan/proto) instead of the repository, for before and after
export const PTREE = process.env.PTREE ?? 'proto'
export const P = { ...(await load(PTREE, 'catalog')), ...(await load(PTREE, 'meteors')), ...(await load(PTREE, 'scene')), ...(await load(PTREE, 'config')), ...(await load(PTREE, 'random')), ...(await load(PTREE, 'color')) }
export const B = { ...(await load('base', 'meteors')), ...(await load('base', 'scene')), ...(await load('base', 'config')), ...(await load('base', 'random')) }

/** The captured layout of a viewport: width, height, dpr and the quiet rects (document coordinates) with the page's own description of each. */
export function loadCapture(label) {
	const data = JSON.parse(fs.readFileSync(`${ZONES}/${label}.json`, 'utf8'))
	const flowSource = data.settled.quiet
	const pinnedSource = data.settled.pinned
	// described = pinned rects first, then the flow rects, in the same walk order as settled.pinned and settled.quiet
	const described = data.described.rects
	const pinnedDescribed = described.filter((d) => d.pinned)
	const flowDescribed = described.filter((d) => !d.pinned)
	const check = (rect, d) => {
		const close = (a, b) => Math.abs(a - b) <= 1.2
		if (!(close(rect.x, d.rect.x) && close(rect.y, d.rect.y) && close(rect.width, d.rect.width) && close(rect.height, d.rect.height))) throw new Error(`${label}: described rect does not match ${JSON.stringify(rect)} vs ${JSON.stringify(d.rect)}`)
	}
	const withHeadroom = (rect, d) => {
		check(rect, d)
		const color = P.parseRgbColor(d.color, NAVY)
		const minimum = P.minimumContrast(d.fontSize, Number(d.fontWeight))
		const headroom = color ? P.lightHeadroom(color, NAVY, WHITE, minimum) : 0
		return { ...rect, headroom, _desc: d }
	}
	const quiet = flowSource.map((r, i) => withHeadroom(r, flowDescribed[i]))
	const pinned = pinnedSource.map((r, i) => withHeadroom(r, pinnedDescribed[i]))
	return { label, width: data.width, height: data.height, dpr: data.dpr, mobile: data.mobile, quiet, pinned, documentHeight: data.settled.documentHeight }
}

/** Planner field for a capture at scroll 0 (the proto's zones carry their headroom). */
export function fieldOf(capture, lib = P) {
	return { width: capture.width, height: capture.height, quiet: lib.screenQuietZones(capture.quiet, 0, capture.pinned) }
}

/** Text rects on screen at scroll 0 (hero and rails only), unpadded, with their description. */
export function textRects(capture) {
	return [...capture.quiet.filter((r) => r.y < capture.height), ...capture.pinned].map((r) => ({ x: r.x, y: r.y, width: r.width, height: r.height, headroom: r.headroom, desc: r._desc }))
}

export function insideRect(rect, x, y) {
	return x >= rect.x && x <= rect.x + rect.width && y >= rect.y && y <= rect.y + rect.height
}

/** Short names for the kinds of copy on the page, from the description of a rect. */
export function kindOf(d) {
	const c = d.color
	if (d.tag === 'h1') return 'name 75px'
	if (c === 'rgb(100, 255, 218)') return d.fontSize >= 24 ? 'green large' : 'green small'
	if (c === 'rgb(168, 178, 209)') return 'light slate small'
	if (c === 'rgb(204, 214, 246)') return 'lightest large'
	if (c === 'rgb(136, 146, 176)') return d.fontSize >= 24 ? 'tagline 75px' : 'paragraph 16px'
	return 'other ' + c
}

/**
 * Walks a planned flight at `n` moments exactly as the renderer's veil does for the head pixel: light, the white the head
 * would add unveiled, the share the zones keep and the white it adds. `lib` is a loaded tree (proto or base); the base tree
 * has fixed keeps and halos taking the veil squared.
 */
export function walkProto(flight, zones, n = 600, ink = 1) {
	const out = []
	const boostOf = (p) => (flight.fireball ? P.METEOR_LOOK.fireballGlow : 1) * (flight.flare && p > P.METEOR_LIGHT.flareGlowFrom ? P.METEOR_LIGHT.flareGlow : 1)
	for (let i = 0; i <= n; i++) {
		const p = i / n
		const { x, y } = P.meteorPoint(flight, p)
		const light = flight.peak * P.meteorLight(p, flight.flare)
		const white = light * P.headGain(boostOf(p))
		const kept = P.quietFactor(zones, x, y, P.budgetKeeps(white, P.METEOR_VEIL.quietKeep, ink))
		out.push({ p, x, y, light, white, kept, rise: white * kept, onCopy: P.inkAt(zones, x, y) === 1 })
	}
	return out
}

export function walkBase(flight, zones, n = 600) {
	const out = []
	const veil = B.METEOR_VEIL
	for (let i = 0; i <= n; i++) {
		const p = i / n
		const { x, y } = B.meteorPoint(flight, p)
		const light = flight.peak * B.meteorLight(p, flight.flare)
		const kept = B.quietFactor(zones, x, y, veil)
		const boost = (flight.fireball ? B.METEOR_LOOK.fireballGlow : 1) * (flight.flare && p > B.METEOR_LIGHT.flareGlowFrom ? B.METEOR_LIGHT.flareGlow : 1)
		const rise = light * kept * (2 + (B.METEOR_LOOK.softAlpha + B.METEOR_LOOK.glowAlpha * boost) * kept)
		out.push({ p, x, y, light, kept, rise, onCopy: B.inkAt(zones, x, y) === 1 })
	}
	return out
}

// SET="METEOR_PASS.dwell=0.2,INK_BUDGET.ceiling=0.1" overrides proto config values in memory (experiments only)
for (const item of (process.env.SET ?? '').split(',').filter(Boolean)) {
	const [key, value] = item.split('=')
	const [group, name] = key.split('.')
	P[group][name] = Number(value)
}

export const median = (a) => (a.length ? [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)] : NaN)
export const pct = (a, q) => (a.length ? [...a].sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(q * a.length))] : NaN)
export const fmt = (v, d = 3) => (Number.isFinite(v) ? v.toFixed(d) : '-')
