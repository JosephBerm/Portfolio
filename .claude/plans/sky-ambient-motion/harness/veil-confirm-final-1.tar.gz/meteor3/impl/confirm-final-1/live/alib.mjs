// Live visual and performance audit helpers (auditor's own tooling). Own headless Chromium through playwright-core,
// the dev server at localhost:3000, observation only: no repository file is read or written here.
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
export const PW = 'C:/Users/josep/AppData/Local/npm-cache/_npx/e41f203b7505f1fb/node_modules/playwright-core'
export const pw = require(PW)
export const { PNG } = require(PW + '/lib/utilsBundle.js')
export const HERE = 'C:/Users/josep/AppData/Local/Temp/claude/S--Documents-repos-Portfolio/f159339c-8cb2-444a-916b-251e57be791d/scratchpad/starfield/meteor3/impl/confirm-final-1/live'
export const CHROME = 'C:/Users/josep/AppData/Local/ms-playwright/chromium-1223/chrome-win64/chrome.exe'
export const GPU_ARGS = ['--enable-gpu', '--ignore-gpu-blocklist', '--use-angle=d3d11']
export const TARGET = process.env.TARGET ?? 'http://localhost:3000/'
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

export function launch(args = GPU_ARGS) {
	return pw.chromium.launch({ executablePath: CHROME, headless: true, args })
}

export function parseSpec(spec) {
	const mobile = spec.endsWith('m')
	const [size, ratio] = spec.replace(/m$/, '').split('@')
	const [width, height] = size.split('x').map(Number)
	return { width, height, dsf: Number(ratio ?? 1), mobile, name: `${width}x${height}@${Number(ratio ?? 1)}${mobile ? 'm' : ''}` }
}

// Page side: every message the page posts to a worker (minus canvas and tokens), long tasks, long animation frames and the
// main thread's animation-frame cadence. Observe only.
export const PAGE_INIT = `(() => {
	const now = () => performance.timeOrigin + performance.now()
	const A = (window.__au = { posts: [], long: [], loaf: [], raf: [], rafOn: false })
	const post = Worker.prototype.postMessage
	Worker.prototype.postMessage = function (message, transfer) {
		try {
			const m = { at: now(), type: message.type }
			for (const [k, v] of Object.entries(message)) if (k !== 'canvas' && k !== 'tokens' && k !== 'type') m[k] = v
			A.posts.push(m)
		} catch {}
		return post.call(this, message, transfer)
	}
	try { new PerformanceObserver((l) => { for (const e of l.getEntries()) A.long.push({ at: performance.timeOrigin + e.startTime, ms: e.duration }) }).observe({ type: 'longtask', buffered: true }) } catch {}
	try { new PerformanceObserver((l) => { for (const e of l.getEntries()) A.loaf.push({ at: performance.timeOrigin + e.startTime, ms: e.duration, block: e.blockingDuration, scripts: (e.scripts || []).map((s) => ({ ms: s.duration, inv: s.invoker, src: (s.sourceURL || '').slice(-60), fn: s.sourceFunctionName })) }) }).observe({ type: 'long-animation-frame', buffered: true }) } catch {}
	A.startRaf = () => {
		if (A.rafOn) return
		A.rafOn = true
		const step = (t) => { A.raf.push(performance.timeOrigin + t); if (A.rafOn) requestAnimationFrame(step) }
		requestAnimationFrame(step)
	}
	A.stopRaf = () => { A.rafOn = false }
})()`

export const posts = (page) => page.evaluate(() => window.__au.posts)
export const pageEpoch = (page) => page.evaluate(() => performance.timeOrigin + performance.now())

export async function waitFor(fn, timeout, label, interval = 50) {
	const start = Date.now()
	for (;;) {
		const value = await fn()
		if (value) return value
		if (Date.now() - start > timeout) throw new Error('timeout: ' + label)
		await sleep(interval)
	}
}

export async function skyWorkerOf(workers) {
	for (const w of workers) {
		try {
			if ((await w.evaluate(() => self.name)) === 'sky') return w
		} catch {}
	}
	return null
}

// Worker chunk hook (my own, minimal): wraps planMeteor and drawMeteor to record what the real worker plans and, per drawn
// frame, its time, the scroll fade it was given and the quiet blend level. No pixel copies, so the worker's timing is the
// real one. The wrappers call the bundle's own functions with the same arguments and return their results.
const HOOK = `;(() => {
	if (self.__hk) return
	const epoch = () => performance.timeOrigin + performance.now()
	const H = (self.__hk = { plans: [], frames: [], meteors: [], errors: [], orig: {} })
	self.addEventListener('error', (e) => H.errors.push('error: ' + String(e.message)))
	self.addEventListener('unhandledrejection', (e) => H.errors.push('rejection: ' + String(e.reason && e.reason.message)))
	H.plan = (original, args) => {
		const t0 = performance.now()
		const result = original(...args)
		const ms = performance.now() - t0
		try {
			const field = args[1]
			H.plans.push({ at: epoch(), ms, now: args[3], width: field.width, height: field.height, zones: field.quiet.map((r) => ({ x: r.x, y: r.y, width: r.width, height: r.height, headroom: r.headroom })), options: { ...(args[4] || {}) }, meteor: result ? { ...result } : null })
		} catch (e) { H.errors.push('plan hook: ' + e) }
		return result
	}
	H.sprites = true
	H.draw = (original, args) => {
		const ctx = args[0]
		const meteor = args[2]
		const frame = args[3]
		let index = H.meteors.indexOf(meteor)
		if (index < 0) { index = H.meteors.length; H.meteors.push(meteor) }
		// Optionally the sprite draws of this call (glow, core: position and alpha), through an own property that shadows the prototype for this call only
		const calls = H.sprites ? [] : null
		if (calls) {
			const di = ctx.drawImage
			ctx.drawImage = function (...b) { calls.push([b[5], b[6], b[7], this.globalAlpha]); return di.apply(this, b) }
		}
		const t0 = performance.now()
		let result
		try { result = original(...args) } finally { if (calls) delete ctx.drawImage }
		const ms = performance.now() - t0
		try {
			H.frames.push({ at: epoch(), time: frame.time, meteor: index, fade: args[4] === undefined ? 1 : args[4], level: frame.quiet.level, next: frame.quiet.next ? frame.quiet.next.length : 0, ms, dpr: frame.dpr, w: frame.width, h: frame.height, calls })
		} catch (e) { H.errors.push('draw hook: ' + e) }
		return result
	}
})();\n`

const PLAN_HEAD = 'function planMeteor(random, field, radiant, now, options = {}) {'
const DRAW_HEAD = 'function drawMeteor(ctx, assets, meteor, frame, fade = 1) {'

export function patchChunk(text) {
	if (!text.includes(PLAN_HEAD) || !text.includes(DRAW_HEAD)) return null
	return (
		HOOK +
		text
			.replace(PLAN_HEAD, 'self.__hk.orig.plan = __planMeteor0;\nfunction planMeteor(...a) { return self.__hk.plan(__planMeteor0, a) }\nfunction __planMeteor0(random, field, radiant, now, options = {}) {')
			.replace(DRAW_HEAD, 'self.__hk.orig.draw = __drawMeteor0;\nfunction drawMeteor(...a) { return self.__hk.draw(__drawMeteor0, a) }\nfunction __drawMeteor0(ctx, assets, meteor, frame, fade = 1) {')
	)
}

export async function hookWorkerChunk(context) {
	const stats = { patched: 0, seen: 0, sources: [] }
	await context.route(/\/_next\/static\/chunks\/src_[^/]*\.js(\?.*)?$/, async (route) => {
		stats.seen++
		const response = await route.fetch()
		const text = await response.text()
		const patched = patchChunk(text)
		if (patched) {
			stats.patched++
			stats.sources.push(text)
		}
		const body = patched ?? text
		const headers = { ...response.headers() }
		delete headers['content-encoding']
		delete headers['transfer-encoding']
		headers['content-length'] = String(Buffer.byteLength(body))
		await route.fulfill({ status: response.status(), headers, body })
	})
	return stats
}

export async function newContext(browser, spec, { reducedMotion = 'no-preference', forcedColors = 'none', contrast, hook = true } = {}) {
	const context = await browser.newContext({ viewport: { width: spec.width, height: spec.height }, deviceScaleFactor: spec.dsf, isMobile: spec.mobile, hasTouch: spec.mobile, reducedMotion, forcedColors, ...(contrast ? { contrast } : {}) })
	await context.addInitScript(PAGE_INIT)
	const stats = hook ? await hookWorkerChunk(context) : { patched: 0, seen: 0, sources: [] }
	return { context, stats }
}

export async function openHome(context, { timeout = 120000 } = {}) {
	const page = await context.newPage()
	const logs = []
	page.on('console', (m) => (m.type() === 'error' || m.type() === 'warning') && !/Reduced Motion enabled/.test(m.text()) && logs.push('page ' + m.type() + ': ' + m.text().slice(0, 300)))
	page.on('pageerror', (e) => logs.push('pageerror: ' + e.message.slice(0, 300)))
	const workers = []
	page.on('worker', (w) => {
		workers.push(w)
		w.on('console', (m) => (m.type() === 'error' || m.type() === 'warning') && logs.push('worker ' + m.type() + ': ' + m.text().slice(0, 300)))
	})
	await page.goto(TARGET, { waitUntil: 'load', timeout })
	const worker = await waitFor(() => skyWorkerOf(workers), 30000, 'sky worker')
	return { page, worker, logs, workers }
}

/** The quiet copy's text lines and control boxes on screen, with computed color, size and weight. */
export async function measureLines(page) {
	return page.evaluate(() => {
		const out = []
		for (const root of document.querySelectorAll('[data-sky-quiet]')) {
			const fixed = getComputedStyle(root).position === 'fixed'
			const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
			const range = document.createRange()
			for (let n = walker.nextNode(); n; n = walker.nextNode()) {
				if (!n.textContent.trim()) continue
				range.selectNodeContents(n)
				const el = n.parentElement
				const cs = getComputedStyle(el)
				for (const r of range.getClientRects()) {
					if (!r.width || !r.height || r.bottom < 0 || r.top > innerHeight) continue
					out.push({ text: n.textContent.trim().replace(/\s+/g, ' ').slice(0, 40), tag: el.tagName, color: cs.color, size: parseFloat(cs.fontSize), weight: Number(cs.fontWeight), x: r.left, y: r.top, w: r.width, h: r.height, fixed })
				}
			}
			for (const c of root.querySelectorAll('a, button')) {
				const r = c.getBoundingClientRect()
				if (!r.width || !r.height || r.bottom < 0 || r.top > innerHeight) continue
				const cs = getComputedStyle(c)
				out.push({ text: '[box] ' + c.textContent.trim().slice(0, 30), tag: c.tagName, color: cs.color, size: parseFloat(cs.fontSize), weight: Number(cs.fontWeight), x: r.left, y: r.top, w: r.width, h: r.height, fixed, box: true })
			}
		}
		return { lines: out, scrollY, inner: [innerWidth, innerHeight], dpr: devicePixelRatio }
	})
}

export const decode = (buf) => PNG.sync.read(buf)
export const encode = (png) => PNG.sync.write(png)

export function crop(img, x0, y0, w, h) {
	const out = new PNG({ width: w, height: h })
	for (let y = 0; y < h; y++) {
		for (let x = 0; x < w; x++) {
			const sx = Math.min(img.width - 1, Math.max(0, x0 + x))
			const sy = Math.min(img.height - 1, Math.max(0, y0 + y))
			const s = (sy * img.width + sx) * 4
			const d = (y * w + x) * 4
			out.data[d] = img.data[s]
			out.data[d + 1] = img.data[s + 1]
			out.data[d + 2] = img.data[s + 2]
			out.data[d + 3] = 255
		}
	}
	return out
}

const lin = (c) => {
	const s = c / 255
	return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4
}
export const luminance = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
export const contrast = (a, b) => {
	const la = luminance(a)
	const lb = luminance(b)
	return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
}
export function parseColor(s) {
	const m = /rgba?\(([^)]+)\)/.exec(s)
	return m ? m[1].split(/[ ,]+/).slice(0, 3).map((v) => Math.round(Number(v))) : null
}
export const median = (xs) => {
	const s = [...xs].sort((a, b) => a - b)
	return s.length ? (s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2) : null
}
export const pct = (xs, q) => {
	const s = [...xs].sort((a, b) => a - b)
	return s.length ? s[Math.min(s.length - 1, Math.floor(q * s.length))] : null
}
export const mkdir = (p) => fs.mkdirSync(p, { recursive: true })
export const write = (p, data) => {
	mkdir(path.dirname(p))
	fs.writeFileSync(p, typeof data === 'string' || Buffer.isBuffer(data) ? data : JSON.stringify(data, null, 1))
}
