// The copy moving under a shooting star in flight while a layout is still waiting (audit finding correctness-wcag:F1), live: the real
// worker, hooked chunk. No real visitor action does this mid-flight (a resize ends the flight, a scroll cancels it); the closest real
// cause is a late font or a text-size change, emulated by changing the root font size while a flight that approaches copy is at
// p 0.45 (its head about to enter the veil). Two modes:
//   held    the root font size 16 -> STEP1, and STEP2 px 100 ms later: the second layout message arrives while the first one's ease
//           runs, so the worker holds it (frame.quiet.next) for up to 0.6 s
//   single  the root font size 16 -> STEP1 only: the layout is applied at once (D2's own case; the control)
// Per frame the head's white is rebuilt from the sprites the worker drew (core and glow alpha times headGain / (1 + glowAlpha), exact because every
// part of the star takes the same share) and compared with INK_BUDGET of every text rect of the NEWEST layout the page posted (the copy where
// it really is) that the head is inside: ratio above 1.001 is a breach. Frames from the first changed layout on, SEEN_MS after its post: the page
// measures the reflow a frame or two after it happens and the worker cannot know of copy that has moved but not been reported (that latency is not what is tested).
//   node d2-held.mjs <runs> [held|single]
import path from 'node:path'
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, write, HERE } from './alib.mjs'

const runs = Number(process.argv[2] ?? 4)
const mode = process.argv[3] ?? 'held'
const STEP1 = Number(process.env.STEP1 ?? 19)
const STEP2 = Number(process.env.STEP2 ?? 22)
const spec = parseSpec(process.env.SPEC ?? '1440x900@1')
// config.ts: INK_BUDGET and METEOR_LOOK, STAR_INK_PEAK 0
const budgetOf = (headroom) => Math.min(0.2, Math.max(0, (headroom - 0.025) * 0.9))
const GAIN = 2 + 0.22 + 0.3
const GLOW_SHARE = 1 + 0.3
const SEEN_MS = 10

const browser = await launch()
const out = []
let done = 0
for (let attempt = 0; attempt < runs * 8 && done < runs; attempt++) {
	const { context } = await newContext(browser, spec)
	try {
		const { page, worker, logs } = await openHome(context)
		await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
		const plan = await waitFor(() => worker.evaluate(() => self.__hk.plans.find((p) => p.meteor)), 40000, 'plan', 15)
		const m = plan.meteor
		if (!m.nearCopy || m.flare || m.fireball || m.train) {
			await context.close()
			continue
		}
		const now = await page.evaluate(() => performance.timeOrigin + performance.now())
		await sleep(Math.max(0, plan.at + 0.45 * m.duration * 1000 - now))
		const t0 = await page.evaluate((px) => {
			document.documentElement.style.fontSize = px + 'px'
			return performance.timeOrigin + performance.now()
		}, STEP1)
		if (mode === 'held') {
			await sleep(100)
			await page.evaluate((px) => (document.documentElement.style.fontSize = px + 'px'), STEP2)
		}
		await sleep(m.duration * 1000 + 700)
		const frames = await worker.evaluate(() => self.__hk.frames.filter((f) => f.meteor === 0).map((f) => ({ at: f.at, time: f.time, level: f.level, next: f.next, fade: f.fade, calls: f.calls })))
		const layouts = (await posts(page)).filter((p) => p.type === 'layout' && p.at >= t0 - 5 && p.quiet.length > 0)
		let onCopy = 0
		let heldOnCopy = 0
		let worst = 0
		let worstInfo = null
		let breaches = 0
		for (const f of frames) {
			if (!f.calls?.length || f.at < t0) continue
			const core = f.calls.reduce((a, b) => (b[2] < a[2] ? b : a))
			const glow = f.calls.length > 1 ? f.calls.reduce((a, b) => (b[2] > a[2] ? b : a)) : null
			const cx = core[0] + core[2] / 2
			const cy = core[1] + core[2] / 2
			const white = ((core[3] + (glow ? glow[3] : 0)) * GAIN) / GLOW_SHARE
			// the copy where it really is: the newest layout the page had posted when the frame was drawn (the post's `at` is when the page sent it)
			// a frame drawn before the worker could have processed a post (SEEN_MS of messaging latency) knows only the older copy: no layout to hold it to
			const layout = [...layouts].reverse().find((p) => p.at + SEEN_MS <= f.at)
			if (!layout) continue
			const budgets = [...layout.quiet, ...layout.pinned].filter((r) => cx >= r.x && cx <= r.x + r.width && cy >= r.y && cy <= r.y + r.height).map((r) => budgetOf(r.headroom))
			if (!budgets.length) continue
			onCopy++
			if (f.next > 0) heldOnCopy++
			const ratio = white / Math.min(...budgets)
			if (ratio > worst) {
				worst = ratio
				worstInfo = { dt: Math.round(f.at - t0), white: +white.toFixed(4), budget: +Math.min(...budgets).toFixed(4), level: +f.level.toFixed(2), next: f.next }
			}
			if (ratio > 1.001) breaches++
		}
		const framesWithNext = frames.filter((f) => f.next > 0).length
		const res = { attempt, mode, layoutsPosted: layouts.map((p) => Math.round(p.at - t0)), flightFrames: frames.length, framesWithWaitingLayout: framesWithNext, framesOnNewCopy: onCopy, ofThemWhileWaiting: heldOnCopy, worstWhiteOverBudget: +worst.toFixed(3), worstInfo, breaches, logs }
		out.push(res)
		done++
		console.log(`run ${done} (${mode}): layouts posted at ${JSON.stringify(res.layoutsPosted)} ms | worker frames ${frames.length}, with a waiting layout ${framesWithNext} | head on the newest copy in ${onCopy} frames (${heldOnCopy} while a layout waited) | worst white / budget ${res.worstWhiteOverBudget} ${JSON.stringify(worstInfo)} | breaches ${breaches} | logs ${logs.length}`)
	} finally {
		await context.close().catch(() => {})
	}
}
write(path.join(HERE, 'out', `d2-${mode}${process.env.TAG ?? ''}.json`), out)
await browser.close()
const total = out.reduce((a, r) => a + r.breaches, 0)
const onCopy = out.reduce((a, r) => a + r.framesOnNewCopy, 0)
console.log(`${mode}: ${out.length} runs, head on the newest copy in ${onCopy} frames, ${total} breaches of its budget`)
process.exit(total > 0 || out.length === 0 ? 1 : 0)
