// The copy moving under a shooting star in flight (D2, transientQuietFactor), live. No real visitor action does this mid-flight
// (a resize ends the flight, a scroll cancels it); the closest real cause is a late font or a text-size change, emulated here by
// setting the root font size 16 -> 17 px while a flight that approaches copy is at p 0.55-0.6 (its head entering the veil).
// Per run: the head's core alpha per worker frame (hooked chunk), the quiet blend level, the largest one-frame drop of the
// core alpha after the layout message against the drop expected from the light curve, and a strip of composite frames.
//   node d2.mjs <runs>
import fs from 'node:fs'
import path from 'node:path'
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, decode, encode, crop, write, HERE } from './alib.mjs'

const runs = Number(process.argv[2] ?? 3)
const spec = parseSpec('1440x900@1')
const dir = path.join(HERE, 'out', 'd2')
fs.mkdirSync(dir, { recursive: true })
const light = (p) => (p <= 0 || p >= 1 ? 0 : Math.sin(Math.PI * p ** 0.868) ** 1.2)

const browser = await launch()
const out = []
let done = 0
for (let attempt = 0; attempt < runs * 6 && done < runs; attempt++) {
	const { context } = await newContext(browser, spec)
	try {
		const { page, worker } = await openHome(context)
		await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
		const cdp = await context.newCDPSession(page)
		let keep = null
		let ring = []
		cdp.on('Page.screencastFrame', ({ data, metadata, sessionId }) => {
			cdp.send('Page.screencastFrameAck', { sessionId }).catch(() => {})
			const f = { ts: metadata.timestamp * 1000, data }
			if (keep) keep.push(f)
			else {
				ring.push(f)
				if (ring.length > 6) ring.shift()
			}
		})
		await cdp.send('Page.startScreencast', { format: 'png', everyNthFrame: 1 })
		const plan = await waitFor(() => worker.evaluate(() => self.__hk.plans.find((p) => p.meteor)), 30000, 'plan', 15)
		keep = ring
		const m = plan.meteor
		if (!m.nearCopy || m.flare || m.fireball || m.train) {
			await context.close()
			continue
		}
		const now = await page.evaluate(() => performance.timeOrigin + performance.now())
		await sleep(Math.max(0, plan.at + 0.57 * m.duration * 1000 - now))
		const t0 = await page.evaluate(() => {
			document.documentElement.style.fontSize = '17px'
			return performance.timeOrigin + performance.now()
		})
		await sleep(m.duration * 1000 + 600)
		await cdp.send('Page.stopScreencast')
		const hk = await worker.evaluate(() => self.__hk.frames.filter((f) => f.meteor === 0).map((f) => ({ at: f.at, time: f.time, level: f.level, core: f.calls?.length ? f.calls.reduce((a, b) => (b[2] < a[2] ? b : a))[3] : 0 })))
		const layout = (await posts(page)).filter((p) => p.type === 'layout' && p.at >= t0 - 5)
		const wf = hk.map((f) => ({ ...f, p: (f.time - m.startedAt) / m.duration }))
		// one-frame core drops after the layout message, net of the light curve's own fall
		let worst = { drop: 0 }
		for (let k = 1; k < wf.length; k++) {
			if (wf[k].at < (layout[0]?.at ?? Infinity) || wf[k].p >= 1) continue
			const expected = wf[k - 1].core * (light(wf[k].p) / Math.max(1e-6, light(wf[k - 1].p)))
			const drop = expected - wf[k].core
			if (drop > worst.drop) worst = { drop: +drop.toFixed(3), from: +wf[k - 1].core.toFixed(3), to: +wf[k].core.toFixed(3), p: +wf[k].p.toFixed(3), level: +wf[k].level.toFixed(3) }
		}
		const easing = wf.filter((f) => f.level < 1).length
		const res = { attempt, layoutAfterMs: layout.length ? Math.round(layout[0].at - t0) : null, easingFrames: easing, worstDrop: worst, track: wf.filter((f) => f.p > 0.45 && f.p < 1).map((f) => [+f.p.toFixed(3), +f.core.toFixed(3), +f.level.toFixed(2)]) }
		// strip: consecutive composite frames from the layout message on, crop around the path
		const xs = [m.startX, m.startX + m.dirX * m.length]
		const ys = [m.startY, m.startY + m.dirY * m.length]
		const x0 = Math.max(0, Math.floor(Math.min(...xs) - 80))
		const y0 = Math.max(0, Math.floor(Math.min(...ys) - 80))
		const sdir = path.join(dir, `run-${done}`)
		fs.mkdirSync(sdir, { recursive: true })
		const from = keep.findIndex((f) => f.ts >= (layout[0]?.at ?? t0) - 40)
		keep.slice(Math.max(0, from), Math.max(0, from) + 12).forEach((f, k) => fs.writeFileSync(path.join(sdir, `f${String(k).padStart(2, '0')}.png`), encode(crop(decode(Buffer.from(f.data, 'base64')), x0, y0, Math.ceil(Math.max(...xs) - Math.min(...xs) + 160), Math.ceil(Math.max(...ys) - Math.min(...ys) + 160)))))
		out.push(res)
		done++
		console.log(`run ${done}: layout ${res.layoutAfterMs} ms after the change, easing frames ${easing}, largest one-frame core drop beyond the light curve ${JSON.stringify(worst)}`)
		console.log('  track p/core/level', JSON.stringify(res.track.filter((_, i) => i % 2 === 0)))
	} finally {
		await context.close().catch(() => {})
	}
}
write(path.join(dir, 'd2.json'), out)
await browser.close()
