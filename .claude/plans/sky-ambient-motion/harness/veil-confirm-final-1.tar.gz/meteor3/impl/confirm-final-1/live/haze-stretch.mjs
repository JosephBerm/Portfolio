// What the deferred haze rebuild costs to look at (N2 side effect): after a resize that changes the aspect ratio the sky draws the OLD haze
// stretched until the rebuild. Compare the sky just after the resize (stretched haze, the rebuild is waiting for the quiet ease) with the sky
// once it has settled (rebuilt haze): the mean color of large blocks (stars average out), in 8-bit levels. Observation only.
//   node haze-stretch.mjs [fromWidth toWidth height]
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, decode, write, HERE } from './alib.mjs'
import path from 'node:path'

const [fromWidth = '1440', toWidth = '1000', height = '900'] = process.argv.slice(2)
const spec = parseSpec(`${fromWidth}x${height}@1`)
const browser = await launch()
const { context } = await newContext(browser, spec, { hook: false })
const { page } = await openHome(context)
const reveal = await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
await sleep(Math.max(0, reveal.at + 2600 - (await page.evaluate(() => performance.timeOrigin + performance.now()))))

// mean color of w x h blocks at fractions of the viewport, away from the copy where possible (the haze is strongest upper right)
const blocks = [
	['upper right pool', 0.8, 0.2],
	['top right corner', 0.93, 0.07],
	['centre right', 0.85, 0.5],
	['lower left pool', 0.06, 0.96],
	['centre', 0.5, 0.45],
]
function meanBlock(png, fx, fy, size = 48) {
	const cx = Math.round(fx * png.width)
	const cy = Math.round(fy * png.height)
	let r = 0
	let g = 0
	let b = 0
	let n = 0
	for (let y = Math.max(0, cy - size / 2); y < Math.min(png.height, cy + size / 2); y++)
		for (let x = Math.max(0, cx - size / 2); x < Math.min(png.width, cx + size / 2); x++) {
			const i = (y * png.width + x) * 4
			r += png.data[i]
			g += png.data[i + 1]
			b += png.data[i + 2]
			n++
		}
	return [r / n, g / n, b / n]
}
const shoot = async () => decode(await page.screenshot({ type: 'png' }))

await page.setViewportSize({ width: Number(toWidth), height: Number(height) })
await sleep(350)
const early = await shoot()
const t1 = await page.evaluate(() => performance.timeOrigin + performance.now())
await sleep(2600)
const late = await shoot()
const out = []
for (const [name, fx, fy] of blocks) {
	const a = meanBlock(early, fx, fy)
	const b = meanBlock(late, fx, fy)
	out.push({ name, early: a.map((v) => +v.toFixed(2)), late: b.map((v) => +v.toFixed(2)), diff: +Math.max(...a.map((v, i) => Math.abs(v - b[i]))).toFixed(2) })
	console.log(`${name.padEnd(18)} early ${a.map((v) => v.toFixed(1)).join(',')}  late ${b.map((v) => v.toFixed(1)).join(',')}  largest channel difference ${out.at(-1).diff} of 255`)
}
write(path.join(HERE, 'out', 'haze-stretch.json'), { fromWidth, toWidth, height, blocks: out, t1 })
await context.close()
await browser.close()
