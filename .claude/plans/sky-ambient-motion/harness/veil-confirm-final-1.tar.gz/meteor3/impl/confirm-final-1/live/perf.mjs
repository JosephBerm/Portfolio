// Performance, live, on the unpatched worker chunk (no hook; one visit at a time):
// - worker frame cost: every animation-frame and timer callback that draws a frame is timed in the worker (prototype and
//   scheduler wrappers installed by evaluate, observation only), with the gradients it created (a shooting-star frame
//   creates its wake gradient), so frames with and without a shooting star are told apart; frame gaps during the flight;
// - main thread: long animation frames and long tasks after the reveal, animation-frame cadence through the first flight,
//   the page's posts to the worker during the flight;
// - main-thread work per layout: measureLayout timed through the ResizeObserver and setTimeout that call it (wrapped by an
//   init script before the page's code runs), for the reveal, three resizes and two scroll stops.
//   node perf.mjs <spec> <visits>
import path from 'node:path'
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, write, median, pct, HERE } from './alib.mjs'

const spec = parseSpec(process.argv[2] ?? '1440x900@1')
const visits = Number(process.argv[3] ?? 3)

const MEASURE_INIT = `(() => {
	const A = window.__au
	A.measures = []
	const record = (kind, fn, self, args) => {
		const t0 = performance.now()
		try { return fn.apply(self, args) } finally { A.measures.push({ at: performance.timeOrigin + t0, ms: performance.now() - t0, kind, name: fn.name }) }
	}
	const RO = window.ResizeObserver
	window.ResizeObserver = class extends RO {
		constructor(cb) {
			super(function (...args) { return record('observer', cb, this, args) })
		}
	}
	const st = window.setTimeout
	window.setTimeout = function (fn, ms, ...rest) {
		if (typeof fn === 'function' && fn.name === 'measureLayout') return st.call(this, function (...args) { return record('timer', fn, this, args) }, ms, ...rest)
		return st.call(this, fn, ms, ...rest)
	}
})()`

function installWorkerPerf() {
	if (self.__perf) return
	const R = (self.__perf = { ticks: [], grads: 0, fills: 0 })
	const C = OffscreenCanvasRenderingContext2D.prototype
	const grad = C.createLinearGradient
	C.createLinearGradient = function (...a) {
		R.grads++
		return grad.apply(this, a)
	}
	const fillRect = C.fillRect
	C.fillRect = function (x, y, w, h) {
		if (x === 0 && y === 0 && w === this.canvas.width && h === this.canvas.height && this.canvas.width > 64) R.fills++
		return fillRect.call(this, x, y, w, h)
	}
	const wrap = (cb, kind) =>
		function (...args) {
			const g0 = R.grads
			const f0 = R.fills
			const t0 = performance.now()
			try {
				return cb.apply(this, args)
			} finally {
				const t1 = performance.now()
				if (R.fills > f0) R.ticks.push([performance.timeOrigin + t0, t1 - t0, R.grads - g0, kind])
			}
		}
	const raf = self.requestAnimationFrame
	self.requestAnimationFrame = function (cb) {
		return raf.call(self, wrap(cb, 'raf'))
	}
	const st = self.setTimeout
	self.setTimeout = function (cb, ms, ...rest) {
		return typeof cb === 'function' ? st.call(self, wrap(cb, 'timer'), ms, ...rest) : st.call(self, cb, ms, ...rest)
	}
}

const browser = await launch()
const results = []
for (let n = 1; n <= visits; n++) {
	const { context } = await newContext(browser, spec, { hook: false })
	await context.addInitScript(MEASURE_INIT)
	try {
		const { page, worker, logs } = await openHome(context)
		await worker.evaluate(installWorkerPerf)
		const reveal = await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
		await page.evaluate(() => window.__au.startRaf())
		// the first flight: wait until a frame with a gradient has been drawn and 2 s more (or 14 s after the reveal)
		const flightAt = await waitFor(
			async () => {
				const t = await worker.evaluate(() => self.__perf.ticks.find((k) => k[2] > 0)?.[0] ?? null)
				const now = await page.evaluate(() => performance.timeOrigin + performance.now())
				return t ?? (now - reveal.at > (spec.mobile ? 40000 : 14000) ? -1 : null)
			},
			60000,
			'flight',
			100
		)
		await sleep(2600)
		await page.evaluate(() => window.__au.stopRaf())
		// Layouts: three resizes and two scroll stops, 2 s apart
		const w = spec.width
		for (const width of [w - 40, w, w - 20]) {
			await page.setViewportSize({ width, height: spec.height })
			await sleep(2000)
		}
		await page.mouse.move(w / 2, spec.height / 2)
		await page.mouse.wheel(0, 300)
		await sleep(2300)
		await page.mouse.wheel(0, -300)
		await sleep(2300)
		const ticks = await worker.evaluate(() => self.__perf.ticks)
		const au = await page.evaluate(() => ({ long: window.__au.long, loaf: window.__au.loaf, raf: window.__au.raf, measures: window.__au.measures, posts: window.__au.posts.map((p) => ({ at: p.at, type: p.type, rects: p.quiet?.length })) }))
		const afterReveal = (x) => x.at > reveal.at + 1000
		const meteorTicks = ticks.filter((k) => k[2] > 0)
		const plainTicks = ticks.filter((k) => k[2] === 0 && k[0] > reveal.at + 1000)
		const flightStart = meteorTicks[0]?.[0] ?? null
		const flightEnd = meteorTicks.at(-1)?.[0] ?? null
		const flightGaps = meteorTicks.slice(1).map((k, i) => k[0] - meteorTicks[i][0])
		const rafIn = au.raf.filter((t) => flightStart && t >= flightStart && t <= flightEnd)
		const rafGaps = rafIn.slice(1).map((t, i) => t - rafIn[i])
		const duringFlight = au.posts.filter((p) => flightStart && p.at > flightStart && p.at < flightEnd)
		const measures = au.measures.filter((m) => m.name === 'measureLayout')
		const r = {
			n,
			spec: spec.name,
			firstFlightS: flightStart ? (flightStart - reveal.at) / 1000 : null,
			worker: {
				meteorFrames: meteorTicks.length,
				meteorMs: { p50: median(meteorTicks.map((k) => k[1])), p95: pct(meteorTicks.map((k) => k[1]), 0.95), max: Math.max(0, ...meteorTicks.slice(1).map((k) => k[1])) },
				firstMeteorTickMs: meteorTicks[0]?.[1] ?? null,
				plainFrames: plainTicks.length,
				plainMs: { p50: median(plainTicks.map((k) => k[1])), p95: pct(plainTicks.map((k) => k[1]), 0.95), max: Math.max(0, ...plainTicks.map((k) => k[1])) },
				flightGapMs: { p50: median(flightGaps), max: Math.max(0, ...flightGaps), over20: flightGaps.filter((g) => g > 20).length },
			},
			main: {
				longTasks: au.long.filter(afterReveal).map((l) => Math.round(l.ms)),
				loaf: au.loaf.filter(afterReveal).map((l) => ({ ms: Math.round(l.ms), block: Math.round(l.block), dt: Math.round(l.at - reveal.at), scripts: l.scripts.slice(0, 3) })),
				rafInFlight: rafIn.length,
				rafGapMs: { p50: median(rafGaps), max: Math.max(0, ...rafGaps), over20: rafGaps.filter((g) => g > 20).length },
				postsDuringFlight: duringFlight.map((p) => p.type),
			},
			layouts: {
				calls: measures.length,
				posted: au.posts.filter((p) => p.type === 'layout').length,
				ms: measures.map((m) => +m.ms.toFixed(2)),
				p50: median(measures.map((m) => m.ms)),
				max: Math.max(0, ...measures.map((m) => m.ms)),
				byKind: Object.fromEntries(['observer', 'timer'].map((k) => [k, measures.filter((m) => m.kind === k).length])),
			},
			logs,
		}
		results.push(r)
		console.log(JSON.stringify(r))
	} catch (e) {
		console.log(`#${n} failed: ${e.message}`)
	} finally {
		await context.close()
	}
}
write(path.join(HERE, 'out', `perf-${spec.name}.json`), results)
await browser.close()
