// Star pop when the copy is re-measured mid-ease (C2), live: the real worker, unpatched chunk. A recorder installed in the
// worker (prototype wrappers, observation only) keeps every star sprite draw per frame (CSS position, alpha) in a window
// around a trigger, 2.2 s after the reveal (the reveal's ease and the 1.5 s re-measure are over; the first shooting star
// is due 4.5-7 s after the reveal). Scenarios:
//   control  one resize 1440 -> 1400 px wide
//   resize2  a second resize 300 ms into the ease (1400 -> 1360)
//   drag     a drag from 1440 to 1300 px in 20 steps 16 ms apart
//   zoom2    browser zoom 125% then 150% 300 ms later (CSS viewport and pixel ratio, as Ctrl+ does)
//   reflow2  no resize: the root font size 16 -> 17 px, then 18 px 300 ms later (copy reflows, a late font or text zoom)
// Per scenario: the largest one-frame alpha change of any star seen in both frames, its rate per second, stars of alpha 0.1+
// that appear or vanish between two frames away from the edges, and stars drawn on the copy (inside a final text line)
// over time: the zones lag a held layout.
//   node pop.mjs [scenario ...]
import path from 'node:path'
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, measureLines, write, HERE } from './alib.mjs'

const all = ['control', 'resize2', 'drag', 'zoom2', 'reflow2']
const scenarios = process.argv.slice(2).length ? process.argv.slice(2) : all
const repeats = Number(process.env.REPEATS ?? 2)
const spec = parseSpec('1440x900@1')

function install() {
	if (self.__pop) return 'already'
	const now = () => performance.timeOrigin + performance.now()
	const R = (self.__pop = { on: false, frames: [], cur: null, main: null })
	const C = OffscreenCanvasRenderingContext2D.prototype
	const fillRect = C.fillRect
	C.fillRect = function (x, y, w, h) {
		if (x === 0 && y === 0 && w === this.canvas.width && h === this.canvas.height && this.canvas.width > 64 && (R.main === null || R.main === this.canvas)) {
			R.main = this.canvas
			if (R.on) {
				R.cur = { at: now(), cw: this.canvas.width, ch: this.canvas.height, stars: [], grads: 0 }
				R.frames.push(R.cur)
			} else R.cur = null
		}
		return fillRect.call(this, x, y, w, h)
	}
	const drawImage = C.drawImage
	C.drawImage = function (...a) {
		if (R.cur && a.length === 9 && this.canvas === R.main) R.cur.stars.push([a[2], a[3], a[5], a[6], this.globalAlpha, a[7]])
		return drawImage.apply(this, a)
	}
	const grad = C.createLinearGradient
	C.createLinearGradient = function (...a) {
		if (R.cur && this.canvas === R.main) R.cur.grads++
		return grad.apply(this, a)
	}
	return 'installed'
}

async function run(browser, scenario, rep) {
	const { context } = await newContext(browser, spec, { hook: false })
	try {
		const { page, worker, logs } = await openHome(context)
		await worker.evaluate(install)
		const reveal = await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
		const cdp = await context.newCDPSession(page)
		const epoch = await page.evaluate(() => performance.timeOrigin + performance.now())
		await sleep(Math.max(0, reveal.at + 1800 - epoch))
		await worker.evaluate(() => {
			self.__pop.on = true
		})
		await sleep(400)
		const before = await measureLines(page)
		const t0 = await page.evaluate(() => performance.timeOrigin + performance.now())
		if (scenario === 'control') await page.setViewportSize({ width: 1400, height: 900 })
		if (scenario === 'resize2') {
			await page.setViewportSize({ width: 1400, height: 900 })
			await sleep(300)
			await page.setViewportSize({ width: 1360, height: 900 })
		}
		if (scenario === 'drag') {
			for (let i = 1; i <= 20; i++) {
				await page.setViewportSize({ width: 1440 - 7 * i, height: 900 })
				await sleep(16)
			}
		}
		if (scenario === 'zoom2') {
			await cdp.send('Emulation.setDeviceMetricsOverride', { width: 1152, height: 720, deviceScaleFactor: 1.25, mobile: false })
			await sleep(300)
			await cdp.send('Emulation.setDeviceMetricsOverride', { width: 960, height: 600, deviceScaleFactor: 1.5, mobile: false })
		}
		if (scenario === 'reflow2') {
			await page.evaluate(() => (document.documentElement.style.fontSize = '17px'))
			await sleep(300)
			await page.evaluate(() => (document.documentElement.style.fontSize = '18px'))
		}
		await sleep(2400)
		const rec = await worker.evaluate(() => {
			self.__pop.on = false
			return self.__pop.frames
		})
		const dom = await measureLines(page)
		const ps = (await posts(page)).filter((p) => p.at >= t0 - 50 && p.type !== 'scroll').map((p) => ({ dt: Math.round(p.at - t0), type: p.type, rects: p.quiet?.length, w: p.width, dpr: p.dpr }))
		return { scenario, rep, t0, rec, dom, before, posts: ps, logs }
	} finally {
		await context.close()
	}
}

function analyze(r) {
	// Frames with a shooting star (a wake gradient) are left out; none is due in this window
	const frames = r.rec.filter((f) => f.grads === 0)
	const resizes = r.posts.filter((p) => p.type === 'resize').map((p) => ({ at: r.t0 + p.dt, w: p.w, dpr: p.dpr }))
	for (const f of frames) {
		// The pixel ratio of this frame's canvas: the newest resize post whose size matches the canvas
		const fits = resizes.filter((p) => p.at <= f.at && Math.round(p.w * p.dpr) === f.cw)
		f.dpr = fits.length ? fits.at(-1).dpr : f.cw / 1440
		f.map = new Map()
		for (const [, , dx, dy, a, size] of f.stars) {
			// Sprite center in CSS px (the draw is at round(x * dpr) - half)
			const key = `${Math.round((dx + size / 2) / f.dpr)},${Math.round((dy + size / 2) / f.dpr)}`
			f.map.set(key, Math.max(f.map.get(key) ?? 0, a))
		}
	}
	const lines = r.dom.lines.filter((l) => !l.box)
	// Near copy: within 100 CSS px of a line of copy before or after the change (the veil reaches 72 px)
	const all = [...lines, ...r.before.lines.filter((l) => !l.box)]
	const nearCopy = (x, y) => all.some((l) => Math.hypot(Math.max(l.x - x, 0, x - l.x - l.w), Math.max(l.y - y, 0, y - l.y - l.h)) <= 100)
	let maxStep = 0
	let maxStepInfo = null
	let maxRate = 0
	let maxStepFar = 0
	let events = 0
	let eventsFar = 0
	const eventList = []
	const onCopy = []
	for (let k = 1; k < frames.length; k++) {
		const a = frames[k - 1]
		const b = frames[k]
		const dt = (b.at - a.at) / 1000
		const sameScale = a.dpr === b.dpr
		for (const [key, alpha] of b.map) {
			const [x, y] = key.split(',').map(Number)
			let prev = a.map.get(key)
			if (prev === undefined && sameScale) {
				// tolerate a 1 px rounding move
				for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
					const v = a.map.get(`${x + ox},${y + oy}`)
					if (v !== undefined) {
						prev = v
						break
					}
				}
			}
			const edge = x < 40 || y < 40 || x > b.cw / b.dpr - 40 || y > b.ch / b.dpr - 40
			if (prev === undefined) {
				if (alpha >= 0.1 && !edge && sameScale && !nearCopy(x, y)) eventsFar++
				else if (alpha >= 0.1 && !edge && sameScale) {
					events++
					if (eventList.length < 12) eventList.push({ kind: 'appear', dt: Math.round(b.at - r.t0), x, y, alpha: +alpha.toFixed(3) })
				}
				continue
			}
			const step = Math.abs(alpha - prev)
			if (!nearCopy(x, y)) {
				maxStepFar = Math.max(maxStepFar, step)
				continue
			}
			if (step > maxStep) {
				maxStep = step
				maxStepInfo = { dt: Math.round(b.at - r.t0), x, y, from: +prev.toFixed(3), to: +alpha.toFixed(3), gap: Math.round(dt * 1000) }
			}
			if (dt > 0.008) maxRate = Math.max(maxRate, step / dt)
		}
		for (const [key, alpha] of a.map) {
			if (b.map.has(key) || alpha < 0.1 || !sameScale) continue
			const [x, y] = key.split(',').map(Number)
			const near = [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([ox, oy]) => b.map.has(`${x + ox},${y + oy}`))
			const edge = x < 40 || y < 40 || x > b.cw / b.dpr - 40 || y > b.ch / b.dpr - 40
			if (!near && !edge && !nearCopy(x, y)) eventsFar++
			else if (!near && !edge) {
				events++
				if (eventList.length < 12) eventList.push({ kind: 'vanish', dt: Math.round(b.at - r.t0), x, y, alpha: +alpha.toFixed(3) })
			}
		}
	}
	// Stars drawn on the copy as it is at the end (inside a final text line), per frame: the zones' lag after the last layout
	for (const f of frames) {
		let max = 0
		let n = 0
		for (const [key, alpha] of f.map) {
			const [x, y] = key.split(',').map(Number)
			if (lines.some((l) => x + 1 >= l.x && x + 1 <= l.x + l.w && y + 1 >= l.y && y + 1 <= l.y + l.h)) {
				n++
				max = Math.max(max, alpha)
			}
		}
		onCopy.push({ dt: Math.round(f.at - r.t0), n, max: +max.toFixed(3) })
	}
	const lastLayout = r.posts.filter((p) => p.type === 'layout').at(-1)?.dt ?? null
	const visibleOnCopy = onCopy.filter((o) => o.max >= 0.05)
	return {
		scenario: r.scenario,
		rep: r.rep,
		frames: frames.length,
		layouts: r.posts.filter((p) => p.type === 'layout').map((p) => p.dt),
		resizes: r.posts.filter((p) => p.type === 'resize').length,
		maxStep: +maxStep.toFixed(3),
		maxStepInfo,
		maxRate: +maxRate.toFixed(2),
		maxStepFar: +maxStepFar.toFixed(3),
		eventsFar,
		events,
		eventList,
		lastLayout,
		starsOnCopy: { frames: visibleOnCopy.length, from: visibleOnCopy[0]?.dt ?? null, until: visibleOnCopy.at(-1)?.dt ?? null, max: Math.max(0, ...onCopy.map((o) => o.max)) },
		onCopy: onCopy.filter((o, i) => i % 3 === 0),
		logs: r.logs,
	}
}

const browser = await launch()
const out = []
for (const scenario of scenarios) {
	for (let rep = 0; rep < repeats; rep++) {
		try {
			const r = await run(browser, scenario, rep)
			const a = analyze(r)
			out.push(a)
			console.log(`${scenario} #${rep}: frames ${a.frames} layouts at ${JSON.stringify(a.layouts)} resizes ${a.resizes} | near copy: max one-frame star alpha step ${a.maxStep} ${JSON.stringify(a.maxStepInfo)} | max rate ${a.maxRate}/s | appear/vanish ${a.events} ${JSON.stringify(a.eventList.slice(0, 4))} | elsewhere: max step ${a.maxStepFar}, appear/vanish ${a.eventsFar} | stars on final copy (alpha >= 0.05): ${a.starsOnCopy.frames} frames, ${a.starsOnCopy.from}..${a.starsOnCopy.until} ms, max ${a.starsOnCopy.max} | logs ${a.logs.length}`)
		} catch (e) {
			console.log(`${scenario} #${rep} failed: ${e.message}`)
		}
	}
}
write(path.join(HERE, 'out', 'pop.json'), out)
await browser.close()
