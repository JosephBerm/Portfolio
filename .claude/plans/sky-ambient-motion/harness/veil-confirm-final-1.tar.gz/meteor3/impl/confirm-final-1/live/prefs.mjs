// Preferences, live: reduced motion and forced colors (the shooting star must not fly; the sky must not misbehave).
// prefers-contrast: more is covered by flights.mjs with CONTRAST=more (real flights, light on copy measured).
//   node prefs.mjs
import path from 'node:path'
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, write, HERE } from './alib.mjs'

const spec = parseSpec('1440x900@1')
const browser = await launch()
const out = {}

function counter() {
	if (self.__cnt) return
	const R = (self.__cnt = { frames: 0, grads: 0, firstAt: null, lastAt: null })
	const C = OffscreenCanvasRenderingContext2D.prototype
	const fillRect = C.fillRect
	C.fillRect = function (x, y, w, h) {
		if (x === 0 && y === 0 && w === this.canvas.width && h === this.canvas.height && this.canvas.width > 64) {
			R.frames++
			const t = performance.timeOrigin + performance.now()
			R.firstAt ??= t
			R.lastAt = t
		}
		return fillRect.call(this, x, y, w, h)
	}
	const grad = C.createLinearGradient
	C.createLinearGradient = function (...a) {
		R.grads++
		return grad.apply(this, a)
	}
}

// Reduced motion: 14 s after the reveal, no shooting star planned or drawn; the sky drawn and ready
{
	const { context } = await newContext(browser, spec, { reducedMotion: 'reduce' })
	const { page, worker, logs } = await openHome(context)
	await worker.evaluate(counter)
	const reveal = await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
	await sleep(3000)
	await page.screenshot({ path: path.join(HERE, 'out', 'prefs-reduced-motion.png') })
	const at3 = await worker.evaluate(() => ({ ...self.__cnt }))
	await sleep(11000)
	const hk = await worker.evaluate(() => ({ plans: self.__hk.plans.length, frames: self.__hk.frames.length, errors: self.__hk.errors }))
	const cnt = await worker.evaluate(() => ({ ...self.__cnt }))
	const init = (await posts(page)).find((p) => p.type === 'init')
	const ready = await page.evaluate(() => document.querySelector('canvas')?.hasAttribute('data-ready'))
	out.reduced = { motion: init?.motion, ready, plans: hk.plans, meteorFrames: hk.frames, skyFramesAfter3s: cnt.frames - at3.frames, skyFramesTotal: cnt.frames, gradients: cnt.grads, logs, errors: hk.errors, sinceReveal: ((cnt.lastAt ?? 0) - reveal.at) / 1000 }
	console.log('reduced motion', JSON.stringify(out.reduced))
	await context.close()
}

// Forced colors: the sky host is display: none; nothing is drawn; no error
{
	const { context } = await newContext(browser, spec, { forcedColors: 'active' })
	const page = await context.newPage()
	const logs = []
	page.on('console', (m) => (m.type() === 'error' || m.type() === 'warning') && logs.push('page ' + m.type() + ': ' + m.text().slice(0, 200)))
	page.on('pageerror', (e) => logs.push('pageerror: ' + e.message.slice(0, 200)))
	const workers = []
	page.on('worker', (w) => workers.push(w))
	await page.goto('http://localhost:3000/', { waitUntil: 'load' })
	await sleep(9000)
	const host = await page.evaluate(() => {
		const c = document.querySelector('canvas')
		const host = c?.parentElement
		return { canvas: !!c, hostDisplay: host ? getComputedStyle(host).display : null, ready: c?.hasAttribute('data-ready') ?? null }
	})
	const ps = await posts(page)
	await page.screenshot({ path: path.join(HERE, 'out', 'prefs-forced-colors.png') })
	out.forced = { ...host, workers: workers.length, posts: ps.map((p) => p.type), logs }
	console.log('forced colors', JSON.stringify(out.forced))
	await context.close()
}

write(path.join(HERE, 'out', 'prefs.json'), out)
await browser.close()
