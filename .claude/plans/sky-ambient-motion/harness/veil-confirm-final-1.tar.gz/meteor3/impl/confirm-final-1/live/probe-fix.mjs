// Probe (round-1 fixes): the sky worker chunk the dev server serves carries the fixed working tree, the page boots, the canvas is
// ready and nothing errors. Observation only; own headless Chromium, the dev server at localhost:3000.
//   node probe-fix.mjs [spec]
import { launch, parseSpec, newContext, openHome, posts, waitFor, write, HERE } from './alib.mjs'

const spec = parseSpec(process.argv[2] ?? '1440x900@1')
const browser = await launch()
const { context, stats } = await newContext(browser, spec)
const { page, worker, logs } = await openHome(context)
await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
const src = stats.sources[0] ?? ''
const markers = [
	'function quietEasing(t)',
	'next: pendingLayout ? screenQuietZones(pendingLayout.quiet, scrollY, pendingLayout.pinned) : undefined',
	'blend.next ? Math.min(current, quietFactor(blend.next, x, y, keeps)) : current',
	'if (quietEasing(performance.now() / 1000))',
	'meteorField.width, meteorField.height',
	'NORMAL_FONT_WEIGHT',
]
const found = Object.fromEntries(markers.map((m) => [m, src.includes(m)]))
console.log('worker chunk: patched', stats.patched, 'seen', stats.seen, found)
const ready = await waitFor(() => page.evaluate(() => document.querySelector('canvas[data-ready]') !== null), 20000, 'canvas ready')
const errors = await worker.evaluate(() => self.__hk?.errors ?? [])
console.log('canvas ready', ready, '| console/page/worker logs', JSON.stringify(logs), '| hook errors', JSON.stringify(errors))
write(HERE + '/out/probe-fix.json', { found, ready, logs, errors })
await browser.close()
const bad = Object.values(found).slice(0, 5).some((v) => !v) || logs.length > 0 || errors.length > 0 || !ready
process.exit(bad ? 1 : 0)
