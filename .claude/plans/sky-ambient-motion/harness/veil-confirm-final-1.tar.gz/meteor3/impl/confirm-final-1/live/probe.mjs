// Probe: the served worker chunk carries the working tree's code, the hook patches it, and the PNG screencast rate during a flight.
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, write, HERE } from './alib.mjs'

const spec = parseSpec(process.argv[2] ?? '1440x900@1')
const browser = await launch()
const { context, stats } = await newContext(browser, spec)
const { page, worker, logs } = await openHome(context)
const reveal = await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
const src = stats.sources[0] ?? ''
const markers = ['transientQuietFactor', 'scrollKept', 'near.length > 0', 'budgetKeeps', 'edgeBright', 'pendingLayout', 'function drawMeteor(ctx, assets, meteor, frame, fade = 1)']
const found = Object.fromEntries(markers.map((m) => [m, src.includes(m)]))
console.log('patched', stats.patched, 'seen', stats.seen, found)
const cdp = await context.newCDPSession(page)
const frames = []
cdp.on('Page.screencastFrame', ({ data, metadata, sessionId }) => {
	cdp.send('Page.screencastFrameAck', { sessionId }).catch(() => {})
	frames.push({ ts: metadata.timestamp, bytes: data.length })
})
await cdp.send('Page.startScreencast', { format: 'png', everyNthFrame: 1 })
// wait for the first flight's first frame, then 1.5 s
const plan = await waitFor(() => worker.evaluate(() => self.__hk.plans.find((p) => p.meteor)), 20000, 'plan', 20)
await sleep(1500)
await cdp.send('Page.stopScreencast')
const hk = await worker.evaluate(() => ({ plans: self.__hk.plans.length, frames: self.__hk.frames.map((f) => f.at), errors: self.__hk.errors }))
const inFlight = frames.filter((f) => f.ts * 1000 >= hk.frames[0] && f.ts * 1000 <= hk.frames.at(-1))
const gaps = inFlight.slice(1).map((f, i) => (f.ts - inFlight[i].ts) * 1000)
console.log('meteor frames', hk.frames.length, 'span ms', (hk.frames.at(-1) - hk.frames[0]).toFixed(0), 'screencast frames in flight', inFlight.length, 'median gap', gaps.sort((a, b) => a - b)[Math.floor(gaps.length / 2)]?.toFixed(1), 'avg bytes', Math.round(inFlight.reduce((s, f) => s + f.bytes, 0) / Math.max(1, inFlight.length)))
console.log('first flight after reveal (s)', ((plan.at - reveal.at) / 1000).toFixed(2), 'logs', logs, 'hook errors', hk.errors)
write(HERE + '/out/probe.json', { found, stats: { patched: stats.patched, seen: stats.seen }, plan, gaps })
await browser.close()
