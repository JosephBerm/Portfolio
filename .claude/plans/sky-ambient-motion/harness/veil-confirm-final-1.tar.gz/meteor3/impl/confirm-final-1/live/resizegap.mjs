// Where the worker's frames stop after a resize (the 150-200 ms gaps seen in pop.mjs), unpatched chunk: a heartbeat in the worker
// (setInterval 5 ms) records event-loop stalls; every full-canvas fillRect (a frame) is timed; the haze rebuild draws the haze anew
// (createImageData/putImageData in the worker), so those calls are timed too. One resize 1440 -> 1400, then a drag of 10 steps.
//   node resizegap.mjs
import path from 'node:path'
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, write, HERE } from './alib.mjs'

function install() {
	if (self.__gap) return
	const now = () => performance.timeOrigin + performance.now()
	const R = (self.__gap = { frames: [], stalls: [], calls: [] })
	let last = now()
	setInterval(() => {
		const t = now()
		if (t - last > 30) R.stalls.push([Math.round(last), Math.round(t - last)])
		last = t
	}, 5)
	const C = OffscreenCanvasRenderingContext2D.prototype
	const fillRect = C.fillRect
	C.fillRect = function (x, y, w, h) {
		if (x === 0 && y === 0 && w === this.canvas.width && h === this.canvas.height && this.canvas.width > 64) R.frames.push(Math.round(now()))
		return fillRect.call(this, x, y, w, h)
	}
	for (const name of ['putImageData', 'getImageData', 'createImageData']) {
		const f = C[name]
		C[name] = function (...a) {
			const t0 = performance.now()
			try {
				return f.apply(this, a)
			} finally {
				R.calls.push([name, Math.round(performance.timeOrigin + t0), +(performance.now() - t0).toFixed(1), this.canvas.width])
			}
		}
	}
	const tb = OffscreenCanvas.prototype.transferToImageBitmap
	OffscreenCanvas.prototype.transferToImageBitmap = function (...a) {
		const t0 = performance.now()
		try {
			return tb.apply(this, a)
		} finally {
			R.calls.push(['transferToImageBitmap', Math.round(performance.timeOrigin + t0), +(performance.now() - t0).toFixed(1), this.width])
		}
	}
	const cib = self.createImageBitmap
	self.createImageBitmap = function (...a) {
		const t0 = performance.now()
		R.calls.push(['createImageBitmap', Math.round(performance.timeOrigin + t0), 0, 0])
		return cib.apply(self, a)
	}
}

const spec = parseSpec('1440x900@1')
const browser = await launch()
const out = []
for (const scenario of ['one', 'drag']) {
	const { context } = await newContext(browser, spec, { hook: false })
	try {
		const { page, worker } = await openHome(context)
		await worker.evaluate(install)
		const reveal = await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
		await sleep(Math.max(0, reveal.at + 2200 - (await page.evaluate(() => performance.timeOrigin + performance.now()))))
		const t0 = await page.evaluate(() => performance.timeOrigin + performance.now())
		if (scenario === 'one') await page.setViewportSize({ width: 1400, height: 900 })
		else
			for (let i = 1; i <= 10; i++) {
				await page.setViewportSize({ width: 1440 - 8 * i, height: 900 })
				await sleep(16)
			}
		await sleep(1600)
		const R = await worker.evaluate(() => self.__gap)
		const ps = (await posts(page)).filter((p) => p.at >= t0 - 5 && p.type !== 'scroll').map((p) => [p.type, Math.round(p.at - t0)])
		const frames = R.frames.filter((t) => t >= t0 - 100).map((t) => t - Math.round(t0))
		const gaps = frames.slice(1).map((t, i) => [frames[i], t - frames[i]]).filter(([, g]) => g > 70)
		const stalls = R.stalls.filter(([t]) => t >= t0 - 100).map(([t, ms]) => [t - Math.round(t0), ms])
		const calls = R.calls.filter(([, t]) => t >= t0 - 100).map(([n, t, ms, w]) => [n, t - Math.round(t0), ms, w])
		const r = { scenario, posts: ps, frameGapsOver70ms: gaps, stallsOver30ms: stalls, slowCalls: calls.filter((c) => c[2] >= 5 || c[0] === 'createImageBitmap') }
		out.push(r)
		console.log(JSON.stringify(r))
	} finally {
		await context.close()
	}
}
write(path.join(HERE, 'out', 'resizegap.json'), out)
await browser.close()
