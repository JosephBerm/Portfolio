// Scroll in the middle of a real flight (C1), live: the hooked worker records each meteor frame's scroll fade and head;
// the PNG screencast shows what the visitor sees. Scenarios, triggered about 0.35 s into the first flight:
//   wheel     one wheel notch (120 px)
//   nav       a click on the first in-page nav link (smooth scroll to its section)
//   pagedown  the PageDown key
//   creep     an 8 px wheel creep (under SCROLL_CANCEL.from 12 px: must not cancel)
//   node scroll.mjs [scenario ...]
// Per run: scroll posts with their offsets, the meteor frames drawn after the first scroll post (fade, offset), frames drawn
// at 24 px or more from the launch offset (must be none), and a strip of consecutive composite frames around the scroll.
import fs from 'node:fs'
import path from 'node:path'
import { launch, parseSpec, newContext, openHome, posts, waitFor, sleep, decode, encode, crop, write, HERE } from './alib.mjs'

const all = ['wheel', 'nav', 'pagedown', 'creep']
const scenarios = process.argv.slice(2).length ? process.argv.slice(2) : all
const repeats = Number(process.env.REPEATS ?? 2)
const spec = parseSpec(process.env.SPEC ?? '1440x900@1')
const dir = path.join(HERE, 'out', 'scroll')
fs.mkdirSync(dir, { recursive: true })

async function run(browser, scenario, rep) {
	const { context } = await newContext(browser, spec)
	try {
		const { page, worker, logs } = await openHome(context)
		await waitFor(async () => (await posts(page)).find((p) => p.type === 'reveal'), 30000, 'reveal')
		const cdp = await context.newCDPSession(page)
		let ring = []
		let keep = null
		cdp.on('Page.screencastFrame', ({ data, metadata, sessionId }) => {
			cdp.send('Page.screencastFrameAck', { sessionId }).catch(() => {})
			const f = { ts: metadata.timestamp * 1000, data }
			if (keep) keep.push(f)
			else {
				ring.push(f)
				if (ring.length > 6) ring.shift()
			}
		})
		await cdp.send('Page.startScreencast', { format: 'png', everyNthFrame: 1 })
		await page.mouse.move(spec.width / 2, spec.height / 2)
		const plan = await waitFor(() => worker.evaluate(() => self.__hk.plans.find((p) => p.meteor)), 30000, 'plan', 15)
		keep = ring
		ring = []
		await sleep(Math.max(0, plan.at + 350 - (await page.evaluate(() => performance.timeOrigin + performance.now()))))
		const t0 = await page.evaluate(() => performance.timeOrigin + performance.now())
		if (scenario === 'wheel') await page.mouse.wheel(0, 120)
		if (scenario === 'creep') await page.mouse.wheel(0, 8)
		if (scenario === 'pagedown') await page.keyboard.press('PageDown')
		if (scenario === 'nav') await page.locator('nav a[href^="#"]').first().click()
		await sleep(1800)
		await cdp.send('Page.stopScreencast')
		const hk = await worker.evaluate(() => ({ frames: self.__hk.frames, errors: self.__hk.errors }))
		const ps = (await posts(page)).filter((p) => p.type === 'scroll' && p.at >= t0 - 20)
		return { scenario, rep, t0, plan, frames: hk.frames.filter((f) => f.meteor === 0), scrolls: ps.map((p) => ({ at: p.at, y: p.y })), cast: keep, logs, errors: hk.errors }
	} finally {
		await context.close()
	}
}

function analyze(r) {
	const m = r.plan.meteor
	const firstScroll = r.scrolls[0]?.at ?? Infinity
	const offsetAt = (at) => {
		const s = r.scrolls.filter((p) => p.at <= at).at(-1)
		return s ? s.y : 0
	}
	const after = r.frames.filter((f) => f.at >= firstScroll)
	const drawnFar = after.filter((f) => Math.abs(offsetAt(f.at - 1)) >= 24)
	const lastFrame = r.frames.at(-1)
	const canceled = lastFrame && (lastFrame.time - m.startedAt) < m.duration + 0.39 - 0.05
	const res = {
		scenario: r.scenario,
		rep: r.rep,
		scrollPosts: r.scrolls.slice(0, 8).map((p) => [Math.round(p.at - r.t0), Math.round(p.y)]),
		framesAfterScroll: after.map((f) => ({ dt: Math.round(f.at - r.t0), fade: +f.fade.toFixed(3), offset: Math.round(offsetAt(f.at - 1)) })),
		drawnAt24plus: drawnFar.length,
		canceled,
		lastFrameP: lastFrame ? +((lastFrame.time - m.startedAt) / m.duration).toFixed(2) : null,
		cutMs: after.length ? Math.round(after.at(-1).at - firstScroll) : 0,
		logs: r.logs,
		errors: r.errors,
	}
	// A strip of consecutive composite frames: 3 before the first scroll post to 8 after
	const cast = r.cast
	const i0 = Math.max(0, cast.findIndex((f) => f.ts >= firstScroll) - 3)
	const pick = cast.slice(i0, i0 + 11)
	if (pick.length) {
		const dpr = spec.dsf
		const xs = [m.startX, m.startX + m.dirX * m.length]
		const ys = [m.startY, m.startY + m.dirY * m.length]
		const x0 = Math.max(0, Math.floor((Math.min(...xs) - 60) * dpr))
		const y0 = Math.max(0, Math.floor((Math.min(...ys) - 60) * dpr))
		const w = Math.ceil((Math.max(...xs) - Math.min(...xs) + 120) * dpr)
		const h = Math.ceil((Math.max(...ys) - Math.min(...ys) + 120) * dpr)
		const sdir = path.join(dir, `${r.scenario}-${r.rep}`)
		fs.mkdirSync(sdir, { recursive: true })
		pick.forEach((f, k) => fs.writeFileSync(path.join(sdir, `f${String(k).padStart(2, '0')}-${Math.round(f.ts - r.t0)}ms.png`), encode(crop(decode(Buffer.from(f.data, 'base64')), x0, y0, w, h))))
		res.stripDir = sdir
	}
	return res
}

const browser = await launch()
const out = []
for (const scenario of scenarios)
	for (let rep = 0; rep < repeats; rep++) {
		try {
			const a = analyze(await run(browser, scenario, rep))
			out.push(a)
			console.log(`${scenario} #${rep}: scroll posts ${JSON.stringify(a.scrollPosts)} | meteor frames after the first scroll post ${JSON.stringify(a.framesAfterScroll)} | drawn at 24px+ ${a.drawnAt24plus} | canceled ${a.canceled} at p ${a.lastFrameP} | cut ${a.cutMs} ms | logs ${a.logs.length} errors ${a.errors.length}`)
		} catch (e) {
			console.log(`${scenario} #${rep} failed: ${e.message}`)
		}
	}
write(path.join(dir, 'scroll.json'), out)
await browser.close()
