// C3 and the per-rect headroom, live: the proposed measurement functions (copyReader, quietRect, quietRects, extracted from
// plan/proto/src/components/sky/mountSky.ts and transpiled) run in the real home page (own headless Chromium, dev server) at
// several moments after the reveal, next to the repository's own walk (what the page posts today). Observation only.
//   node mount-check.mjs [width height dpr]
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { launch, PAGE_INIT, posts, pageEpoch, sleep, waitFor } from '../../code-logic/lib.mjs'
import { HERE } from './lib.mjs'

const [width = '1440', height = '900', dpr = '1'] = process.argv.slice(2)
const REPO = 'S:/Documents/repos/Portfolio'
const ts = createRequire(REPO + '/package.json')('typescript')

// The proposed functions, cut out of the proposed file between two markers
// FROM_REPO=1 reads the repository's mountSky.ts (after the patch is applied) instead of the proposed copy
const source = fs.readFileSync(process.env.FROM_REPO ? REPO + '/src/components/sky/mountSky.ts' : path.join(HERE, 'proto/src/components/sky/mountSky.ts'), 'utf8')
const start = source.indexOf('/** What a measurement reads of the copy')
const end = source.indexOf('/**\n * Starts the night sky inside `host`')
if (start < 0 || end < 0) throw new Error('markers not found')
const body = source.slice(start, end)
const header = `import { lightHeadroom, minimumContrast, parseRgbColor } from '/__plan/pure/proto/lib-sky/color.mjs'
const QUIET_CONTROLS = 'a, button'
const NORMAL_FONT_WEIGHT = 400
`
const { outputText } = ts.transpileModule(header + body + '\nexport { copyReader, quietRects }\n', { compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 } })
fs.mkdirSync(path.join(HERE, 'pure/proto'), { recursive: true })
fs.writeFileSync(path.join(HERE, 'pure/proto/mount-measure.mjs'), outputText)

const browser = await launch()
try {
	const context = await browser.newContext({ viewport: { width: Number(width), height: Number(height) }, deviceScaleFactor: Number(dpr), bypassCSP: true })
	await context.addInitScript(PAGE_INIT)
	await context.route('http://localhost:3000/__plan/**', async (route) => {
		const url = new URL(route.request().url())
		const file = path.resolve(HERE, '.' + decodeURIComponent(url.pathname.replace('/__plan', '')))
		if (path.relative(HERE, file).startsWith('..') || !fs.existsSync(file)) return route.fulfill({ status: 404, body: 'missing' })
		return route.fulfill({ contentType: 'text/javascript', body: fs.readFileSync(file, 'utf8') })
	})
	const page = await context.newPage()
	await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 120000 })
	const run = { page }
	const reveal = await waitFor(async () => (await posts(run)).find((p) => p.type === 'reveal'), 60000, 'reveal')
	const wait = async (ms) => {
		while ((await pageEpoch(run)) < reveal.at + ms) await sleep(5)
	}
	await page.evaluate(async () => {
		const { copyReader, quietRects } = await import('/__plan/pure/proto/mount-measure.mjs')
		const tokens = { navy: [10, 25, 47], white: [230, 241, 255] }
		const headrooms = new Map()
		// What the repository's measurement posts today (per line, plain client rects)
		const plainWalk = () => {
			const out = []
			const roots = Array.from(document.querySelectorAll('[data-sky-quiet]')).filter((r) => getComputedStyle(r).position !== 'fixed')
			const range = document.createRange()
			for (const root of roots) {
				const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
				for (let node = walker.nextNode(); node; node = walker.nextNode()) {
					if (!node.textContent.trim()) continue
					range.selectNodeContents(node)
					for (const l of range.getClientRects()) if (l.right > l.left && l.bottom > l.top) out.push({ x: l.left, y: l.top + scrollY, width: l.width, height: l.height })
				}
				for (const c of root.querySelectorAll('a, button')) {
					const b = c.getBoundingClientRect()
					if (b.right > b.left && b.bottom > b.top) out.push({ x: b.left, y: b.top + scrollY, width: b.width, height: b.height })
				}
			}
			return out
		}
		window.__measure = () => {
			const t0 = performance.now()
			const reader = copyReader(tokens, headrooms)
			const flowRoots = Array.from(document.querySelectorAll('[data-sky-quiet]')).filter((r) => getComputedStyle(r).position !== 'fixed')
			const pinnedRoots = Array.from(document.querySelectorAll('[data-sky-quiet]')).filter((r) => getComputedStyle(r).position === 'fixed')
			const quiet = flowRoots.flatMap((root) => quietRects(root, scrollY, reader))
			const pinned = pinnedRoots.flatMap((root) => quietRects(root, 0, reader))
			return { ms: performance.now() - t0, quiet, pinned, plain: plainWalk() }
		}
	})
	const samples = {}
	for (const ms of [20, 150, 350, 700, 1100, 1700]) {
		await wait(ms)
		samples[ms] = await page.evaluate(() => window.__measure())
	}
	await wait(3200)
	const settled = await page.evaluate(() => window.__measure())
	console.log(`viewport ${width}x${height}@${dpr}: ${settled.quiet.length} flow + ${settled.pinned.length} pinned rects; measurement ${settled.ms.toFixed(2)} ms`)
	const diff = (a, b) => {
		let max = 0
		let over = 0
		a.forEach((r, i) => {
			const t = b[i]
			if (!t) return
			const d = Math.max(Math.abs(r.x - t.x), Math.abs(r.y - t.y), Math.abs(r.width - t.width), Math.abs(r.height - t.height))
			if (d > 0.5) over++
			max = Math.max(max, d)
		})
		return `max ${max.toFixed(2)} px, ${over} of ${a.length} rects over 0.5 px`
	}
	console.log('\nrects at each moment after the reveal against the settled proposed measurement (the hero and the footer; Contact is only settled once its entrance has played, so its settled-by-subtraction rects are the true ones)')
	for (const [ms, s] of Object.entries(samples)) {
		console.log(`+${String(ms).padStart(4)} ms  proposed (net of entrance): ${diff(s.quiet, settled.quiet).padEnd(44)} | today's plain walk: ${diff(s.plain, settled.quiet)}  (measure ${s.ms.toFixed(2)} ms)`)
	}
	console.log('\nheadroom per rect (settled), by text:')
	const seen = new Set()
	for (const r of [...settled.quiet, ...settled.pinned]) {
		const key = r.headroom.toFixed(4) + '|' + Math.round(r.height)
		if (seen.has(key)) continue
		seen.add(key)
		console.log(`  headroom ${r.headroom.toFixed(4)}  rect ${Math.round(r.width)}x${Math.round(r.height)} at (${Math.round(r.x)}, ${Math.round(r.y)})`)
	}
	fs.writeFileSync(path.join(HERE, `mount-check-${width}x${height}.json`), JSON.stringify({ samples: Object.fromEntries(Object.entries(samples).map(([k, v]) => [k, { quiet: v.quiet.length }])), settled }, null, 1))
	await context.close()
} finally {
	await browser.close()
}
