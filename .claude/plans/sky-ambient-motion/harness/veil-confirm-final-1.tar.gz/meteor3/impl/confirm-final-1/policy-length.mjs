// Flight length and duration under each tree's own worker radiant policy (final confirmation, observation only).
//   base:  HEAD's updateMeteor loop (keep the radiant while it yields any flight, else up to radiantTries fresh ones, long then short on each)
//   proto: the repository's planLaunch (long flights on the radiant in hand and on fresh ones before any shorter fallback)
// Visits of `per` launches, the radiant sticky within a visit (as in the worker), a fresh visit starts with none.
//   node policy-length.mjs [visits=600] [per=3] <viewport...>
import { P, B, loadCapture, median, pct } from './lib.mjs'
import { mulberry32 } from './pure/proto/lib-sky/random.mjs'

const visits = Number(process.argv[2] ?? 600)
const per = Number(process.argv[3] ?? 3)
const specs = process.argv.slice(4)

function baseLaunch(lib, state, random, field, narrow, t) {
	let plan = state.radiant ? lib.planMeteor(random, field, state.radiant, t) : null
	for (let tries = 0; !plan && tries < (narrow ? 1 : lib.METEOR.radiantTries); tries++) {
		state.radiant = lib.pickRadiant(random, field.width, field.height)
		plan = lib.planMeteor(random, field, state.radiant, t)
	}
	if (!plan) state.radiant = null
	return plan
}

function protoLaunch(lib, state, random, field, narrow, t) {
	const radiants = state.radiant ? [state.radiant] : []
	while (radiants.length < (state.radiant ? 1 : 0) + (narrow ? 1 : lib.METEOR.radiantTries)) radiants.push(lib.pickRadiant(random, field.width, field.height))
	for (const flights of ['long', 'short']) {
		for (const candidate of radiants) {
			const plan = lib.planMeteor(random, field, candidate, t, { flights, ink: 1 })
			if (plan) {
				state.radiant = candidate
				return plan
			}
		}
	}
	state.radiant = null
	return null
}

const fallbackMax = (lib, narrow) => (narrow ? lib.METEOR.narrowFallbackDuration[1] : lib.METEOR.fallbackDuration[1])

for (const spec of specs) {
	const capture = loadCapture(spec)
	const narrow = capture.width <= P.NARROW_MAX_WIDTH
	const rows = []
	for (const [name, lib, launch] of [['HEAD', B, baseLaunch], ['now', P, protoLaunch]]) {
		const random = mulberry32(0x5eed + capture.width)
		const field = { width: capture.width, height: capture.height, quiet: lib.screenQuietZones(capture.quiet, 0, capture.pinned) }
		const paths = []
		const durations = []
		let launches = 0
		let planned = 0
		let short = 0
		for (let v = 0; v < visits; v++) {
			const state = { radiant: null }
			for (let k = 0; k < per; k++) {
				launches++
				const plan = launch(lib, state, random, field, narrow, 0)
				if (!plan) continue
				planned++
				paths.push(plan.length)
				durations.push(plan.duration)
				if (!plan.fireball && plan.duration <= fallbackMax(lib, narrow) + 1e-9) short++
			}
		}
		rows.push({ name, launches, planned, short, path: median(paths), pathP10: pct(paths, 0.1), duration: median(durations), meanDuration: durations.reduce((a, b) => a + b, 0) / Math.max(1, durations.length) })
	}
	const [h, n] = rows
	// Narrow screens: the long (0.75-1.05 s) and fallback (0.6-0.8 s) ranges overlap, so the duration can't tell them apart (c4 counts them)
	const f = (r) => `planned ${((100 * r.planned) / r.launches).toFixed(1)}%, shorter fallback ${narrow ? 'n/a' : ((100 * r.short) / Math.max(1, r.planned)).toFixed(1) + '%'} of planned, path median ${r.path.toFixed(0)} px (p10 ${r.pathP10.toFixed(0)}), duration median ${r.duration.toFixed(2)} s (mean ${r.meanDuration.toFixed(2)} s)`
	console.log(`${spec.padEnd(14)} ${h.launches} launches | HEAD: ${f(h)} | now: ${f(n)}`)
}
