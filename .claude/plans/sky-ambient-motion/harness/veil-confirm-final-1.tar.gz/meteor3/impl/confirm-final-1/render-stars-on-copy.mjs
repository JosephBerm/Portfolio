// How much light do the STARS add inside the text rects? The real drawSky (the repository's and the proposed, transpiled) draws every
// layer at full level with twinkle over the real hero haze in my own headless Chromium, with the live quiet zones fully eased in; each
// frame is compared with the same sky without stars, and the largest R+G+B rise (of 726 = 3 x 242, white over navy) inside any text
// rect is kept per kind of copy. The repository's far layer keeps 0.1 of its light on the copy (up to 0.06 of white at a twinkle peak);
// the proposed one keeps none, so no star adds anything inside a text rect.
//   node render-stars-on-copy.mjs [labels...]       env: SECONDS=14 FPS=12 DPR=<override>
import fs from 'node:fs'
import path from 'node:path'
import { launch } from '../../code-logic/lib.mjs'
import { P, B, HERE, NAVY, loadCapture, fieldOf, textRects, kindOf } from './lib.mjs'

const LABELS = process.argv.slice(2).length ? process.argv.slice(2) : ['1440x900@1', '1280x800@1', '1920x1080@1']
const SECONDS = Number(process.env.SECONDS ?? 14)
const FPS = Number(process.env.FPS ?? 12)
const PAGE = '<!doctype html><meta charset="utf-8"><title>stars</title><body style="margin:0;background:#000"></body>'
const TOKENS = { navy: [10, 25, 47], white: [230, 241, 255], green: [100, 255, 218], card2: [60, 103, 227], card3: [78, 0, 194] }

// Runs in the page: the largest star rise inside each text rect over the sampled moments
async function measure({ tree, width, height, dpr, zones, texts, tokens, seconds, fps }) {
	const sky = (name) => import(`/pure/${tree}/components-sky/${name}`)
	const { drawSky, createStarField } = await sky('renderSky.mjs')
	const { buildStarAtlas, buildHaze, starPalette } = await sky('skyAssets.mjs')
	const { densityKeep } = await import(`/pure/${tree}/lib-sky/catalog.mjs`)
	const W = Math.round(width * dpr)
	const H = Math.round(height * dpr)
	const canvas = new OffscreenCanvas(W, H)
	const ctx = canvas.getContext('2d', { alpha: false, willReadFrequently: true })
	const assets = { atlas: buildStarAtlas(dpr, tokens), haze: buildHaze(width, height, tokens), palette: starPalette(tokens), tokens }
	const field = createStarField()
	const frameAt = (time, stars) => ({
		time, width, height, dpr, deviceWidth: W, deviceHeight: H, parallaxScroll: 0, keep: stars ? densityKeep(width, height) : 0,
		layers: stars ? { far: 1, mid: 1, near: 1 } : { far: 0, mid: 0, near: 0 }, dusk: Infinity, twinkle: 1, haze: 1,
		quiet: { from: [], to: zones, level: 1 }, meteorInk: 1, meteorScroll: 1,
	})
	drawSky(ctx, assets, field, frameAt(0, false))
	const background = ctx.getImageData(0, 0, W, H).data
	const worst = texts.map(() => 0)
	const starsInRects = texts.map(() => 0)
	let frames = 0
	for (let t = 0; t < seconds; t += 1 / fps) {
		drawSky(ctx, assets, field, frameAt(t, true))
		const data = ctx.getImageData(0, 0, W, H).data
		frames++
		texts.forEach((text, k) => {
			const x0 = Math.max(0, Math.floor(text.x * dpr))
			const y0 = Math.max(0, Math.floor(text.y * dpr))
			const x1 = Math.min(W, Math.ceil((text.x + text.width) * dpr))
			const y1 = Math.min(H, Math.ceil((text.y + text.height) * dpr))
			for (let y = y0; y < y1; y++) {
				for (let x = x0; x < x1; x++) {
					const i = (y * W + x) * 4
					const rise = data[i] - background[i] + data[i + 1] - background[i + 1] + data[i + 2] - background[i + 2]
					if (rise > worst[k]) worst[k] = rise
					if (rise > 2) starsInRects[k]++
				}
			}
		})
	}
	return { frames, worst: texts.map((text, k) => ({ kind: text.kind, rise: worst[k], litPixelFrames: starsInRects[k] })) }
}

const browser = await launch()
try {
	const context = await browser.newContext({ viewport: { width: 800, height: 600 } })
	await context.route('http://sky.test/**', async (route) => {
		const url = new URL(route.request().url())
		if (url.pathname === '/') return route.fulfill({ contentType: 'text/html', body: PAGE })
		const file = path.resolve(HERE, '.' + decodeURIComponent(url.pathname))
		if (path.relative(HERE, file).startsWith('..') || !fs.existsSync(file)) return route.fulfill({ status: 404, body: 'missing' })
		return route.fulfill({ contentType: 'text/javascript', body: fs.readFileSync(file, 'utf8') })
	})
	const page = await context.newPage()
	page.on('pageerror', (e) => console.log('pageerror', e.message))
	await page.goto('http://sky.test/')
	console.log(`largest star rise (R+G+B of 726) inside any text rect, ${SECONDS} s at ${FPS} fps with twinkle, quiet zones fully eased in`)
	for (const label of LABELS) {
		const capture = loadCapture(label)
		const dpr = Number(process.env.DPR ?? Math.min(capture.dpr, 2))
		const texts = textRects(capture).map((r) => ({ x: r.x, y: r.y, width: r.width, height: r.height, kind: kindOf(r.desc) }))
		for (const tree of ['base', 'proto']) {
			const field = fieldOf(capture, tree === 'base' ? B : P)
			const result = await page.evaluate(measure, { tree, width: capture.width, height: capture.height, dpr, zones: field.quiet, texts, tokens: TOKENS, seconds: SECONDS, fps: FPS })
			const byKind = {}
			for (const w of result.worst) {
				const entry = (byKind[w.kind] ??= { rise: 0, lit: 0 })
				entry.rise = Math.max(entry.rise, w.rise)
				entry.lit += w.litPixelFrames
			}
			const summary = Object.entries(byKind)
				.map(([kind, v]) => `${kind} ${v.rise}${v.lit ? ` (${v.lit} lit pixel-frames)` : ''}`)
				.join('; ')
			console.log(`${label} DPR ${dpr} ${tree.padEnd(5)} max rise: ${summary}`)
		}
	}
} finally {
	await browser.close()
}
