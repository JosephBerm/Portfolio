// Renders shooting stars with the real drawing code (the repository's and the proposed renderSky/skyAssets, transpiled) in
// my own headless Chromium, on an OffscreenCanvas the size of the viewport (navy and the real hero haze, no stars), and reads
// the pixels back frame by frame at 60 fps:
//   visible:      how long anything is lit (R+G+B at least 30 above the sky), and how long it is lit INSIDE a text rect
//   readability:  for every text rect, the lowest WCAG contrast of its own text color against the rendered pixels there,
//                 plain and with the worst far star added on the same pixel (STAR_INK_PEAK of white), against its AA minimum
// Flights are planned in Node with each tree's own planMeteor against the live rects of the capture, seeded.
//   node render3.mjs [labels...]       env: FLIGHTS=60 TREES=base,proto DPR=<override>
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { launch } from '../../code-logic/lib.mjs'
import { P, B, HERE, NAVY, WHITE, loadCapture, fieldOf, textRects, kindOf } from './lib.mjs'

const LABELS = process.argv.slice(2).length ? process.argv.slice(2) : ['1440x900@1', '1280x800@1', '1920x1080@1']
const PER_TREE = Number(process.env.FLIGHTS ?? 60)
const TREES = (process.env.TREES ?? 'base,proto').split(',')
const STAR = P.STAR_INK_PEAK

const PAGE = '<!doctype html><meta charset="utf-8"><title>render</title><body style="margin:0;background:#000"></body>'
const TOKENS = { navy: [10, 25, 47], white: [230, 241, 255], green: [100, 255, 218], card2: [60, 103, 227], card3: [78, 0, 194] }

// Runs in the page: measures one tree's flights at one viewport
async function measure({ tree, width, height, dpr, flights, zones, texts, tokens, star, ink }) {
	const sky = (name) => import(`/pure/${tree}/components-sky/${name}`)
	const { drawSky, drawMeteor, createStarField } = await sky('renderSky.mjs')
	const { buildStarAtlas, buildHaze, starPalette } = await sky('skyAssets.mjs')
	const { meteorLifetime } = await import(`/pure/${tree}/lib-sky/meteors.mjs`)
	const W = Math.round(width * dpr)
	const H = Math.round(height * dpr)
	const canvas = new OffscreenCanvas(W, H)
	const ctx = canvas.getContext('2d', { alpha: false, willReadFrequently: true })
	const assets = { atlas: buildStarAtlas(dpr, tokens), haze: buildHaze(width, height, tokens), palette: starPalette(tokens), tokens }
	const field = createStarField()
	const frameAt = (time) => ({
		time, width, height, dpr, deviceWidth: W, deviceHeight: H, parallaxScroll: 0, keep: 0, layers: { far: 0, mid: 0, near: 0 }, dusk: Infinity, twinkle: 0, haze: 1,
		quiet: { from: [], to: zones, level: 1 }, meteorInk: ink, meteorScroll: 1,
	})
	const lin = (c) => {
		const v = c / 255
		return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4
	}
	const lum = (r, g, b) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
	const contrast = (l1, l2) => (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05)
	const out = []
	for (const flight of flights) {
		const xs = [flight.startX, flight.startX + flight.dirX * flight.length]
		const ys = [flight.startY, flight.startY + flight.dirY * flight.length]
		const pad = 14
		const x0 = Math.max(0, Math.floor((Math.min(...xs) - pad) * dpr))
		const y0 = Math.max(0, Math.floor((Math.min(...ys) - pad) * dpr))
		const x1 = Math.min(W, Math.ceil((Math.max(...xs) + pad) * dpr))
		const y1 = Math.min(H, Math.ceil((Math.max(...ys) + pad) * dpr))
		const bw = x1 - x0
		const bh = y1 - y0
		drawSky(ctx, assets, field, frameAt(0))
		const background = ctx.getImageData(x0, y0, bw, bh).data
		// Pixels of each text rect inside the box; per rect the text color luminance and its minimum
		const rectPixels = texts.map((text) => {
			const px = []
			const rx0 = Math.max(x0, Math.floor(text.x * dpr))
			const ry0 = Math.max(y0, Math.floor(text.y * dpr))
			const rx1 = Math.min(x1, Math.ceil((text.x + text.width) * dpr))
			const ry1 = Math.min(y1, Math.ceil((text.y + text.height) * dpr))
			for (let y = ry0; y < ry1; y++) for (let x = rx0; x < rx1; x++) px.push((y - y0) * bw + (x - x0))
			return px
		})
		const textLum = texts.map((text) => lum(text.rgb[0], text.rgb[1], text.rgb[2]))
		const worst = texts.map(() => ({ rise: 0, contrast: Infinity, contrastStar: Infinity, frames: 0 }))
		const lifetime = meteorLifetime(flight)
		let frames30 = 0
		let framesOnCopy30 = 0
		let framesOnCopy87 = 0
		let first30 = null
		let last30 = null
		for (let t = 0; t <= lifetime + 0.05; t += 1 / 60) {
			drawSky(ctx, assets, field, frameAt(t))
			drawMeteor(ctx, assets, flight, frameAt(t))
			const data = ctx.getImageData(x0, y0, bw, bh).data
			let maxRise = 0
			for (let i = 0; i < data.length; i += 4) {
				const rise = data[i] - background[i] + data[i + 1] - background[i + 1] + data[i + 2] - background[i + 2]
				if (rise > maxRise) maxRise = rise
			}
			if (maxRise >= 30) {
				frames30++
				first30 ??= t
				last30 = t
			}
			let onCopy = false
			let onCopy87 = false
			for (let k = 0; k < texts.length; k++) {
				const w = worst[k]
				let rectRise = 0
				for (const index of rectPixels[k]) {
					const i = index * 4
					const rise = data[i] - background[i] + data[i + 1] - background[i + 1] + data[i + 2] - background[i + 2]
					if (rise <= 0) continue
					if (rise > rectRise) rectRise = rise
					const c = contrast(textLum[k], lum(data[i], data[i + 1], data[i + 2]))
					if (c < w.contrast) w.contrast = c
					const cs = contrast(textLum[k], lum(Math.min(255, data[i] + star * tokens.white[0]), Math.min(255, data[i + 1] + star * tokens.white[1]), Math.min(255, data[i + 2] + star * tokens.white[2])))
					if (cs < w.contrastStar) w.contrastStar = cs
				}
				if (rectRise > w.rise) w.rise = rectRise
				if (rectRise >= 30) {
					w.frames++
					onCopy = true
				}
				if (rectRise >= 87) onCopy87 = true
			}
			if (onCopy) framesOnCopy30++
			if (onCopy87) framesOnCopy87++
		}
		out.push({
			duration: flight.duration,
			length: flight.length,
			seconds30: frames30 / 60,
			span30: first30 === null ? 0 : last30 - first30,
			onCopySeconds30: framesOnCopy30 / 60,
			onCopySeconds87: framesOnCopy87 / 60,
			worst: worst.map((w, k) => ({ rise: w.rise, contrast: w.contrast === Infinity ? null : w.contrast, contrastStar: w.contrastStar === Infinity ? null : w.contrastStar, seconds: w.frames / 60, kind: texts[k].kind, min: texts[k].min })),
		})
	}
	return out
}

function plan(tree, field, capture, extra) {
	const lib = tree === 'base' ? B : P
	const random = lib.mulberry32(0xf3 + capture.width * 3 + capture.height + Number(process.env.SEED ?? 0))
	const flights = []
	const forced = []
	for (let i = 0; i < 30000 && (flights.length < PER_TREE || forced.length < extra); i++) {
		const f = lib.planMeteor(random, field, lib.pickRadiant(random, field.width, field.height), 0)
		if (!f) continue
		if (flights.length < PER_TREE) flights.push(f)
		else if (tree === 'proto') {
			// extra flights that reach the copy, at the brightest peak the planner allows
			let ink = false
			for (let k = 1; k < 200 && !ink; k++) {
				const { x, y } = lib.meteorPoint(f, k / 200)
				ink = lib.inkAt(field.quiet, x, y) === 1
			}
			if (ink) forced.push({ ...f, peak: Math.max(f.peak, 0.9) })
		}
	}
	return { flights, forced }
}

const browser = await launch()
const results = {}
try {
	const context = await browser.newContext({ viewport: { width: 800, height: 600 } })
	await context.route('http://sky.test/**', async (route) => {
		const url = new URL(route.request().url())
		if (url.pathname === '/') return route.fulfill({ contentType: 'text/html', body: PAGE })
		const file = path.resolve(HERE, '.' + decodeURIComponent(url.pathname))
		if (path.relative(HERE, file).startsWith('..') || !fs.existsSync(file)) return route.fulfill({ status: 404, body: 'missing' })
		return route.fulfill({ contentType: 'text/javascript', body: fs.readFileSync(file, 'utf8') })
	})
	const page = await context.newPage()
	page.on('pageerror', (e) => console.log('pageerror', e.message))
	await page.goto('http://sky.test/')
	for (const label of LABELS) {
		const capture = loadCapture(label)
		const dpr = Number(process.env.DPR ?? Math.min(capture.dpr, 2))
		const rects = textRects(capture)
		const texts = rects.map((r) => {
			const color = P.parseRgbColor(r.desc.color, NAVY)
			return { x: r.x, y: r.y, width: r.width, height: r.height, rgb: color, min: P.minimumContrast(r.desc.fontSize, Number(r.desc.fontWeight)), kind: kindOf(r.desc) }
		})
		results[label] = {}
		for (const tree of TREES) {
			const field = fieldOf(capture, tree === 'base' ? B : P)
			const { flights, forced } = plan(tree, field, capture, tree === 'proto' ? Number(process.env.FORCED ?? 40) : 0)
			const started = Date.now()
			const measured = await page.evaluate(measure, { tree, width: capture.width, height: capture.height, dpr, flights, zones: field.quiet, texts, tokens: TOKENS, star: STAR, ink: Number(process.env.INK ?? 1) })
			const stress = forced.length ? await page.evaluate(measure, { tree, width: capture.width, height: capture.height, dpr, flights: forced, zones: field.quiet, texts, tokens: TOKENS, star: STAR, ink: Number(process.env.INK ?? 1) }) : []
			results[label][tree] = { measured, stress }
			const med = (a) => [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)]
			const onCopy = measured.filter((m) => m.onCopySeconds30 >= 0.1)
			const onCopy87 = measured.filter((m) => (m.onCopySeconds87 ?? 0) >= 0.1)
			console.log(
				label,
				tree,
				`${measured.length} flights (${((Date.now() - started) / 1000).toFixed(1)} s): lit ${med(measured.map((m) => m.seconds30)).toFixed(2)} s median, ` +
					`lit on copy for 0.1 s or more in ${onCopy.length} (${((100 * onCopy.length) / measured.length).toFixed(0)}%), median on-copy ${onCopy.length ? med(onCopy.map((m) => m.onCopySeconds30)).toFixed(2) : '-'} s; by 87 of 726 (0.12 of white) for 0.1 s or more in ${onCopy87.length} (${((100 * onCopy87.length) / measured.length).toFixed(0)}%)`
			)
		}
	}
} finally {
	await browser.close()
}
fs.writeFileSync(path.join(HERE, `render3-results${process.env.TAG ?? ''}.json`), JSON.stringify(results))

// Summary: per kind of copy, the worst rendered contrast against its AA minimum, plain and with a far star
const rows = {}
for (const [label, trees] of Object.entries(results)) {
	for (const [tree, { measured, stress }] of Object.entries(trees)) {
		for (const set of [['planned', measured], ['stress', stress]]) {
			for (const m of set[1]) {
				for (const w of m.worst) {
					if (w.contrast === null) continue
					const key = `${label} ${tree} ${set[0]} ${w.kind}`
					const r = (rows[key] ??= { min: w.min, contrast: Infinity, contrastStar: Infinity, rise: 0, flights: 0 })
					r.contrast = Math.min(r.contrast, w.contrast)
					r.contrastStar = Math.min(r.contrastStar, w.contrastStar)
					r.rise = Math.max(r.rise, w.rise)
					r.flights++
				}
			}
		}
	}
}
console.log('\nworst rendered contrast per kind of copy (AA minimum; plain; with the brightest far star on the same pixel; max R+G+B rise; flights that lit it)')
for (const [key, r] of Object.entries(rows)) console.log(key.padEnd(54), `min ${r.min}`, `plain ${r.contrast.toFixed(2)}`, `+star ${r.contrastStar.toFixed(2)}`, `rise ${r.rise}`, `n ${r.flights}`)
