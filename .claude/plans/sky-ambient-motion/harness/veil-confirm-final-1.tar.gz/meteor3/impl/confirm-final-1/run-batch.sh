#!/bin/bash
# The planner-, worker- and style-dependent offline checks on the fixed code (impl/fix1/pure/proto re-transpiled from the repository).
# Mirrors impl/live/run-opt-check.sh; outputs in results/batch/. Run after `node transpile.mjs && node harness/build.mjs`, with nothing else using pure/.
cd "$(dirname "$0")"
R=results/batch
mkdir -p $R
rm -f $R/batch.done
OUT=$R node sim2.mjs 4000 > $R/planner-9-viewports.txt 2>&1 &
node checks.mjs 2000 > $R/invariants.txt 2>&1 &
node checks-r2.mjs 1500 > $R/invariants-r2.txt 2>&1 &
node equiv-d.mjs > $R/equiv-d.txt 2>&1 &
node equiv.mjs > $R/equivalence-stars.txt 2>&1 &
node check-interface.mjs > $R/check-interface.txt 2>&1 &
node check-fade.mjs > $R/check-fade.txt 2>&1 &
node harness/worker-tests.mjs c1 > $R/worker-c1.txt 2>&1 &
node harness/worker-tests.mjs c2 > $R/worker-c2.txt 2>&1 &
node harness/worker-tests.mjs c4 > $R/worker-c4.txt 2>&1 &
node harness/visits.mjs 240 3 1440x900@1 > $R/visits-1440x900.txt 2>&1 &
node harness/visits.mjs 160 3 1280x800@1 > $R/visits-1280x800.txt 2>&1 &
node check-e.mjs 2000 150 1 1440x900@1 1280x800@1 1280x720@1 1024x768@1 390x844@3m > $R/check-e-a.txt 2>&1 &
node check-e.mjs 2000 100 1 1366x768@1 1536x864@1.25 1920x1080@1 2560x1440@1 > $R/check-e-b.txt 2>&1 &
wait
echo done > $R/batch.done
