#!/bin/bash
# The worker-level checks on the final code: the audit's adversarial suite (A-H, held layouts at 15 and 30 px), check W (plain) and its held variant.
cd "$(dirname "$0")"
mkdir -p results/final
rm -f results/final/done
(TREE=proto MAXMOVE=15 node --max-old-space-size=8000 worker-adv.mjs 10 > results/final/worker-adv-move15.log 2>&1) &
(TREE=proto MAXMOVE=30 node --max-old-space-size=8000 worker-adv.mjs 10 > results/final/worker-adv-move30.log 2>&1) &
wait
node --max-old-space-size=10000 check-w.mjs 1440x900@1 24 proto > results/final/check-w-1440x900-proto.txt 2>&1 &
node --max-old-space-size=10000 check-w.mjs 1280x800@1 24 proto > results/final/check-w-1280x800-proto.txt 2>&1 &
wait
HELD=1 node --max-old-space-size=10000 check-w.mjs 1440x900@1 24 proto > results/final/check-w-held-1440x900-proto.txt 2>&1 &
HELD=1 node --max-old-space-size=10000 check-w.mjs 1440x900@1 24 before > results/final/check-w-held-1440x900-before.txt 2>&1 &
wait
HELD=1 node --max-old-space-size=10000 check-w.mjs 1280x800@1 24 proto > results/final/check-w-held-1280x800-proto.txt 2>&1 &
HELD=1 node --max-old-space-size=10000 check-w.mjs 1280x800@1 24 before > results/final/check-w-held-1280x800-before.txt 2>&1 &
wait
echo done > results/final/done
