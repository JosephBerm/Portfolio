#!/bin/bash
# Live: a layout waiting under a flying star (audit finding correctness-wcag:F1), on the dev server; frames the worker could not have known about are skipped.
cd "$(dirname "$0")"
rm -f results/live-held.done
STEP1=17 STEP2=18 TAG=-17-18 node live/d2-held.mjs 16 held > results/live-d2-held-17-18.txt 2>&1
node live/d2-held.mjs 8 held > results/live-d2-held-19-22.txt 2>&1
node live/d2-held.mjs 6 single > results/live-d2-single.txt 2>&1
echo done > results/live-held.done
