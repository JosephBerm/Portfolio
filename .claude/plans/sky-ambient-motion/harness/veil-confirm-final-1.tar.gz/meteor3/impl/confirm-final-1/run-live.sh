#!/bin/bash
# Live checks on the dev server (own headless Chromium, one at a time, nothing else running): the fixes' boot, the haze rebuild (resizegap, pop),
# a layout waiting under a flying star (d2-held), the page-level smoke tests, and the worker's frame cost with resizes.
cd "$(dirname "$0")"
mkdir -p results live/logs
rm -f results/live.done
node live/probe-fix.mjs > results/live-probe.txt 2>&1
node live/resizegap.mjs > results/live-resizegap.txt 2>&1
node live/pop.mjs > results/live-pop.txt 2>&1
node live/d2-held.mjs 8 held > results/live-d2-held-19-22.txt 2>&1
STEP1=17 STEP2=18 TAG=-17-18 node live/d2-held.mjs 8 held > results/live-d2-held-17-18.txt 2>&1
node live/d2-held.mjs 4 single > results/live-d2-single.txt 2>&1
node live/perf.mjs 1440x900@1 2 > results/live-perf-1440x900.txt 2>&1
node ../live-smoke.mjs 2 > results/live-smoke-desktop.txt 2>&1
MODE=reduced node ../live-smoke.mjs 1 1440x900@1 > results/live-smoke-reduced.txt 2>&1
MODE=forced node ../live-smoke.mjs 1 1440x900@1 > results/live-smoke-forced.txt 2>&1
echo done > results/live.done
