#!/bin/bash
# Rendered readability on the final code (own headless Chromium): the lowest WCAG contrast of copy a flight lit, its brightest rise against the budget, and what the stars add on the copy.
cd "$(dirname "$0")"
mkdir -p results/render
rm -f results/render/done
TAG=-final-dpr1 node render3.mjs 1440x900@1 1280x800@1 1920x1080@1 > results/render/readability-dpr1.log 2>&1 &
TAG=-final-dpr2 DPR=2 node render3.mjs 1440x900@1 > results/render/readability-dpr2.log 2>&1 &
node render-stars-on-copy.mjs 1440x900@1 > results/render/stars-on-copy.txt 2>&1 &
wait
echo done > results/render/done
