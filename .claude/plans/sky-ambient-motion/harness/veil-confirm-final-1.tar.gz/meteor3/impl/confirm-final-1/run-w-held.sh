#!/bin/bash
# Check W held variant (audit finding correctness-wcag:F1): one tree per process, two at a time.
cd "$(dirname "$0")"
mkdir -p results
HELD=1 node --max-old-space-size=10000 check-w.mjs 1440x900@1 24 proto > results/check-w-held-1440x900-proto.txt 2>&1 &
HELD=1 node --max-old-space-size=10000 check-w.mjs 1440x900@1 24 before > results/check-w-held-1440x900-before.txt 2>&1 &
wait
HELD=1 node --max-old-space-size=10000 check-w.mjs 1280x800@1 24 proto > results/check-w-held-1280x800-proto.txt 2>&1 &
HELD=1 node --max-old-space-size=10000 check-w.mjs 1280x800@1 24 before > results/check-w-held-1280x800-before.txt 2>&1 &
wait
echo done > results/run-w-held.done
