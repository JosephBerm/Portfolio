#!/bin/bash
# Check W (D2, the shift of copy under a passing head) and its held variant (round-1 fix for audit finding correctness-wcag:F1).
# One tree per process (each simulated visit leaves a worker module instance behind), two processes at a time.
cd "$(dirname "$0")"
mkdir -p results
HELD=1 node --max-old-space-size=10000 check-w.mjs 1440x900@1 24 proto > results/check-w-held-1440x900-proto.txt 2>&1 &
HELD=1 node --max-old-space-size=10000 check-w.mjs 1440x900@1 24 before > results/check-w-held-1440x900-before.txt 2>&1 &
wait
HELD=1 node --max-old-space-size=10000 check-w.mjs 1280x800@1 24 proto > results/check-w-held-1280x800-proto.txt 2>&1 &
HELD=1 node --max-old-space-size=10000 check-w.mjs 1280x800@1 24 before > results/check-w-held-1280x800-before.txt 2>&1 &
wait
node --max-old-space-size=10000 check-w.mjs 1440x900@1 24 proto > results/check-w-1440x900-proto.txt 2>&1 &
node --max-old-space-size=10000 check-w.mjs 1280x800@1 24 proto > results/check-w-1280x800-proto.txt 2>&1 &
wait
echo done > results/run-w.done
