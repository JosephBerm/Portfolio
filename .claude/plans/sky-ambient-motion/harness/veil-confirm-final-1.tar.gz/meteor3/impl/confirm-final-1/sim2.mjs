// Planner statistics against the live rects, revision 2: today's planner and veil against the proposed ones, per viewport.
// A flight "passes behind copy" at level L when its head center is inside a text rect adding at least L of white (the head
// pixel only) for at least 0.1 s. The aim targets L = METEOR_PASS.visible (0.12); 0.04 counts every glimmer (the tagline's
// budget is about 0.10, so tagline passes show up only there) and 0.17 is a clearly visible streak.
//   node sim2.mjs [launches] [label...]      JSON copy of the rows: ${OUT}/sim2.json (OUT defaults to results-r3)
import fs from 'node:fs'
import { P, B, HERE, loadCapture, fieldOf, textRects, insideRect, kindOf, walkProto, walkBase, median, pct, fmt } from './lib.mjs'

const N = Number(process.argv[2] ?? 4000)
const labels = process.argv.slice(3).length ? process.argv.slice(3) : ['1440x900@1', '1280x800@1', '1366x768@1', '1536x864@1.25', '1920x1080@1', '2560x1440@1', '1280x720@1', '1024x768@1', '390x844@3m']
const STEPS = 400
const LEVELS = [0.04, 0.12, 0.17]
const TARGET = 0.12

function stats(tree, capture) {
	const lib = tree === 'base' ? B : P
	const field = fieldOf(capture, lib)
	const rects = textRects(capture)
	const random = lib.mulberry32(0xa11ce + capture.width * 7 + capture.height)
	const walk = tree === 'base' ? walkBase : walkProto
	const out = { launches: N, planned: 0, short: 0, nearCopy: 0, reach: 0, pass: Object.fromEntries(LEVELS.map((l) => [l, 0])), passTimes: [], maxRise: [], paths: [], durs: [], headTime: [], kinds: { fireball: 0, flare: 0, train: 0 }, byCopy: {}, worst: {} }
	for (let i = 0; i < N; i++) {
		const radiant = lib.pickRadiant(random, capture.width, capture.height)
		const f = lib.planMeteor(random, field, radiant, 0)
		if (!f) continue
		out.planned++
		const narrow = capture.width <= 640
		if (f.duration <= (narrow ? lib.METEOR.narrowFallbackDuration[1] : lib.METEOR.fallbackDuration[1]) + 1e-9 && !f.fireball) out.short++
		out.paths.push(f.length)
		out.durs.push(f.duration)
		if (f.fireball) out.kinds.fireball++
		if (f.flare) out.kinds.flare++
		if (f.train) out.kinds.train++
		if (f.nearCopy) out.nearCopy++
		const w = walk(f, field.quiet, STEPS)
		let reached = false
		let maxRise = 0
		const on = Object.fromEntries(LEVELS.map((l) => [l, 0]))
		const copies = Object.fromEntries(LEVELS.map((l) => [l, new Set()]))
		for (const s of w) {
			if (s.rise >= TARGET) on.head = (on.head ?? 0) + 1
			if (!s.onCopy) continue
			reached = true
			maxRise = Math.max(maxRise, s.rise)
			const inside = rects.filter((r) => insideRect(r, s.x, s.y))
			const strictest = inside.reduce((a, r) => (!a || r.headroom < a.headroom ? r : a), null)
			if (strictest && tree === 'proto') {
				const k = kindOf(strictest.desc)
				const budget = P.inkBudget(strictest.headroom)
				out.worst[k] = Math.max(out.worst[k] ?? 0, (s.rise + P.STAR_INK_PEAK + P.INK_BUDGET.hazeReserve) / strictest.headroom)
				out.worst['rise ' + k] = Math.max(out.worst['rise ' + k] ?? 0, s.rise / Math.max(budget, 1e-9))
			}
			for (const l of LEVELS) {
				if (s.rise < l) continue
				on[l]++
				if (strictest) copies[l].add(kindOf(strictest.desc))
			}
		}
		if (reached) out.reach++
		if (reached) out.maxRise.push(maxRise)
		out.headTime.push(((on.head ?? 0) / STEPS) * f.duration)
		for (const l of LEVELS) {
			if ((on[l] / STEPS) * f.duration < 0.1) continue
			out.pass[l]++
			if (l === TARGET) {
				out.passTimes.push((on[l] / STEPS) * f.duration)
				for (const k of copies[l]) out.byCopy[k] = (out.byCopy[k] ?? 0) + 1
			}
		}
	}
	return out
}

console.log(`launches per cell ${N}; PASS@L = head center on a text rect adding >= L of white for >= 0.1 s; aim target ${TARGET}; METEOR_PASS ${JSON.stringify(P.METEOR_PASS)}\n`)
console.log('viewport       tree   planned  short  nearCopy  reach  PASS@.04  PASS@.12  PASS@.17  time at >=.12 on copy med/p90 (s)  max rise on copy med/p90   head time >=.12 med (s)  fireball flare train   path med  dur med')
const rows = []
for (const label of labels) {
	const capture = loadCapture(label)
	for (const tree of ['base', 'proto']) {
		const s = stats(tree, capture)
		const pc = (v) => ((100 * v) / N).toFixed(1).padStart(5) + '%'
		const pcp = (v) => ((100 * v) / Math.max(1, s.planned)).toFixed(1).padStart(4) + '%'
		const row = {
			label,
			tree,
			planned: s.planned / N,
			short: s.short / N,
			nearCopy: s.nearCopy / N,
			reach: s.reach / N,
			pass: Object.fromEntries(LEVELS.map((l) => [l, s.pass[l] / N])),
			passTimeMedian: median(s.passTimes),
			passTimeP90: pct(s.passTimes, 0.9),
			maxRiseMedian: median(s.maxRise),
			maxRiseP90: pct(s.maxRise, 0.9),
			headTimeMedian: median(s.headTime),
			kinds: Object.fromEntries(Object.entries(s.kinds).map(([k, v]) => [k, v / Math.max(1, s.planned)])),
			byCopy: s.byCopy,
			worst: s.worst,
			pathMedian: median(s.paths),
			durMedian: median(s.durs),
		}
		rows.push(row)
		console.log(
			label.padEnd(14),
			tree.padEnd(6),
			pc(s.planned),
			pc(s.short),
			pc(s.nearCopy),
			pc(s.reach),
			pc(s.pass[0.04]).padStart(8),
			pc(s.pass[0.12]).padStart(9),
			pc(s.pass[0.17]).padStart(9),
			(fmt(row.passTimeMedian, 2) + ' / ' + fmt(row.passTimeP90, 2)).padStart(30),
			(fmt(row.maxRiseMedian, 3) + ' / ' + fmt(row.maxRiseP90, 3)).padStart(24),
			fmt(row.headTimeMedian, 2).padStart(16),
			pcp(s.kinds.fireball).padStart(10),
			pcp(s.kinds.flare).padStart(5),
			pcp(s.kinds.train).padStart(5),
			fmt(row.pathMedian, 0).padStart(9),
			fmt(row.durMedian, 2).padStart(8)
		)
		if (tree === 'proto') console.log('   passes at >= .12 by copy:', JSON.stringify(s.byCopy), '| worst (rise + star + haze) / headroom:', JSON.stringify(Object.fromEntries(Object.entries(s.worst).filter(([k]) => !k.startsWith('rise ')).map(([k, v]) => [k, +v.toFixed(3)]))), '| worst rise / budget:', JSON.stringify(Object.fromEntries(Object.entries(s.worst).filter(([k]) => k.startsWith('rise ')).map(([k, v]) => [k.slice(5), +v.toFixed(3)]))))
	}
}
const OUT = process.env.OUT ?? 'results-r3'
fs.mkdirSync(`${HERE}/${OUT}`, { recursive: true })
fs.writeFileSync(`${HERE}/${OUT}/sim2.json`, JSON.stringify({ launches: N, steps: STEPS, meteorPass: P.METEOR_PASS, rows }, null, 1))
