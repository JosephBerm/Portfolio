// Frame strips of proposed shooting stars over the real page (own headless Chromium, observation only): the home page loads
// from the dev server, the page's own sky canvas is hidden in this browser, and a canvas in the same fixed layer (under
// #content) is drawn with the proposed renderSky (transpiled), so the real copy sits on top exactly as it will. Flights are
// planned with the proposed planMeteor against the rects of the live capture. Twinkle is off so frames differ only by the
// shooting star. Output: plan/shots/<tag>-<label>-<n>.png and plan/shots/<tag>-<label>.html.
//   node strips.mjs <label> <seed> <count> [kind]   kind: pass | dim | clear | any
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { launch, pageEpoch, sleep, waitPost, PAGE_INIT } from '../../code-logic/lib.mjs'
import { P, HERE, loadCapture, fieldOf, walkProto } from './lib.mjs'

const SHOTS = process.env.SHOTS ?? path.join(HERE, 'shots')
fs.mkdirSync(SHOTS, { recursive: true })
const [label = '1440x900@1', seedArg = '11', countArg = '3', kindArg = 'pass'] = process.argv.slice(2)
const FRAMES = Number(process.env.FRAMES ?? 12)
const capture = loadCapture(label)
const field = fieldOf(capture)
const random = P.mulberry32(Number(seedArg))

function classify(f) {
	const w = walkProto(f, field.quiet, 300)
	const onCopyVisible = (w.filter((s) => s.onCopy && s.rise >= P.METEOR_PASS.visible).length / 300) * f.duration
	if (onCopyVisible >= 0.15) return { kind: 'pass', visible: onCopyVisible }
	if (w.some((s) => s.kept < 0.999)) return { kind: 'dim', visible: onCopyVisible }
	return { kind: 'clear', visible: 0 }
}

const chosen = []
for (let i = 0; i < 20000 && chosen.length < Number(countArg); i++) {
	const f = P.planMeteor(random, field, P.pickRadiant(random, field.width, field.height), 0)
	if (!f || f.fireball) continue
	const c = classify(f)
	if (kindArg === 'any' || c.kind === kindArg) chosen.push({ flight: f, ...c })
}
console.log(label, 'chosen', chosen.map((c) => `${c.kind}(${c.visible.toFixed(2)}s, ${Math.round(c.flight.length)}px, ${c.flight.duration.toFixed(2)}s)`).join(' '))

const browser = await launch()
const sheets = []
try {
	const mobile = label.endsWith('m')
	const context = await browser.newContext({ viewport: { width: capture.width, height: capture.height }, deviceScaleFactor: capture.dpr, isMobile: mobile, hasTouch: mobile, bypassCSP: true })
	await context.addInitScript(PAGE_INIT)
	await context.route('http://localhost:3000/__plan/**', async (route) => {
		const url = new URL(route.request().url())
		const file = path.resolve(HERE, '.' + decodeURIComponent(url.pathname.replace('/__plan', '')))
		if (path.relative(HERE, file).startsWith('..') || !fs.existsSync(file)) return route.fulfill({ status: 404, body: 'missing' })
		return route.fulfill({ contentType: 'text/javascript', body: fs.readFileSync(file, 'utf8') })
	})
	const page = await context.newPage()
	const logs = []
	page.on('pageerror', (e) => logs.push(e.message))
	await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 120000 })
	const run = { page }
	const reveal = await waitPost(run, (p) => p.type === 'reveal', 60000, 'reveal')
	while ((await pageEpoch(run)) < reveal.at + 2800) await sleep(100)
	await page.evaluate(
		async ({ zones, dpr }) => {
			const host = document.querySelector('canvas[data-ready]')?.parentElement
			const original = host.querySelector('canvas')
			original.style.display = 'none'
			const canvas = document.createElement('canvas')
			canvas.className = original.className
			canvas.dataset.ready = ''
			canvas.width = Math.round(innerWidth * Math.min(dpr, 2))
			canvas.height = Math.round(innerHeight * Math.min(dpr, 2))
			host.append(canvas)
			const { drawSky, drawMeteor, createStarField } = await import('/__plan/pure/proto/components-sky/renderSky.mjs')
			const { buildStarAtlas, buildHaze, starPalette } = await import('/__plan/pure/proto/components-sky/skyAssets.mjs')
			const { densityKeep } = await import('/__plan/pure/proto/lib-sky/catalog.mjs')
			const tokens = { navy: [10, 25, 47], white: [230, 241, 255], green: [100, 255, 218], card2: [60, 103, 227], card3: [78, 0, 194] }
			const ratio = Math.min(dpr, 2)
			const field = createStarField()
			const assets = { atlas: buildStarAtlas(ratio, tokens), haze: buildHaze(innerWidth, innerHeight, tokens), palette: starPalette(tokens), tokens }
			window.__draw = (flight, t) => {
				const ctx = canvas.getContext('2d', { alpha: false })
				const frame = {
					time: t,
					width: innerWidth,
					height: innerHeight,
					dpr: ratio,
					deviceWidth: canvas.width,
					deviceHeight: canvas.height,
					parallaxScroll: 0,
					keep: densityKeep(innerWidth, innerHeight),
					layers: { far: 1, mid: 1, near: 1 },
					dusk: Infinity,
					twinkle: 0,
					haze: 1,
					quiet: { from: [], to: zones, level: 1 },
					meteorInk: 1,
					meteorScroll: 1,
				}
				drawSky(ctx, assets, field, frame)
				if (flight) drawMeteor(ctx, assets, flight, frame)
			}
		},
		{ zones: field.quiet, dpr: capture.dpr }
	)
	for (const [n, pick] of chosen.entries()) {
		const f = pick.flight
		const end = P.meteorPoint(f, 1)
		const pad = 90
		const x0 = Math.max(0, Math.floor(Math.min(f.startX, end.x) - pad))
		const y0 = Math.max(0, Math.floor(Math.min(f.startY, end.y) - pad))
		const x1 = Math.min(capture.width, Math.ceil(Math.max(f.startX, end.x) + pad))
		const y1 = Math.min(capture.height, Math.ceil(Math.max(f.startY, end.y) + pad))
		const clip = { x: x0, y: y0, width: x1 - x0, height: y1 - y0 }
		const total = f.duration + 3 * f.wake
		const frames = []
		for (let k = 0; k < FRAMES; k++) {
			const t = 0.08 + (k / (FRAMES - 1)) * (total - 0.08)
			await page.evaluate(([flight, time]) => window.__draw(flight, time), [f, t])
			const png = await page.screenshot({ clip, type: 'png' })
			const p = t / f.duration
			const head = P.meteorPoint(f, Math.min(1, p))
			const light = f.peak * P.meteorLight(Math.min(1, p), f.flare)
			const kept = P.quietFactor(field.quiet, head.x, head.y, P.budgetKeeps(light * P.headGain(), P.METEOR_VEIL.quietKeep))
			frames.push({ t, p, kept, light, rise: light * P.headGain() * kept, src: 'data:image/png;base64,' + png.toString('base64') })
		}
		await page.evaluate(() => window.__draw(null, 0))
		sheets.push({ label, n, kind: pick.kind, visible: pick.visible, flight: { duration: f.duration, length: Math.round(f.length), speed: Math.round(f.speed), peak: f.peak.toFixed(2) }, clip, frames })
		console.log(label, n, pick.kind, `dur ${f.duration.toFixed(2)} s, ${Math.round(f.length)} px`)
	}
	if (logs.length) console.log('page errors', logs)
	await context.close()
	const tag = process.env.TAG ?? 'strip'
	const css = 'body{margin:0;background:#111;color:#ccc;font:12px/1.3 system-ui}section{padding:10px 12px;border-bottom:1px solid #333}h2{font-size:13px;margin:0 0 6px;color:#eee}figure{display:inline-block;margin:0 6px 6px 0;vertical-align:top}figcaption{font-size:11px;color:#9ab}img{display:block}'
	const body = sheets
		.map(
			(s) =>
				`<section id="s${s.n}"><h2>${s.label} #${s.n}: ${s.kind} (${s.flight.duration.toFixed(2)} s, ${s.flight.length} px, peak ${s.flight.peak}, visible on copy ${s.visible.toFixed(2)} s)</h2>${s.frames
					.map((fr) => `<figure><img src="${fr.src}" width="${Math.round(s.clip.width)}"><figcaption>+${fr.t.toFixed(2)} s p${fr.p.toFixed(2)} L${fr.light.toFixed(2)} veil ${fr.kept.toFixed(2)} white ${fr.rise.toFixed(3)}</figcaption></figure>`)
					.join('')}</section>`
		)
		.join('')
	fs.writeFileSync(path.join(SHOTS, `${tag}-${label}.html`), `<!doctype html><meta charset="utf-8"><style>${css}</style>${body}`)
	const ctx2 = await browser.newContext({ viewport: { width: 1900, height: 1000 } })
	const page2 = await ctx2.newPage()
	await page2.goto(pathToFileURL(path.join(SHOTS, `${tag}-${label}.html`)).href)
	for (const s of sheets) {
		const el = await page2.$('#s' + s.n)
		if (el) await el.screenshot({ path: path.join(SHOTS, `${tag}-${label}-${s.n}.png`) })
	}
	await ctx2.close()
} finally {
	await browser.close()
}
