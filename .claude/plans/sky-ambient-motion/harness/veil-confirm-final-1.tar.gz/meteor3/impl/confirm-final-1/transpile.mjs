// Transpiles the sky model and the worker's drawing modules to ES modules for Node and the test page, for three trees:
//   base:  the repository at HEAD (read with git show: the working tree now holds the implementation)
//   plan:  the plan's proposed files (meteor3/plan/proto, read-only; files it doesn't propose come from HEAD): what the plan said
//   before: the working tree as it stood before round-1 fixes (impl/confirm-final-1/before-src: the code the audit read)
//   proto: the repository's working tree, the implementation (the name the scripts use for "the proposed code", so every
//          script here runs on the implemented code; PTREE=plan in lib.mjs points them at the plan's files instead)
// Output: impl/pure/<tree>/lib-sky/*.mjs and impl/pure/<tree>/components-sky/{renderSky,skyAssets,sky.worker}.mjs
// Nothing outside impl/pure is written, and plan/pure (the plan's own build) is left as it was.
import { createRequire } from 'node:module'
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'

const HERE = 'C:/Users/josep/AppData/Local/Temp/claude/S--Documents-repos-Portfolio/f159339c-8cb2-444a-916b-251e57be791d/scratchpad/starfield/meteor3/impl/confirm-final-1'
const PLAN = 'C:/Users/josep/AppData/Local/Temp/claude/S--Documents-repos-Portfolio/f159339c-8cb2-444a-916b-251e57be791d/scratchpad/starfield/meteor3/plan/proto'
const REPO = 'S:/Documents/repos/Portfolio'
const require = createRequire(REPO + '/package.json')
const ts = require('typescript')

const head = (rel) => execFileSync('git', ['show', `HEAD:${rel}`], { cwd: REPO, encoding: 'utf8', maxBuffer: 1 << 26 })

// The source text of a tree's file
const sourceOf = (tree, rel) => {
	if (tree === 'base') return head(rel)
	if (tree === 'before') {
		const kept = path.join(HERE, 'before-src', rel)
		return fs.existsSync(kept) ? fs.readFileSync(kept, 'utf8') : head(rel)
	}
	if (tree === 'plan') {
		const proposed = path.join(PLAN, rel)
		return fs.existsSync(proposed) ? fs.readFileSync(proposed, 'utf8') : head(rel)
	}
	return fs.readFileSync(path.join(REPO, rel), 'utf8')
}

function emit(text, target, rewrite) {
	let { outputText } = ts.transpileModule(text, { compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 } })
	outputText = rewrite(outputText)
	fs.mkdirSync(path.dirname(target), { recursive: true })
	fs.writeFileSync(target, outputText)
}

const libFiles = fs.readdirSync(path.join(REPO, 'src/lib/sky')).filter((f) => f.endsWith('.ts'))
for (const tree of ['base', 'plan', 'before', 'proto']) {
	const out = path.join(HERE, 'pure', tree)
	fs.rmSync(out, { recursive: true, force: true })
	for (const file of libFiles) {
		emit(sourceOf(tree, `src/lib/sky/${file}`), path.join(out, 'lib-sky', file.replace(/\.ts$/, '.mjs')), (text) => text.replace(/from '\.\/([A-Za-z]+)'/g, "from './$1.mjs'"))
	}
	for (const file of ['renderSky.ts', 'skyAssets.ts', 'sky.worker.ts']) {
		emit(sourceOf(tree, `src/components/sky/${file}`), path.join(out, 'components-sky', file.replace(/\.ts$/, '.mjs')), (text) =>
			text.replace(/from '@\/lib\/sky\/([A-Za-z]+)'/g, "from '../lib-sky/$1.mjs'").replace(/from '\.\/([A-Za-z]+)'/g, "from './$1.mjs'")
		)
	}
	console.log(tree, fs.readdirSync(path.join(out, 'lib-sky')).join(' '), '|', fs.readdirSync(path.join(out, 'components-sky')).join(' '))
}
