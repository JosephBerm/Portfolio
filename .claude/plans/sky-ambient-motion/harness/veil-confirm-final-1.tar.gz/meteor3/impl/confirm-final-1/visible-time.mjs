// How long the head stays visible, today against proposed: the median over planned flights of the seconds the head pixel adds at least L
// of white anywhere (clear sky or copy), for L = 0.04 (a glimmer), 0.12, 0.25 and 0.5. The proposed veil takes light off the head near
// copy (to that copy's budget), so the time at high levels can only fall a little; "stays longer in frame" is about 0.04 and 0.12.
//   node visible-time.mjs [launches] [labels...]
import { P, B, loadCapture, fieldOf, walkProto, walkBase, median } from './lib.mjs'

const N = Number(process.argv[2] ?? 3000)
const labels = process.argv.slice(3).length ? process.argv.slice(3) : ['1440x900@1', '1280x800@1', '1920x1080@1']
const LEVELS = [0.04, 0.12, 0.25, 0.5]
const STEPS = 400
for (const label of labels) {
	const capture = loadCapture(label)
	const row = {}
	for (const tree of ['base', 'proto']) {
		const lib = tree === 'base' ? B : P
		const field = fieldOf(capture, lib)
		const walk = tree === 'base' ? walkBase : walkProto
		const random = lib.mulberry32(0x7131 + capture.width)
		const times = Object.fromEntries(LEVELS.map((l) => [l, []]))
		for (let i = 0; i < N; i++) {
			const f = lib.planMeteor(random, field, lib.pickRadiant(random, capture.width, capture.height), 0)
			if (!f) continue
			const w = walk(f, field.quiet, STEPS)
			for (const l of LEVELS) times[l].push((w.filter((s) => s.rise >= l).length / STEPS) * f.duration)
		}
		row[tree] = LEVELS.map((l) => `>=${l}: ${median(times[l]).toFixed(2)} s`).join(', ')
	}
	console.log(`${label.padEnd(12)} today: ${row.base} | proposed: ${row.proto}`)
}
