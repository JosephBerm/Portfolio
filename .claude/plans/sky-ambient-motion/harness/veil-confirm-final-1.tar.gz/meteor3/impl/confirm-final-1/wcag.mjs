// WCAG 2 contrast for the plan's scripts, written independently of src/lib/sky/color.ts (which keeps luminance and contrastRatio private),
// so the scripts check that module against a second implementation.
const linear = (channel) => {
	const c = channel / 255
	return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4
}
export const luminance = (rgb) => 0.2126 * linear(rgb[0]) + 0.7152 * linear(rgb[1]) + 0.0722 * linear(rgb[2])
export const contrastRatio = (a, b) => {
	const first = luminance(a)
	const second = luminance(b)
	return (Math.max(first, second) + 0.05) / (Math.min(first, second) + 0.05)
}
