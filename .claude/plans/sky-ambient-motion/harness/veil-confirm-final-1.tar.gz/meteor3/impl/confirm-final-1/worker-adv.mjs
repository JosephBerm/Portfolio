// Audit (correctness-wcag): the REAL transpiled worker of the working tree on a fake clock (harness/sim.mjs, recording 2D
// context), driven through adversarial message sequences while a shooting star passes behind copy:
//   A  a layout that moves copy, held by the C2 deferral because another layout started an ease just before it: does the
//      head stay within the budget of the copy where it really is (the held layout), as transientQuietFactor's doc claims?
//      Control: the same move sent alone (applied at once).
//   B  prefers-contrast: more switched on (then off) with the head on copy
//   C  reduced motion mid-flight, back to full; D  hidden tab mid-flight, back; E  resize mid-flight
//   F  every alpha the worker writes is finite and in 0-1 (gradient stops parsed back from rgba())
//   G  a layout whose rects all have headroom 0 mid-pass; H  a layout with no rects mid-pass
//   node worker-adv.mjs [passes]
import fs from 'node:fs'
import { HERE, ZONES, P, loadCapture, walkProto } from './lib.mjs'
import { createSim, alphaOf } from './harness/sim.mjs'

const label = process.env.LABEL ?? '1440x900@1'
const TREE = process.env.TREE ?? 'proto'
const PASSES = Number(process.argv[2] ?? 12)
const capture = loadCapture(label)
const raw = JSON.parse(fs.readFileSync(`${ZONES}/${label}.json`, 'utf8'))
const clean = (rects, headrooms) => rects.map((r, i) => ({ x: r.x, y: r.y, width: r.width, height: r.height, headroom: headrooms[i] ?? 0 }))
const settledRaw = raw.layouts.filter((l) => l.quiet.length > 0).at(-1)
const settled = { documentHeight: settledRaw.documentHeight, quiet: clean(settledRaw.quiet, capture.quiet.map((r) => r.headroom)), pinned: clean(settledRaw.pinned, capture.pinned.map((r) => r.headroom)) }
const shifted = (dx, dy) => ({ documentHeight: settled.documentHeight, quiet: settled.quiet.map((r) => ({ ...r, x: r.x + dx, y: r.y + dy })), pinned: settled.pinned.map((r) => ({ ...r, x: r.x + dx, y: r.y + dy })) })
const insideRect = (r, x, y) => x >= r.x && x <= r.x + r.width && y >= r.y && y <= r.y + r.height
const TOL = 2e-4
const out = []
const log = (...a) => {
	const line = a.join(' ')
	out.push(line)
	console.log(line)
}

// The head's white per drawn frame, read back from what the worker drew (core + glow sprites, the wake's head stop through both passes)
const headWhite = (f) => {
	const core = f.meteorImages.find((i) => i.size === 7)
	if (!core) return null
	const glow = f.meteorImages.find((i) => i.size === 19)
	const fill = f.fills.reduce((a, x) => a + x.alpha * alphaOf(x.gradient.stops[0][1]), 0)
	return { x: core.cx, y: core.cy, white: core.alpha + (glow?.alpha ?? 0) + fill }
}
// F: every alpha written: sprite globalAlpha, fill globalAlpha x each stop alpha, stroke stop alphas
const badAlphas = (frames) => {
	let bad = 0
	for (const f of frames) {
		for (const i of f.meteorImages) if (!Number.isFinite(i.alpha) || i.alpha < 0 || i.alpha > 1) bad++
		for (const x of [...f.fills, ...f.strokes]) for (const [, color] of x.gradient.stops) {
			const a = alphaOf(color)
			if (!Number.isFinite(a) || a < 0 || a > 1) bad++
		}
	}
	return bad
}

async function start(seed) {
	const sim = await createSim({ width: capture.width, height: capture.height, seed, tree: TREE })
	sim.send({ type: 'init' })
	sim.advance(3800)
	sim.send({ type: 'reveal' })
	const revealAt = sim.clock.now
	sim.send({ type: 'layout', ...settled })
	if (!sim.until(revealAt + 20000, () => !!sim.dbg.meteor)) return null
	return sim
}

// Seeds whose first launch passes behind copy (head on a text rect at the glimmer level or more) and when it arrives there
const seeds = []
for (let seed = 1; seeds.length < PASSES && seed < 600; seed++) {
	const sim = await start(seed)
	if (!sim) continue
	const flight = { ...sim.dbg.meteor }
	const walk = walkProto(flight, P.screenQuietZones(settled.quiet, 0, settled.pinned), 600)
	const on = walk.find((s) => s.onCopy && s.rise >= P.METEOR_PASS.visible)
	if (on) seeds.push({ seed, arrives: on.p * flight.duration, launchMs: sim.clock.now })
}
log(`${label}: ${seeds.length} seeds whose first flight passes behind copy at 0.12 of white or more`)

// ---------- A: held layout ----------
async function runA({ seed, arrives }, first, moved, lead, gapMs) {
	const sim = await start(seed)
	const launchMs = sim.clock.now
	const firstMs = launchMs + Math.max(0, arrives - lead) * 1000
	sim.until(firstMs)
	if (first) sim.send({ type: 'layout', ...first })
	sim.until(sim.clock.now + gapMs)
	const movedT = sim.clock.now / 1000
	sim.send({ type: 'layout', ...moved })
	const held = sim.dbg.pendingLayout !== null
	sim.until(sim.clock.now + 900)
	sim.flush()
	let over = 0
	let frames = 0
	let worst = 0
	let worstAt = null
	const texts = [...moved.quiet, ...moved.pinned]
	for (const f of sim.frames) {
		if (f.t < movedT - 1e-9) continue
		const h = headWhite(f)
		if (!h) continue
		const budgets = texts.filter((r) => insideRect(r, h.x, h.y)).map((r) => P.inkBudget(r.headroom))
		if (!budgets.length) continue
		frames++
		const budget = Math.min(...budgets)
		if (h.white / budget > worst) {
			worst = h.white / budget
			worstAt = { t: +(f.t - movedT).toFixed(3), white: +h.white.toFixed(4), budget: +budget.toFixed(4) }
		}
		if (h.white - budget > TOL) over++
	}
	return { held, frames, over, worst, worstAt, bad: badAlphas(sim.frames) }
}
// Flights that come near copy without necessarily passing behind it, each with the copy move (up to MAXMOVE px, default 30) that would put the
// most unveiled light on the moved copy if the worker kept the old zones: the case the deferral leaves to transientQuietFactor
const MAXMOVE = Number(process.env.MAXMOVE ?? 30)
const near = []
const zonesNow = P.screenQuietZones(settled.quiet, 0, settled.pinned)
for (let seed = 1; near.length < PASSES && seed < 900; seed++) {
	const sim = await start(seed)
	if (!sim || !sim.dbg.meteor.nearCopy) continue
	const flight = { ...sim.dbg.meteor }
	const walk = walkProto(flight, zonesNow, 300)
	let best = null
	for (let dx = -MAXMOVE; dx <= MAXMOVE; dx += 5) {
		for (let dy = -MAXMOVE; dy <= MAXMOVE; dy += 5) {
			const moved = [...settled.quiet, ...settled.pinned].map((r) => ({ ...r, x: r.x + dx, y: r.y + dy }))
			for (const s of walk) {
				const inside = moved.filter((r) => insideRect(r, s.x, s.y))
				if (!inside.length) continue
				const budget = Math.min(...inside.map((r) => P.inkBudget(r.headroom)))
				const ratio = s.rise / budget
				if (!best || ratio > best.ratio) best = { ratio, dx, dy, t: s.p * flight.duration }
			}
		}
	}
	if (best && best.ratio > 1.2) near.push({ seed, arrives: best.t, vector: [best.dx, best.dy], model: best.ratio })
}
log(`${near.length} seeds whose first flight comes near copy and would light copy moved by up to ${MAXMOVE} px above its budget under the old zones (model ratio ${near.map((n) => n.model.toFixed(1)).join(' ')})`)
log('\nA2. that move, sent 100 ms after an unrelated 1 px re-measure started an ease (held), against the same move sent alone (applied at once)')
{
	let runs = 0
	let heldRuns = 0
	let overRuns = 0
	let overFrames = 0
	let worst = 0
	let worstAt = null
	let controlOver = 0
	let controlWorst = 0
	let bad = 0
	for (const entry of near) {
		const moved = shifted(...entry.vector)
		for (const lead of [0.15, 0.3, 0.45]) {
			const a = await runA(entry, shifted(0, 1), moved, lead, 100)
			const c = await runA(entry, null, moved, lead, 100)
			runs++
			if (a.held) heldRuns++
			if (a.over) overRuns++
			overFrames += a.over
			if (a.worst > worst) {
				worst = a.worst
				worstAt = { seed: entry.seed, vector: entry.vector, lead, ...a.worstAt }
			}
			if (c.over) controlOver++
			controlWorst = Math.max(controlWorst, c.worst)
			bad += a.bad + c.bad
		}
	}
	log(`  held ${heldRuns}/${runs}; runs with the head above the moved copy's budget ${overRuns} (${overFrames} frames), worst head white / budget ${worst.toFixed(2)} ${JSON.stringify(worstAt)} | sent alone: runs above budget ${controlOver}, worst ${controlWorst.toFixed(3)} | bad alphas ${bad}`)
}
log('\nA1. flights that pass behind copy, copy moved by fixed vectors (the message lands `lead` s before the head reaches the copy)')
for (const [name, dx, dy] of [['down 15', 0, 15], ['up 15', 0, -15], ['left 20', -20, 0], ['down 25', 0, 25]]) {
	const moved = shifted(dx, dy)
	const tiny = shifted(0, 1) // an unrelated re-measure that changes a rect by 1 px starts an ease just before
	let runs = 0
	let heldRuns = 0
	let overRuns = 0
	let overFrames = 0
	let worst = 0
	let worstAt = null
	let controlOver = 0
	let controlWorst = 0
	let bad = 0
	for (const entry of seeds) {
		for (const lead of [0.05, 0.2]) {
			const a = await runA(entry, tiny, moved, lead, 100)
			const c = await runA(entry, null, moved, lead, 100)
			runs++
			if (a.held) heldRuns++
			if (a.over) overRuns++
			overFrames += a.over
			if (a.worst > worst) {
				worst = a.worst
				worstAt = { seed: entry.seed, lead, ...a.worstAt }
			}
			if (c.over) controlOver++
			controlWorst = Math.max(controlWorst, c.worst)
			bad += a.bad + c.bad
		}
	}
	log(`  ${name.padEnd(8)} after a 1 px re-measure 100 ms before: held ${heldRuns}/${runs}; runs with the head above the moved copy's budget ${overRuns} (${overFrames} frames), worst head white / budget ${worst.toFixed(2)} ${JSON.stringify(worstAt)} | sent alone: runs above budget ${controlOver}, worst ${controlWorst.toFixed(3)} | bad alphas ${bad}`)
}

// ---------- B to H ----------
async function midPass({ seed, arrives }, inject, { after = 700 } = {}) {
	const sim = await start(seed)
	const launchMs = sim.clock.now
	sim.until(launchMs + arrives * 1000 + 30)
	const injectT = sim.clock.now / 1000
	const before = sim.dbg.meteor !== null
	inject(sim)
	sim.until(sim.clock.now + after)
	sim.flush()
	const later = sim.frames.filter((f) => f.t > injectT + 1e-9)
	return { sim, injectT, before, later, bad: badAlphas(sim.frames) }
}
const zonesSettled = [...settled.quiet, ...settled.pinned]
let rowsB = { runs: 0, onCopyAfter: 0, maxOnCopy: 0, bad: 0, offOK: 0 }
let rowsC = { runs: 0, drawsAfter: 0, nextGap: Infinity, bad: 0 }
let rowsD = { runs: 0, drawsAfter: 0, nextGap: Infinity, bad: 0 }
let rowsE = { runs: 0, drawsAfter: 0, radiantCleared: 0, bad: 0 }
let rowsG = { runs: 0, maxOnCopy: 0, bad: 0 }
let rowsH = { runs: 0, bad: 0, drawn: 0 }
for (const entry of seeds) {
	// B: contrast more with the head on copy: from the next frame no light on the copy itself; then back off
	{
		const r = await midPass(entry, (sim) => sim.send({ type: 'contrast', more: true }), { after: 250 })
		rowsB.runs++
		for (const f of r.later) {
			const h = headWhite(f)
			if (!h) continue
			if (zonesSettled.some((z) => insideRect(z, h.x, h.y))) {
				rowsB.onCopyAfter++
				rowsB.maxOnCopy = Math.max(rowsB.maxOnCopy, h.white)
			}
		}
		r.sim.send({ type: 'contrast', more: false })
		r.sim.until(r.sim.clock.now + 400)
		r.sim.flush()
		rowsB.bad += badAlphas(r.sim.frames)
		if (badAlphas(r.sim.frames) === 0) rowsB.offOK++
	}
	// C: reduced motion mid-flight: gone at once; back to full motion: the next one waits METEOR.afterReturn
	{
		const r = await midPass(entry, (sim) => sim.send({ type: 'motion', motion: 'reduced' }), { after: 400 })
		rowsC.runs++
		rowsC.drawsAfter += r.later.filter((f) => f.meteorImages.length + f.fills.length + f.strokes.length > 0 && f.t > r.injectT + 0.001).length
		const backAt = r.sim.clock.now / 1000
		r.sim.send({ type: 'motion', motion: 'full' })
		r.sim.send({ type: 'scroll', y: 0 })
		r.sim.until(r.sim.clock.now + 60000, () => !!r.sim.dbg.meteor)
		if (r.sim.dbg.meteor) rowsC.nextGap = Math.min(rowsC.nextGap, r.sim.dbg.meteor.startedAt - backAt)
		rowsC.bad += r.bad
	}
	// D: hidden mid-flight
	{
		const r = await midPass(entry, (sim) => sim.send({ type: 'visible', visible: false }), { after: 400 })
		rowsD.runs++
		rowsD.drawsAfter += r.later.length
		const backAt = r.sim.clock.now / 1000
		r.sim.send({ type: 'visible', visible: true })
		r.sim.until(r.sim.clock.now + 60000, () => !!r.sim.dbg.meteor)
		if (r.sim.dbg.meteor) rowsD.nextGap = Math.min(rowsD.nextGap, r.sim.dbg.meteor.startedAt - backAt)
		rowsD.bad += r.bad
	}
	// E: resize mid-flight
	{
		const r = await midPass(entry, (sim) => sim.send({ type: 'resize', width: capture.width - 40, height: capture.height, dpr: 1 }), { after: 300 })
		rowsE.runs++
		rowsE.drawsAfter += r.later.filter((f) => f.meteorImages.length + f.fills.length > 0).length
		if (r.sim.dbg.radiant === null) rowsE.radiantCleared++
		rowsE.bad += r.bad
	}
	// G: the same rects with headroom 0 (copy whose color could not be read): no light on it from the next frame
	{
		const zero = { documentHeight: settled.documentHeight, quiet: settled.quiet.map((r) => ({ ...r, headroom: 0 })), pinned: settled.pinned.map((r) => ({ ...r, headroom: 0 })) }
		const r = await midPass(entry, (sim) => sim.send({ type: 'layout', ...zero }), { after: 300 })
		rowsG.runs++
		for (const f of r.later) {
			const h = headWhite(f)
			if (h && zonesSettled.some((z) => insideRect(z, h.x, h.y))) rowsG.maxOnCopy = Math.max(rowsG.maxOnCopy, h.white)
		}
		rowsG.bad += r.bad
	}
	// H: a layout with no rects at all mid-pass
	{
		const r = await midPass(entry, (sim) => sim.send({ type: 'layout', documentHeight: settled.documentHeight, quiet: [], pinned: [] }), { after: 300 })
		rowsH.runs++
		rowsH.drawn += r.later.length
		rowsH.bad += r.bad
	}
}
log('\nB. prefers-contrast: more with the head on copy:', `${rowsB.runs} runs; frames with the head on copy afterwards ${rowsB.onCopyAfter}, most white the head adds there ${rowsB.maxOnCopy.toFixed(4)}; bad alphas ${rowsB.bad}; back to normal without a bad alpha in ${rowsB.offOK}/${rowsB.runs}`)
log('C. reduced motion mid-flight:', `${rowsC.runs} runs; shooting-star frames drawn after it ${rowsC.drawsAfter}; back to full motion, the next launch at least ${rowsC.nextGap.toFixed(2)} s later (METEOR.afterReturn ${P.METEOR.afterReturn}); bad alphas ${rowsC.bad}`)
log('D. hidden tab mid-flight:', `${rowsD.runs} runs; frames drawn after it ${rowsD.drawsAfter}; visible again, the next launch at least ${rowsD.nextGap.toFixed(2)} s later; bad alphas ${rowsD.bad}`)
log('E. resize mid-flight:', `${rowsE.runs} runs; shooting-star frames drawn after it ${rowsE.drawsAfter}; radiant cleared in ${rowsE.radiantCleared}; bad alphas ${rowsE.bad}`)
log('G. every rect re-measured at headroom 0 mid-pass:', `${rowsG.runs} runs; most white the head adds on copy afterwards ${rowsG.maxOnCopy.toFixed(4)}; bad alphas ${rowsG.bad}`)
log('H. a layout with no rects mid-pass:', `${rowsH.runs} runs; frames drawn after it ${rowsH.drawn}; bad alphas ${rowsH.bad}`)
fs.writeFileSync(`${HERE}/results/worker-adv-${TREE}${process.env.MAXMOVE ? '-move' + process.env.MAXMOVE : ''}.txt`, out.join(String.fromCharCode(10)) + String.fromCharCode(10))
