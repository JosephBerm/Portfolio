// Visual audit 2 helpers: own headless Chromium via playwright-core, observe only (nothing routed or patched).
import fs from 'node:fs'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
export const PW = 'C:/Users/josep/AppData/Local/npm-cache/_npx/e41f203b7505f1fb/node_modules/playwright-core'
export const pw = require(PW)
export const { PNG } = require(PW + '/lib/utilsBundle.js')
export const HERE = 'C:/Users/josep/AppData/Local/Temp/claude/S--Documents-repos-Portfolio/f159339c-8cb2-444a-916b-251e57be791d/scratchpad/starfield/meteor3/live-capture'
export const OUT = HERE + '/out'
fs.mkdirSync(OUT, { recursive: true })
export const CHROME = 'C:/Users/josep/AppData/Local/ms-playwright/chromium-1223/chrome-win64/chrome.exe'
export const GPU_ARGS = ['--enable-gpu', '--ignore-gpu-blocklist', '--use-angle=d3d11']
export const URL = 'http://localhost:3000/'
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

export function launch(args = GPU_ARGS) {
	return pw.chromium.launch({ executablePath: CHROME, headless: true, args })
}

export function parseSpec(spec) {
	const mobile = spec.endsWith('m')
	const [size, ratio] = spec.replace(/m$/, '').split('@')
	const [width, height] = size.split('x').map(Number)
	return { width, height, dsf: Number(ratio ?? 1), mobile, name: `${width}x${height}@${Number(ratio ?? 1)}${mobile ? 'm' : ''}` }
}

// Page init: wraps Worker.prototype.postMessage to log every message the page posts to a worker (epoch ms, with the
// quiet and pinned rect arrays of each layout message), minus the canvas and tokens. Observe only.
export const PAGE_INIT = `(() => {
	const now = () => performance.timeOrigin + performance.now()
	const t = (window.__a2 = { posts: [] })
	const post = Worker.prototype.postMessage
	Worker.prototype.postMessage = function (message, transfer) {
		try {
			const m = { at: now(), type: message.type }
			for (const [k, v] of Object.entries(message)) if (k !== 'canvas' && k !== 'tokens' && k !== 'type') m[k] = v
			t.posts.push(m)
		} catch {}
		return post.call(this, message, transfer)
	}
})()`

export const posts = (page) => page.evaluate(() => window.__a2.posts)
export const pageEpoch = (page) => page.evaluate(() => performance.timeOrigin + performance.now())

export async function waitFor(fn, timeout, label, interval = 50) {
	const start = Date.now()
	for (;;) {
		const value = await fn()
		if (value) return value
		if (Date.now() - start > timeout) throw new Error('timeout: ' + label)
		await sleep(interval)
	}
}

export async function skyWorkerOf(workers) {
	for (const w of workers) {
		try {
			if ((await w.evaluate(() => self.name)) === 'sky') return w
		} catch {}
	}
	return null
}

export const decode = (buf) => PNG.sync.read(buf)
export const encode = (png) => PNG.sync.write(png)

export function blank(w, h, bg = [0, 0, 0]) {
	const out = new PNG({ width: w, height: h })
	for (let i = 0; i < out.data.length; i += 4) {
		out.data[i] = bg[0]
		out.data[i + 1] = bg[1]
		out.data[i + 2] = bg[2]
		out.data[i + 3] = 255
	}
	return out
}

export function crop(img, x0, y0, w, h) {
	const out = new PNG({ width: w, height: h })
	for (let y = 0; y < h; y++) {
		for (let x = 0; x < w; x++) {
			const sx = Math.min(img.width - 1, Math.max(0, x0 + x))
			const sy = Math.min(img.height - 1, Math.max(0, y0 + y))
			const s = (sy * img.width + sx) * 4
			const d = (y * w + x) * 4
			out.data[d] = img.data[s]
			out.data[d + 1] = img.data[s + 1]
			out.data[d + 2] = img.data[s + 2]
			out.data[d + 3] = 255
		}
	}
	return out
}

/** Pastes `tile` into `out` at (ox, oy). */
export function paste(out, tile, ox, oy) {
	for (let y = 0; y < tile.height; y++) {
		const dy = oy + y
		if (dy < 0 || dy >= out.height) continue
		for (let x = 0; x < tile.width; x++) {
			const dx = ox + x
			if (dx < 0 || dx >= out.width) continue
			const s = (y * tile.width + x) * 4
			const d = (dy * out.width + dx) * 4
			out.data[d] = tile.data[s]
			out.data[d + 1] = tile.data[s + 1]
			out.data[d + 2] = tile.data[s + 2]
			out.data[d + 3] = 255
		}
	}
}

/** Lays equal-size tiles out in a grid with a gap. */
export function sheet(tiles, cols, gap = 4, bg = [60, 0, 0]) {
	const tw = tiles[0].width
	const th = tiles[0].height
	const rows = Math.ceil(tiles.length / cols)
	const out = blank(cols * tw + (cols - 1) * gap, rows * th + (rows - 1) * gap, bg)
	tiles.forEach((tile, i) => paste(out, tile, (i % cols) * (tw + gap), Math.floor(i / cols) * (th + gap)))
	return out
}

/** Area-average resize. */
export function resize(img, w, h) {
	const out = new PNG({ width: w, height: h })
	const fx = img.width / w
	const fy = img.height / h
	for (let y = 0; y < h; y++)
		for (let x = 0; x < w; x++) {
			const x0 = Math.floor(x * fx)
			const x1 = Math.max(x0 + 1, Math.floor((x + 1) * fx))
			const y0 = Math.floor(y * fy)
			const y1 = Math.max(y0 + 1, Math.floor((y + 1) * fy))
			let r = 0
			let g = 0
			let b = 0
			let n = 0
			for (let yy = y0; yy < y1; yy++)
				for (let xx = x0; xx < x1; xx++) {
					const i = (Math.min(img.height - 1, yy) * img.width + Math.min(img.width - 1, xx)) * 4
					r += img.data[i]
					g += img.data[i + 1]
					b += img.data[i + 2]
					n++
				}
			const o = (y * w + x) * 4
			out.data[o] = r / n
			out.data[o + 1] = g / n
			out.data[o + 2] = b / n
			out.data[o + 3] = 255
		}
	return out
}

/** Nearest-neighbor upscale by an integer factor (to look at pixels). */
export function zoom(img, k) {
	const out = new PNG({ width: img.width * k, height: img.height * k })
	for (let y = 0; y < out.height; y++)
		for (let x = 0; x < out.width; x++) {
			const s = (Math.floor(y / k) * img.width + Math.floor(x / k)) * 4
			const d = (y * out.width + x) * 4
			out.data[d] = img.data[s]
			out.data[d + 1] = img.data[s + 1]
			out.data[d + 2] = img.data[s + 2]
			out.data[d + 3] = 255
		}
	return out
}

/** Multiplies the difference from `base` (an image of the same size, or an RGB) by `gain`, so faint light shows. */
export function boost(img, base, gain) {
	const out = new PNG({ width: img.width, height: img.height })
	for (let i = 0; i < img.data.length; i += 4) {
		for (let k = 0; k < 3; k++) {
			const b = Array.isArray(base) ? base[k] : base.data[i + k]
			out.data[i + k] = Math.max(0, Math.min(255, b + (img.data[i + k] - b) * gain))
		}
		out.data[i + 3] = 255
	}
	return out
}

/** Draws a 1px rectangle outline (for marking text boxes in diagnostic images). */
export function outline(img, x0, y0, w, h, rgb) {
	const set = (x, y) => {
		if (x < 0 || y < 0 || x >= img.width || y >= img.height) return
		const d = (y * img.width + x) * 4
		img.data[d] = rgb[0]
		img.data[d + 1] = rgb[1]
		img.data[d + 2] = rgb[2]
	}
	for (let x = x0; x < x0 + w; x++) {
		set(x, y0)
		set(x, y0 + h - 1)
	}
	for (let y = y0; y < y0 + h; y++) {
		set(x0, y)
		set(x0 + w - 1, y)
	}
}

// WCAG 2 relative luminance and contrast
const lin = (c) => {
	const s = c / 255
	return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4
}
export const luminance = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
export const contrast = (a, b) => {
	const la = luminance(a)
	const lb = luminance(b)
	return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
}
export function hex(h) {
	const m = /^#?([0-9a-f]{6})$/i.exec(h.trim())
	if (!m) return null
	const n = parseInt(m[1], 16)
	return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}
export function parseColor(s) {
	const m = /rgba?\(([^)]+)\)/.exec(s)
	if (!m) return hex(s)
	return m[1].split(',').slice(0, 3).map((v) => Math.round(Number(v)))
}
export const median = (xs) => {
	const s = [...xs].sort((a, b) => a - b)
	return s.length ? (s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2) : null
}
